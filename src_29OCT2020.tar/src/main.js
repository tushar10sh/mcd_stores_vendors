import Vue from "vue";
import App from "./App.vue";
//import "vuelayers/lib/style.css";
import vuetify from "./plugins/vuetify";
//import "ol/ol.css";
import store from "./store/store";
//import "vuetify/dist/vuetify.min.css";
/* import "@mdi/font/css/materialdesignicons.min.css";
import "typeface-roboto/index.css"; */

Vue.config.productionTip = true;

new Vue({
  store,
  vuetify,
  render: (h) => h(App),
}).$mount("#app");
