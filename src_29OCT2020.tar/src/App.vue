<template>
  <v-app app>
    <HeaderRapid />
    <v-main>
      <BodyRapid />
    </v-main>
    <v-bottom-sheet
      v-if="mobileView"
      max-width="500px"
      no-click-animation
      v-model="layerlist_open"
      hide-overlay
      persistent
      inset
    >
      <LayerConfigurationUI />
    </v-bottom-sheet>
  </v-app>
</template>

<script>
import HeaderRapid from "./components/HeaderRapid.vue";
import BodyRapid from "./components/BodyRapid.vue";
import { mapState, mapMutations } from "vuex";
import LayerConfigurationUI from "./components/LayerConfigurationUI.vue";
import { LocalStorageHelper } from "./mixins/";
export default {
  name: "App",

  components: {
    HeaderRapid,
    BodyRapid,
    LayerConfigurationUI
  },
  mixins: [LocalStorageHelper],
  computed: {
    //...mapGetters(["isLayerListOpen"])
    ...mapState(["layerlist_open", "mobileView"])
  },
  created() {
    this.clearLocalStorage();
    this.handleView();
    window.addEventListener("resize", this.handleView);
  },
  methods: {
    handleView() {
      this.setMobileView(window.innerWidth <= 990);
    },
    ...mapMutations(["setMobileView"])
  },

  data: () => ({
    open_tab: false
  })
};
</script>
<style scoped>
html,
body {
  height: 100%;
}
</style>
<!--height: calc(var(--vh, 1vh) * 100);-->

