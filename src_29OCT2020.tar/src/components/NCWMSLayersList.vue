<template>
  <div>
    <NCWMSLayer
      v-for="(layer, index) in ncmwms_layers"
      :key="index"
      :index="layer_offset + index"
      :ncwms_layer="layer"
    />
  </div>
</template>
<script>
import NCWMSLayer from "./NCWMSLayer.vue";
import { NCWMSHelper } from "../mixins/";

export default {
  name: "NCMWMSLayersList",
  mixins: [NCWMSHelper],

  data() {
    return {
      ncmwms_layers: []
    };
  },
  components: {
    NCWMSLayer
  },
  props: {
    proc_prods: {
      type: Object,
      required: true
    },
    layer_type: {
      type: String,
      required: true
    },
    layer_offset: {
      type: Number,
      required: true
    }
  },

  created() {
    let rapid_ncwms_layer = this.getRapidNCWMSLayer();

    this.ncmwms_layers.push(rapid_ncwms_layer);
  },
  methods: {
    getRapidNCWMSLayer() {
      let rapid_ncwms_layer = {
        layer_type: this.layer_type,
        projection: this.proc_prods.projection.trim(),
        url_prefix: this.proc_prods.url_prefix.trim(),
        wms_version: this.proc_prods.wms_version.trim(),
        format: this.proc_prods.format.trim(),
        visible:
          this.proc_prods.visible === undefined
            ? false
            : this.proc_prods.visible
      };

      let found_def_layer = false;

      let sensors = this.proc_prods["sensors"];
      //console.log("rapid_ncwms_layer:" + rapid_ncwms_layer.visible);

      for (let sensor of sensors) {
        let ptypes = sensor["ptypes"];
        for (let ptype of ptypes) {
          let datasets = ptype["datasets"];
          for (let ds of datasets) {
            let layers = ds["layers"];
            let def_layer = layers.filter(layer => true == layer["def"]);

            if (!found_def_layer && def_layer.length) {
              //console.log("layername:" + def_layer[0].name);
              //console.log("typeof layername:" + typeof def_layer[0].name);
              if (typeof def_layer[0].name === "string") {
                rapid_ncwms_layer.range = undefined;
                rapid_ncwms_layer.layer_name = `${ds.ds_name}/${def_layer[0].name}`;
                rapid_ncwms_layer.attribution =
                  def_layer[0].caption === undefined
                    ? `${ds.ds_name}/${def_layer[0].name}`
                    : `${ds.ds_name}/${def_layer[0].caption}`;
              } else {
                rapid_ncwms_layer.layer_name = new Array();
                let concat_layernames = `${ds.ds_name}`;

                for (let single_layer of def_layer[0].name) {
                  single_layer = single_layer.trim();
                  if (single_layer.includes("/")) {
                    rapid_ncwms_layer.layer_name.push(single_layer);
                  } else {
                    rapid_ncwms_layer.layer_name.push(
                      `${ds.ds_name}/${single_layer}`
                    );
                  }
                  concat_layernames += "/" + single_layer;
                }

                rapid_ncwms_layer.range_options = [];
                for (let rng of def_layer[0].range) {
                  rapid_ncwms_layer.range_options.push(rng);
                }

                rapid_ncwms_layer.attribution =
                  def_layer[0].caption === undefined
                    ? `${ds.ds_name}/${concat_layernames}`
                    : `${ds.ds_name}/${def_layer[0].caption}`;
              }
              rapid_ncwms_layer.style =
                def_layer[0].style === undefined
                  ? "default"
                  : def_layer[0].style;

              let minRes = def_layer[0].minResolution;
              let maxRes = def_layer[0].maxResolution;
              rapid_ncwms_layer.minResolution =
                minRes === undefined
                  ? this.proc_prods.DEFAULT_MIN_RESOLUTION
                  : minRes;
              rapid_ncwms_layer.maxResolution =
                maxRes === undefined
                  ? this.proc_prods.DEFAULT_MAX_RESOLUTION
                  : maxRes;

              rapid_ncwms_layer.sld_template = def_layer[0].sld_template;
              rapid_ncwms_layer.sld = def_layer[0].sld;
              rapid_ncwms_layer.clipRange =
                def_layer[0].clipRange === undefined
                  ? false
                  : def_layer[0].clipRange;
              console.log(
                "radpi_ncwms_layer clipRange:" +
                  rapid_ncwms_layer.clipRange +
                  " " +
                  rapid_ncwms_layer.attribution
              );

              rapid_ncwms_layer.autoscl = def_layer[0].autoscl;
              //console.log("rapid sat layer_name:" + rapid_ncwms_layer.layer_name);
              found_def_layer = true;
              break;
            }
          }
          if (found_def_layer) {
            break;
          }
        }
        if (found_def_layer) {
          break;
        }
      }

      return rapid_ncwms_layer;
    }
  }
};
</script>
