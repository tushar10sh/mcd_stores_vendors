<template>
  <vl-layer-tile
    v-if="vector_layer != undefined"
    :key="vector_layer.url + '_' + vector_layer.layerName"
    :z-index="index"
    :opacity="vector_layer.opacity"
    :visible="vector_layer.visible"
  >
    <vl-source-wms
      :url="vector_layer.url"
      :version="vector_layer.version"
      :layers="vector_layer.layerName"
      :projection="vector_layer.projection"
      :img_format="vector_layer.img_format"
      :attributions="vector_layer.attribution"
      :extParams="vector_layer.extParams"
    ></vl-source-wms>
  </vl-layer-tile>
</template>

<script>
export default {
  name: "RapidVectorLayer",

  props: {
    vector_layer: {
      type: Object,
      required: true
    },
    index: {
      type: Number,
      default: 0
    },
    category: {
      type: String,
      required: true
    }
  }
};
</script>

