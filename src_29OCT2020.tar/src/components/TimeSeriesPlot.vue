<template>
  <div
    v-show="my_probe_info !== undefined && my_probe_info.location.length > 0"
  >
    <v-layout ref="chart" id="chart">
      <v-flex xs12>
        <svg class="tschart" />
      </v-flex>
    </v-layout>

    <v-layout>
      <v-flex xs12>
        <div v-html="probe_value" />
      </v-flex>
    </v-layout>
  </div>
  <!--</div>-->
</template>

<script>
import d3 from "../plugins/D3Importer.js";
import { NCWMSHelper, FetchHelper } from "../mixins/";
import { mapState, mapGetters, mapMutations } from "vuex";
export default {
  name: "TimeSeriesPlot",
  mixins: [NCWMSHelper, FetchHelper],
  computed: {
    ...mapGetters(["getFromMetadataCache", "getFromTSCache"]),
    ...mapState(["sel_timezone"]),
  },
  watch: {
    ts_probe_info: {
      handler(new_val) {
        if (new_val !== undefined && new_val.location.length > 0) {
          if (
            this.my_probe_info === undefined ||
            this.isTSProbeInfoChanged(this.my_probe_info, new_val)
          ) {
            this.my_probe_info = this.deepCopy(new_val);
            this.initialize();

            this.plot();
          }
        }
      },
      deep: true,
    },
    sel_timezone: {
      handler(new_val) {
        //console.log("In sel_timezone");
        if (this.xAxis != undefined) {
          let time_axis_format = this.getTimeAxisFormat(new_val.id);
          this.xAxis.tickFormat(time_axis_format);
          this.gXAxis.call(this.xAxis);
        }
      },
      deep: true,
    },
  },
  props: {
    ts_probe_info: {
      type: Object,
      required: false,
    },
  },

  data() {
    return {
      cushion: 2,
      width: 0,
      height: 0,
      //offset: 0,
      limit: 10,
      current_index: 0,
      margin: undefined,
      chartData: undefined,
      full_data: undefined,
      layerNames: [],
      date_fetch_map: {},
      param_units: [],
      unit_layer_map: {},
      lname_yScale_map: {},
      lname_yAxis_map: {},
      lname_gYAxis_map: {},
      line_function_map: {},
      isoParseDate: d3.timeParse("%Y-%m-%dT%H:%M:%S.%L%Z"),
      unit_axiscaption_map: {},

      lname_color_map: {},
      circle_radius: 3,
      //tz: "UTC",
      updating: false,
      my_probe_info: undefined,
      tooltip_rect: undefined,
      probe_value: "",
      cursorLine: undefined,
    };
  },
  mounted() {
    if (this.ts_probe_info !== undefined) {
      this.my_probe_info = this.deepCopy(this.ts_probe_info);
      this.initialize();
      this.plot();
    }
  },

  methods: {
    ...mapMutations(["addToTSCache"]),

    async getData(probe_url) {
      //console.log("probe_url:" + probe_url);
      //let response = await d3.json(probe_url);
      let response_arr = await this.fetchUrl([probe_url]);
      //console.log("response_Arr:" + response_arr.length);
      let response = response_arr[0];
      //console.log("response:" + response);

      let lines = [];
      let ranges = response.ranges;
      if (ranges !== undefined) {
        let parameter_values = [];
        for (let key of Object.keys(ranges)) {
          parameter_values.push(ranges[key].values);
        }
        let time_values = response.domain.axes.t.values;

        let num_obs = time_values.length;

        let num_layers = this.layerNames.length;
        //console.log("num_layers:" + num_layers);

        for (let pindx = 0; pindx < num_layers; pindx++) {
          let band = [];
          for (let indx = 0; indx < num_obs; indx++) {
            let measurement_val =
              parameter_values[pindx][indx] === null
                ? NaN
                : +parameter_values[pindx][indx];
            band.push({
              date: this.isoParseDate(time_values[indx]),
              measurement: measurement_val,
            });
            /* console.log(
            "measurement:" + (parameter_values[pindx][indx] === null)
          ); */
          }
          lines.push({ id: this.layerNames[pindx], values: band.reverse() }); //Latest to First
        }
      }

      return lines;
    },

    getAxisCaption(layer_names, param_unit) {
      let num_layers = layer_names.length;
      let axis_caption = layer_names[0].split("/")[1];
      for (let i = 1; i < num_layers; i++) {
        axis_caption += ", " + layer_names[i].split("/")[1];
      }
      if (param_unit !== "") {
        axis_caption += " (" + param_unit + ")";
      }
      return axis_caption;
    },
    initialize() {
      //console.log("In initialize");

      this.date_fetch_map = {};
      this.param_units = [];

      this.unit_layer_map = {};
      this.unit_axiscaption_map = {};

      this.lname_yScale_map = {};
      this.lname_yAxis_map = {};
      this.lname_gYAxis_map = {};
      this.line_function_map = {};

      this.lname_color_map = {};
      this.layerNames = [];

      this.chartData = undefined;
      this.full_data = undefined;
      this.current_index = 0;
      //this.tooltip = d3.select(".probe_text").html("");

      this.input_date_time = this.my_probe_info.layer.time;
      console.log("input_date_time:" + this.input_date_time);
      let date_format = d3.timeFormat("%Y-%m-%d");

      //console.log("layerName:" + this.my_probe_info.layer.layerName);

      //3DIMG_L1C_DMP/VIS_ALBEDO,3DIMG_L1C_DMP/SWIR_ALBEDO,3DIMG_L1C_DMP/TIR1_BT
      if (this.my_probe_info.layer.layerName.includes(",")) {
        /* let indiv_layer_names = this.my_probe_info.layer.layerName.split(",");
        let ds_lname = indiv_layer_names[0].split("/");
        let ds = ds_lname[0];
        indiv_layer_names[0] = ds_lname[1];
        this.layerNames = indiv_layer_names.map(layer => ds + "/" + layer);*/ length;
        this.layerNames = this.my_probe_info.layer.layerName.split(",");
      } else {
        this.layerNames = [this.my_probe_info.layer.layerName];
      }
      //console.log("layernames:" + this.layerNames);

      let num_layers = this.layerNames.length;

      for (let indx = 0; indx < num_layers; indx++) {
        let metadata_url = this.createLayerDetailsUrl(
          this.my_probe_info.layer.url,
          this.layerNames[indx]
        );
        //console.log("metadata_url:" + metadata_url);
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        let metadata = metadata_arr[0];

        if (0 == indx) {
          let dates = this.getDateArray(metadata.datesWithData);
          this.date_fetch_map = dates.reduce((map, dt) => {
            map[date_format(dt)] = false;
            return map;
          }, {});
        }
        this.param_units.push(metadata.units);
      }

      for (let indx = 0; indx < num_layers; indx++) {
        let layer_arr = this.unit_layer_map[this.param_units[indx]];

        if (layer_arr === undefined) {
          layer_arr = [];
        }
        layer_arr.push(this.layerNames[indx]);
        this.unit_layer_map[this.param_units[indx]] = layer_arr;
      }

      for (let key of Object.keys(this.unit_layer_map)) {
        let unit = key;
        let layer_arr = this.unit_layer_map[key];
        let axis_caption = this.getAxisCaption(layer_arr, unit);
        this.unit_axiscaption_map[unit] = axis_caption;
      }
    },

    async getDateTime(probe_date) {
      let avail_dates = Object.keys(this.date_fetch_map).sort().reverse();

      let sel_indx = avail_dates.findIndex((dt) => {
        return dt == probe_date;
      });

      let ts_array = [];
      if (sel_indx != -1) {
        let ts_acc = 0;

        for (let indx = sel_indx; indx < avail_dates.length; indx++) {
          if (!this.date_fetch_map[avail_dates[indx]]) {
            let ts_url = this.createTimeStepsUrl(
              this.my_probe_info.layer.url,
              this.layerNames[0],
              avail_dates[indx]
            );
            let timesteps = this.getFromTSCache(ts_url);

            if (timesteps === undefined) {
              let fetched_ts_data = await this.fetchUrl([ts_url]);
              timesteps = fetched_ts_data[0].timesteps;

              let dt_tm_list = this.getLayerTimes(
                [avail_dates[indx]],
                [timesteps]
              );
              this.addToTSCache({ url: ts_url, val: dt_tm_list });
            } else {
              let xx_time_format = d3.utcFormat("%H:%M:%S.%LZ");
              timesteps = timesteps.map((ts) => xx_time_format(ts));
            }
            ts_acc += timesteps.length;
            let timesteps_with_dt = timesteps.map(
              (ts) => avail_dates[indx] + "T" + ts
            );
            this.date_fetch_map[avail_dates[indx]] = true;
            ts_array.push(...timesteps_with_dt);

            if (ts_acc > this.limit) {
              break;
            }
          }
        }

        if (ts_acc < this.limit) {
          for (let indx = sel_indx - 1; indx >= 0; indx--) {
            if (!this.date_fetch_map[avail_dates[indx]]) {
              let ts_url = this.createTimeStepUrl(avail_dates[indx]);
              let ts_data = await d3.json(ts_url);
              let timesteps = ts_data.timesteps;
              ts_acc += timesteps.length;
              let timesteps_with_dt = timesteps.map(
                (ts) => avail_dates[indx] + "T" + ts
              );
              this.date_fetch_map[avail_dates[indx]] = true;
              ts_array.push(...timesteps_with_dt);
              if (ts_acc > this.limit) {
                break;
              }
            }
          }
        }
      }

      if (ts_array.length) {
        ts_array = ts_array.sort();
        let [start_date, start_time] = ts_array[0].split("T");
        let [end_date, end_time] = ts_array[ts_array.length - 1].split("T");
        return [start_date, start_time, end_date, end_time];
      } else {
        return undefined;
      }
    },
    createProbeUrl(start_date, start_time, end_date, end_time) {
      let time_clause =
        start_date + "T" + start_time + "/" + end_date + "T" + end_time;
      return this.getFeatureInfoUrl(
        this.my_probe_info.layer,
        this.my_probe_info.map_bbox,
        this.my_probe_info.map_size,
        this.my_probe_info.scan_pix,
        "GetTimeseries",
        time_clause,
        "text/json"
      );
    },

    async getDataSlice(date_time) {
      let probe_date = date_time.split("T")[0];

      let values_to_be_copied = 0;
      if (!this.date_fetch_map[probe_date]) {
        let st_end_dt = await this.getDateTime(probe_date);
        if (st_end_dt !== undefined) {
          let [start_date, start_time, end_date, end_time] = st_end_dt;

          let probe_url = this.createProbeUrl(
            start_date,
            start_time,
            end_date,
            end_time
          );

          if (this.full_data === undefined) {
            this.full_data = await this.getData(probe_url);
            if (this.full_data.length) {
              values_to_be_copied = this.full_data[0].values.length;
            }
          } else {
            let new_data = await this.getData(probe_url);
            let num_layers = this.layerNames.length;
            for (let indx = 0; indx < num_layers; indx++) {
              this.full_data[indx].values = this.full_data[indx].values.concat(
                new_data[indx].values
              );
            }
            values_to_be_copied = new_data[0].values.length;
          }
        }
      }
      let slices = [];

      if (values_to_be_copied) {
        for (let layer of this.full_data) {
          let slice = {};
          slice.id = layer.id;

          slice.values = layer.values.slice(
            this.current_index,
            this.current_index + values_to_be_copied
          );
          slices.push(slice);
        }
        this.current_index += values_to_be_copied;
      }
      return slices;
    },
    getMinMax(data, layer_names) {
      let min_arr = [],
        max_arr = [];
      for (let d of data) {
        if (layer_names.findIndex((l) => l === d.id) > -1) {
          let min = d3.min(d.values, (d1) => d1.measurement);
          let max = d3.max(d.values, (d1) => d1.measurement);
          min_arr.push(min);
          max_arr.push(max);
        }
      }
      return [d3.min(min_arr), d3.max(max_arr)];
    },

    getTimeAxisFormat(tz_id) {
      //if (this.tz === "UTC") {
      if (tz_id === "UTC") {
        return d3.utcFormat("%d/%m %H:%M");
      } else {
        return d3.timeFormat("%d/%m %H:%M");
      }
    },
    zoomed() {
      let transform = d3.getEvent().transform;

      let xNewScale = transform.rescaleX(this.xScale);
      this.currentXScale = xNewScale;

      this.xAxis = this.xAxis.scale(xNewScale);
      this.gXAxis.call(this.xAxis);
      for (let lname of this.layerNames) {
        this.line_function_map[lname].x((d) => xNewScale(d.date));
      }
      this.updateData(xNewScale);
      let time_values = this.chartData[0].values.map((d) => d.date);
      let me = this;
      this.tooltip_rect.on("mousemove", function () {
        let evt = d3.mouse(this);
        me.mouseover(evt, time_values, xNewScale);
      });
      this.gLines.attr("d", (d) => this.line_function_map[d.id](d.values));
      this.svg.selectAll("circle").attr("cx", (d) => xNewScale(d.value.date));
    },

    async plot() {
      this.margin = { top: 5, right: 50, bottom: 30, left: 50 };
      if (this.layerNames.length == 1) {
        this.margin.right = 5;
      }

      if (this.width === 0) {
        let div_width = parseInt(this.$refs.chart.clientWidth);
        this.width = div_width - this.margin.left - this.margin.right;
      }
      if (this.height === 0) {
        let div_height = parseInt(window.innerHeight * 0.25);
        this.height = div_height - this.margin.top - this.margin.bottom;
      }

      this.chartData = await this.getDataSlice(this.input_date_time);
      if (!this.chartData.length) {
        return;
      }

      let non_nan_cnt = 0;
      for (let layer of this.chartData) {
        let non_nan_values = layer.values.filter(
          (value) => !isNaN(value.measurement),
          []
        );
        if (non_nan_values.length) {
          non_nan_cnt++;
        }
      }
      if (non_nan_cnt == 0) {
        return;
      }

      let time_values = this.chartData[0].values.map((d) => d.date);
      this.xScale = d3.scaleTime().range([0, this.width]);
      this.xScale.domain(d3.extent(time_values));

      this.pan = d3
        .zoom()
        .scaleExtent([1, 10])
        .translateExtent([
          [-1e100, 1],
          [1e100, 1],
        ])
        .on("zoom", () => {
          this.zoomed();
        });
      if (this.svg !== undefined) {
        this.svg.selectAll("*").remove();
      } else {
        this.svg = d3
          .selectAll(".tschart")
          .attr("width", this.width + this.margin.left + this.margin.right)
          .attr("height", this.height + this.margin.top + this.margin.bottom)
          .call(this.pan)
          .append("g")
          .attr(
            "transform",
            "translate(" + this.margin.left + "," + this.margin.top + ")"
          );
      }

      //console.log("svg:" + this.svg.nodes());

      /* this.svg = d3
        .select("div#chart")
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
         .attr(
          "viewBox",
          "-" +
            adj +
            " -" +
            adj +
            " " +
            (width + adj * 3) +
            " " +
            (height + adj * 3)
        )
        .attr("width", this.width + this.margin.left + this.margin.right)
        .attr("height", this.height + this.margin.top + this.margin.bottom)
       .style("padding", padding)
        .style("margin", margin)
        .classed("svg-content", true); */

      this.svg
        .append("clipPath")
        .attr("id", "axis-clip")
        .append("rect")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height);

      let cnt = 0;
      let point_colors = ["#f44336", "#4caf50", "#2196f3"];

      let num_y_ticks = parseInt(this.height / 25.0);
      //console.log("this.width:" + this.width);
      if (num_y_ticks <= 0) {
        num_y_ticks = 1;
      }

      for (let key of Object.keys(this.unit_layer_map)) {
        let unit = key;
        let layer_names = this.unit_layer_map[key];
        let [min, max] = this.getMinMax(this.chartData, layer_names);
        min = min - this.cushion;

        max = max + this.cushion;

        let yScale = d3
          .scaleLinear()
          .range([this.height, 0])
          .domain([min, max]);

        for (let lname of layer_names) {
          this.lname_yScale_map[lname] = yScale;
        }
        let axis_caption = this.unit_axiscaption_map[unit];

        let yAxis;
        let gYAxis;

        if (cnt % 2 == 0) {
          //console.log("left y axis");
          yAxis = d3
            .axisLeft()
            .scale(yScale)
            .ticks(num_y_ticks)
            .tickSize(-this.width, 0, 0);

          gYAxis = this.svg.append("g").attr("class", "leftygrid").call(yAxis);

          gYAxis
            .append("text")
            .attr(
              "transform",
              "translate(" +
                (-this.margin.left + 10) +
                "," +
                this.height / 2 +
                ") rotate(-90) "
            )
            .attr("stroke", "white")
            .style("text-anchor", "middle")
            .text(axis_caption);
        } else {
          //console.log("right y axis");
          yAxis = d3
            .axisRight()
            .scale(yScale)
            .ticks(num_y_ticks)
            .tickSize(-this.width, 0, 0);

          gYAxis = this.svg
            .append("g")
            .attr("class", "rightygrid")
            .attr("transform", "translate(" + this.width + ",0)")
            .call(yAxis);

          gYAxis
            .append("text")
            .attr(
              "transform",
              "translate(" +
                (this.margin.right - 10) +
                "," +
                this.height / 2 +
                ") rotate(90)"
            )
            .attr("stroke", "white")
            .style("text-anchor", "middle")
            .text(axis_caption);
        }

        for (let lname of layer_names) {
          this.lname_yAxis_map[lname] = yAxis;
          this.lname_gYAxis_map[lname] = gYAxis;
        }
        cnt++;
      }

      let time_axis_format = this.getTimeAxisFormat(this.sel_timezone.id);

      let num_x_ticks = parseInt(this.width / 100.0);
      if (num_x_ticks <= 0) {
        num_x_ticks = 1;
      }

      this.xAxis = d3
        .axisBottom()
        .scale(this.xScale)
        .ticks(num_x_ticks)
        .tickFormat(time_axis_format)
        .tickSize(-this.height);

      this.gXAxis = this.svg
        .append("g")
        .attr("class", "grid")
        .attr("stroke", "white")
        .attr("transform", "translate(0," + this.height + ")")
        .call(this.xAxis);

      this.gXAxis
        .append("text")
        .attr("transform", "translate(" + this.width / 2 + ",30)")
        .attr("stroke", "white")
        .style("text-anchor", "middle")
        .text("Time");

      for (let lname of this.layerNames) {
        this.line_function_map[lname] = d3
          .line() //line function
          .defined((d) => !isNaN(d.measurement))
          .x((d) => this.xScale(d.date))
          .y((d) => {
            //  console.log("d.measurement:" + d.measurement);
            return this.lname_yScale_map[lname](d.measurement);
          });
      }

      let id = 0;
      let me = this;

      const ids = function () {
        id = id % me.chartData.length;
        //console.log("id:" + id);
        return "line-" + id++;
      };

      let lines = this.svg
        .selectAll("lines")
        .data(this.chartData)
        .enter()
        .append("g");

      this.gLines = lines
        .append("path")
        .attr("clip-path", "url(#axis-clip)")
        .attr("class", ids)
        .attr("d", (d) => this.line_function_map[d.id](d.values));

      cnt = 0;

      for (let lname of this.layerNames) {
        this.lname_color_map[lname] = point_colors[cnt++];
      }

      let data_points = [];
      for (let layer of this.chartData) {
        let non_nan_points = layer.values.filter(
          (value) => !isNaN(value.measurement)
        );
        let layer_points = non_nan_points.map((value) => ({
          value,
          id: layer.id,
        }));

        data_points.push(...layer_points);
      }

      this.cursorLine = this.svg
        .append("g")
        .attr("class", "mouse-over-effects")
        .append("path")
        .attr("class", "cursorLine")
        .style("stroke", "white")
        .style("stroke-width", "1px")
        .style("opacity", "0");

      this.svg
        .selectAll("circle")
        .data(data_points)
        .enter()
        .append("circle")

        .attr("clip-path", "url(#axis-clip)")
        .attr("fill", (d) => this.lname_color_map[d.id])
        .attr("stroke", "none")

        .attr("cx", (d) => this.xScale(d.value.date))
        .attr("cy", (d) => this.lname_yScale_map[d.id](d.value.measurement))
        .attr("r", this.circle_radius);

      this.tooltip_rect = this.svg
        .append("rect")
        .attr("class", "overlay")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height)
        .on("mouseenter", function () {})
        .on("mouseleave", function () {
          me.probe_value = "Time:<br/>Value:";
          me.cursorLine.style("opacity", "0");
        })
        .on("mousemove", function () {
          let evt = d3.mouse(this);
          me.mouseover(evt, time_values, me.xScale);
        });
    },

    mouseover(evt, time_values, myxscale) {
      let mousedate = myxscale.invert(evt[0]);
      let sorted_time_values = time_values.sort((a, b) => a - b);
      let bisect_date = d3.bisector((d) => d);
      let indx = bisect_date.left(sorted_time_values, mousedate, 1);
      let d0 = sorted_time_values[indx - 1];
      let d1 = sorted_time_values[indx];
      let date = mousedate - d0 > d1 - mousedate ? d1 : d0;

      let click_value_format = this.getTimeAxisFormat(this.sel_timezone.id);
      let caption = "Time:" + click_value_format(date) + "<br/>";


      let me = this;
      let param_x_coord = myxscale(date);
      this.cursorLine.style("opacity", "1").attr("d", function () {
        var d = "M" + param_x_coord + "," + me.height;
        d += " " + param_x_coord + "," + 0;
        //console.log("d:" + d);
        return d;
      });

      let cnt = 0;

      for (let layer of this.chartData) {
        let layer_val = layer.values.find((val) => {
          return val.date.getTime() === date.getTime();
        });

        caption +=
          "<span style='color:" +
          this.lname_color_map[layer.id] +
          "'>" +
          layer.id.split("/")[1] +
          ": " +
          layer_val.measurement.toFixed(2) +
          " " +
          this.param_units[cnt++] +
          "</span> ";
      }
      this.probe_value = caption;
    },

    /* getXPosition(event_x, cushion) {
      let tt_width = parseInt(this.tooltip.style("width"), 10);
      let chart_width = parseInt(d3.select("svg").attr("width"), 10);
      let xpos = 0;
      if (event_x + tt_width > chart_width) {
        xpos = event_x - cushion - tt_width;
      } else {
        xpos = event_x + cushion;
      }
      return parseInt(xpos);
    }, */

    async updateData(xNewScale) {
      if (!this.updating) {
        this.updating = true;
        let chart_times = this.chartData[0].values.map((d) => d.date);
        let data_start_time = d3.min(chart_times);
        let data_end_time = d3.max(chart_times);
        let xscale_domain = xNewScale.domain();

        let axis_start_time = d3.min(xscale_domain);
        let axis_end_time = d3.max(xscale_domain);
        var new_data = [];
        let dateformat = d3.utcFormat("%Y-%m-%dT%H:%M:%S.%LZ");
        if (axis_start_time.getTime() < data_start_time.getTime()) {
          //Pan Left
          new_data = await this.getDataSlice(
            dateformat(axis_start_time.getTime())
          );
        } else if (axis_end_time.getTime() > data_end_time.getTime()) {
          //Pan Right
          new_data = await this.getDataSlice(
            dateformat(axis_end_time.getTime())
          );
        }

        if (new_data.length) {
          for (let i = 0; i < this.chartData.length; i++) {
            this.chartData[i].values = this.chartData[i].values.concat(
              new_data[i].values
            );
            this.chartData[i].values.sort((v1, v2) => {
              return v1.date < v2.date ? -1 : v1.date > v2.date ? 1 : 0;
            });
          }

          for (let unit of Object.keys(this.unit_layer_map)) {
            let layer_names = this.unit_layer_map[unit];
            let [min, max] = this.getMinMax(this.chartData, layer_names);
            min = min - this.cushion;

            max = max + this.cushion;
            let yNewScale = d3
              .scaleLinear()
              .range([this.height, 0])
              .domain([min, max]);

            for (let lname of layer_names) {
              this.lname_yAxis_map[lname] = this.lname_yAxis_map[lname].scale(
                yNewScale
              );
              this.lname_gYAxis_map[lname].call(this.lname_yAxis_map[lname]);
              this.line_function_map[lname].y((d) => yNewScale(d.measurement));
              this.lname_yScale_map[lname] = yNewScale;
            }
          }
          this.gLines.attr("d", (d) => this.line_function_map[d.id](d.values));

          this.updateCircles();
        }

        this.updating = false;
      }
    },
    updateCircles() {
      let data_points = [];
      for (let layer of this.chartData) {
        /* let layer_points = layer.values.map((value) => ({
          value,
          id: layer.id,
        })); */
        let non_nan_points = layer.values.filter(
          (value) => !isNaN(value.measurement)
        );
        let layer_points = non_nan_points.map((value) => ({
          value,
          id: layer.id,
        }));
        data_points.push(...layer_points);
      }

      let x = this.svg.selectAll("circle").data(data_points);

      let new_x = x.enter().append("circle");
      let time_values = this.chartData[0].values.map((d) => d.date);

      x.merge(new_x)
        .attr("clip-path", "url(#axis-clip)")
        .attr("fill", (d) => this.lname_color_map[d.id])
        .attr("stroke", "none")
        .attr("cx", (d) => this.currentXScale(d.value.date))
        .attr("cy", (d) => this.lname_yScale_map[d.id](d.value.measurement))
        .attr("r", this.circle_radius);
      let me = this;

      this.tooltip_rect.on("mousemove", function () {
        //console.log("mousemove");
        let evt = d3.mouse(this);
        me.mouseover(evt, time_values, me.currentXScale);
      });
    },
    /*showCaption(date, pos) {
      let click_value_format = this.getTimeAxisFormat();
      let caption = click_value_format(date) + "<br/>";
      let cnt = 0;
      let ycoords = [];
      for (let layer of this.chartData) {
        let layer_val = layer.values.find(val => {
          return val.date.getTime() === date.getTime();
        });

        console.log("top_y:" + this.lname_yScale_map[layer.id].domain()[1]);
        ycoords.push(this.lname_yScale_map[layer.id](layer_val.measurement));

        caption +=
          "<span style='color:" +
          this.lname_color_map[layer.id] +
          "'>" +
          layer.id.split("/")[1] +
          ": " +
          layer_val.measurement.toFixed(2) +
          " " +
          this.param_units[cnt++] +
          "</span><br/>";
      }

      console.log(
        "top:" + this.svg.style("top") + " left:" + this.svg.style("left")
      );
      console.log("ycoords:" + ycoords[0] + " " + pos[1]);

      this.tooltip.style("opacity", 1);
      this.tooltip
        .html(caption)
        .style("left", pos[0] + "px")
        .style("top", pos[1] + "px");
    }*/
  },
};
</script>
<style>
/* .probe_text {
  //background: rgba(0, 0, 0, 0);
} */
.overlay {
  fill: none;
  pointer-events: all;
}
.tooltip {
  font-family: Georgia;
  position: absolute;
  background: rgba(255, 255, 255, 255);
  box-shadow: 0 6px 8px rgba(52, 73, 94, 0.2), 0 1px 1px rgba(52, 73, 94, 0.1);
  z-index: 999;
  transition: all 0.2s ease-out;

  font-size: 12px;
}
.line {
  fill: none;
  stroke: red;
  stroke-width: 1px;
}

.grid .tick {
  opacity: 0.8;
}
.grid line {
  stroke: white;
  stroke-opacity: 0.5;
  shape-rendering: crispEdges;
}

.leftygrid .tick {
  opacity: 0.8;
  stroke: white;
}
.leftygrid line {
  stroke: white;
  stroke-opacity: 0.5;
  shape-rendering: crispEdges;
}

.rightygrid .tick {
  opacity: 0.8;
  stroke: white;
}
.rightygrid line {
  stroke: white;
  stroke-opacity: 0.5;
  stroke-dasharray: 10 5;
  shape-rendering: crispEdges;
}

path.line-0 {
  fill: none;
  stroke: #f44336;
}

path.line-1 {
  fill: none;
  stroke: #4caf50;
}

path.line-2 {
  fill: none;
  stroke: #2196f3;
}
</style>
