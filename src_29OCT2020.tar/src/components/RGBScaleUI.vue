<template>
  <div>
    <v-layout class="mx-0 px-0">
      <v-flex class="mt-3" xs1>
        <v-icon style="display:grid">mdi-arrow-expand-horizontal</v-icon>
      </v-flex>

      <v-flex class="mt-3" v-for="(range, indx) in layerinfo_list" :key="indx" xs2 sm2 md2 lg2>
        <v-text-field
          v-model="range.min"
          :color="range.color"
          hide-details
          :class="range.class"
          :label="range.band_name"
          type="number"
          style="width:70px"
        ></v-text-field>
        <v-text-field
          v-model="range.max"
          :class="range.class"
          hide-details
          :color="range.color"
          single-line
          type="number"
          style="width:70px"
        ></v-text-field>
      </v-flex>
      <v-flex class="mt-3" xs3>
        <v-btn small @click="changeRange('apply')">
          <v-icon small style="display:grid">mdi-check</v-icon>
        </v-btn>
        <v-btn small @click="changeRange('default')">
          <v-icon small style="display:grid">mdi-undo</v-icon>
        </v-btn>
        <v-btn class="text_transform_none" small @click="changeRange('actual')">Actual</v-btn>
      </v-flex>
    </v-layout>
    <br />
    <v-layout class="mx-0 px-0">
      <v-flex offset-xs1 xs10>
        <div v-for="url of palette_urls" :key="url" class="rgblegend">
          <img :src="url" />
        </div>
      </v-flex>
    </v-layout>
    <!-- <v-container fill-height fluide>
      <v-row justify="center">
        <v-col xs12>
          <v-img
            v-for="url of palette_urls"
            :key="url"
            :height="legend_size"
            :width="legend_size"
            :src="url"
          ></v-img>
        </v-col>
      </v-row>
    </v-container>-->
  </div>
</template>
<script>
import { mapGetters, mapMutations } from "vuex";
import { SLDHelpers, NCWMSHelper } from "../mixins/";
export default {
  computed: {
    ...mapGetters([
      "getRasterLayer",
      "getFromMetadataCache",
      "getFromMinMaxCache"
    ]),
    palette_urls: {
      get() {
        /* let raster_layer = this.getRasterLayer(this.layer_type);
        let encoded_sld = encodeURIComponent(raster_layer.extParams.sld_body);

        let out = `${raster_layer.url}&WIDTH=${this.legend_size}&HEIGHT=${this.legend_size}&request=GetLegendGraphic&SLD_BODY=${encoded_sld}`;
        //console.log("palette_url:" + raster_layer.extParams.sld_body);
        return out; */
        let raster_layer = this.getRasterLayer(this.layer_type);
        let isRGB = raster_layer.extParams.sld_body.includes(
          "RasterRGBSymbolizer"
        );

        let num_layers = this.layernames_list.length;
        let style_map = {};
        if (isRGB) {
          let rgb_styles = [
            "default/insat_reds",
            "default/insat_greens",
            "default/insat_blues"
          ];
          for (let indx = 0; indx < num_layers; indx++) {
            style_map[this.layernames_list[indx]] = rgb_styles[indx];
          }
        } else {
          style_map = this.getPaletteNames(raster_layer.extParams.sld_body);
        }
        let urls = [];

        for (let indx = 0; indx < num_layers; indx++) {
          let my_style = style_map[this.layernames_list[indx]];
          if (my_style !== undefined) {
            urls.push(
              `${raster_layer.url}` +
                "&request=GetLegendGraphic" +
                `&style=${style_map[this.layernames_list[indx]]}` +
                `&WIDTH=${this.legend_width}&HEIGHT=${this.legend_height}` +
                `&LAYERS=${this.layernames_list[indx]}` +
                `&COLORSCALERANGE=${this.my_rangeList[indx].min},${this.my_rangeList[indx].max}` +
                "&BELOWMINCOLOR=extend&ABOVEMAXCOLOR=extend&vertical=false"
            );
          }
        }
        return urls;
      }
    },
    numeric_range: {
      get() {
        let out_rng = [];

        for (let rng of this.layerinfo_list) {
          let min =
            typeof rng.min === "string" ? parseFloat(rng.min, 10) : rng.min;
          let max =
            typeof rng.max === "string" ? parseFloat(rng.max, 10) : rng.max;

          out_rng.push([min, max]);
        }
        return out_rng;
      }
    },
    layerinfo_list: {
      get() {
        let out_list = [];
        let num_layers = this.my_layernames_list.length;

        for (let i = 0; i < num_layers; i++) {
          let obj = {
            color: this.colors[i],
            class: "text-" + this.colors[i] + " mt-0 pt-0",
            min: this.my_rangeList[i].min,
            max: this.my_rangeList[i].max,
            band_name: this.my_layernames_list[i].split("/")[1]
          };
          //console.log("obj bandname:" + obj.band_name);
          out_list.push(obj);
        }
        return out_list;
      }
    }
  },
  mixins: [SLDHelpers, NCWMSHelper],
  name: "RGBScaleUI",
  data() {
    //console.log("layernames_list:" + typeof this.layernames_list);
    return {
      legend_size: 600,
      legend_height: 300,
      legend_width: 20,
      def_range_options: this.range_options,
      my_rangeList: this.range_list,
      my_layernames_list: this.layernames_list,
      colors: ["red", "green", "blue"]
    };
  },

  props: {
    range_list: {
      type: Array,
      required: true
    },
    range_options: {
      type: Array,
      required: true
    },
    layernames_list: {
      type: Array,
      required: true
    },
    layer_type: {
      type: String,
      required: true
    }
  },
  watch: {
    range_list: {
      handler(new_val) {
        this.my_rangeList = new_val;
      },
      deep: true
    },
    layernames_list: {
      handler(new_val) {
        this.my_layernames_list = new_val;
      },
      deep: true
    },
    range_options: {
      handler(new_val) {
        this.def_range_options = new_val;
      },
      deep: true
    }
  },

  methods: {
    ...mapMutations(["updateRaster", "addToMinMaxCache"]),

    async changeRange(option) {
      let raster_layer = this.getRasterLayer(this.layer_type);
      let layers = this.createArrayFromLayerName(raster_layer.layerName);
      console.log("layerName:" + raster_layer.layerName);
      console.log("In change Range layers:" + layers);
      let num_layers = layers.length;

      if (option !== "apply") {
        //Default or Actual
        let metadata_urls = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_urls);

        let scaleRanges = [];
        console.log("option:" + option);

        let layer_info = {
          url_prefix: raster_layer.url,
          sat_projection: raster_layer.projection,
          wms_version: raster_layer.version,
          layer_name: raster_layer.layerName
        };

        let elevation_values = [];

        let elev = raster_layer.extParams.elevation_value;
        elev = elev === undefined ? 0 : elev;
        for (let i = 0; i < num_layers; i++) {
          elevation_values.push(elev);
        }

        let layerRangeUrls = this.createLayerRangeUrl(
          layer_info,
          metadata_arr,
          raster_layer.time,
          elevation_values
        );
        console.log("layer_range_url:" + layerRangeUrls);

        if (option === "default") {
          let cnt = 0;
          for (let rng of this.def_range_options) {
            if (typeof rng === "boolean") {
              if (rng) {
                console.log("rng is true");
                let mm_response_arr = await this.fetchUrl([
                  layerRangeUrls[cnt]
                ]);
                this.addToMinMaxCache({
                  url: layerRangeUrls[cnt],
                  val: mm_response_arr[0]
                });

                scaleRanges.push([
                  mm_response_arr[0].min,
                  mm_response_arr[0].max
                ]);
              } else {
                console.log("rng is false");
                scaleRanges.push(metadata_arr[cnt].scaleRange);
              }
            } else if (rng instanceof Array) {
              console.log("rng is array");
              scaleRanges.push(rng);
            }
            cnt++;
          }
        } else {
          //Actual
          console.log("actual:");

          //console.log("layerRangeUrl:" + layerRangeUrl);
          let mm_response_arr = this.getFromMinMaxCache(layerRangeUrls);
          for (let url of layerRangeUrls) {
            console.log("layerRangeUrls:" + url);
          }
          console.log("mm_response.lenght:" + mm_response_arr.length);
          if (mm_response_arr.length != layerRangeUrls.length) {
            let not_foundlr_urls = [];
            for (let i = 0; i < layerRangeUrls.length; i++) {
              if (mm_response_arr[i] === undefined) {
                not_foundlr_urls.push(layerRangeUrls[i]);
              }
            }
            let found_mm_arr = await this.fetchUrl(not_foundlr_urls);
            let cnt = 0;
            for (let i = 0; i < layerRangeUrls.length; i++) {
              if (mm_response_arr[i] === undefined) {
                mm_response_arr[i] = found_mm_arr[cnt++];
              }
            }
            mm_response_arr = await this.fetchUrl(layerRangeUrls);

            this.addToMinMaxCache({
              url: layerRangeUrls,
              val: mm_response_arr
            });
          } else {
            console.log("Got minmax from cache");
          }
          for (let mm_response of mm_response_arr) {
            scaleRanges.push([mm_response.min, mm_response.max]);
          }
        }
        //console.log("num_layers:" + num_layers);
        for (let i = 0; i < num_layers; i++) {
          this.layerinfo_list[i].min = scaleRanges[i][0];
          this.layerinfo_list[i].max = scaleRanges[i][1];
        }
      }
      let sld_body = raster_layer.extParams.sld_body;
      let out_sld = this.updateSLD(sld_body, layers, this.numeric_range);

      console.log("out_sld:" + out_sld);
      let new_extParams = {};
      for (let key of Object.keys(raster_layer.extParams)) {
        new_extParams[key] = raster_layer.extParams[key];
      }
      new_extParams.sld_body = out_sld;
      this.updateRaster({
        layer_type: this.layer_type,
        items: {
          extParams: new_extParams
        }
      });
    }
  }
};
</script>
<style>
.text-green input {
  color: #4caf50 !important;
}
.text-red input {
  color: #f44336 !important;
}
.text-blue input {
  color: #2196f3 !important;
}
.text_transform_none {
  text-transform: none;
}
.rgblegend {
  height: auto;
  width: 100%;
  padding: 0px;
  margin: 0px;
}
</style>
