
<template>
  <v-dialog v-model="myshow" width="350">
    <v-card>
      <v-card-title>{{title}}</v-card-title>
      <v-card-text>
        <v-layout align-center>
          <v-flex xs3>Opacity</v-flex>

          <v-flex xs11>
            <v-slider hide-details class="pl-1" v-model="layer_opacity" min="0" max="10"></v-slider>
          </v-flex>
        </v-layout>
        <v-layout align-center>
          <v-flex xs3>Width</v-flex>
          <v-flex xs10>
            <v-slider hide-details class="pl-1" v-model="stroke_width" min="5" max="50"></v-slider>
          </v-flex>
        </v-layout>
        <v-layout align-center>
          <v-flex xs3>Color</v-flex>
        </v-layout>
        <v-layout align-center>
          <v-flex xs12>
            <v-color-picker class="mx0 px0" hide-mode-switch v-model="stroke_color"></v-color-picker>
          </v-flex>
        </v-layout>
      </v-card-text>
      <v-card-actions>
        <v-btn @click="closeDialog">Close</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import { XmlHelper, HexUtils } from "../mixins";
export default {
  mixins: [XmlHelper, HexUtils],
  data() {
    return {
      myshow: true
    };
  },

  computed: {
    ...mapState(["mobileView", "gridlines_color", "gridlines_width"]),
    ...mapGetters(["getAddlLayer"]),
    layer_opacity: {
      get() {
        if (this.isGridLines) {
          return Math.round(this.getAlphaFromRGBA(this.gridlines_color) * 10);
        } else {
          return Math.round(this.mylayer.opacity * 10);
        }
      },
      set(value) {
        if (this.isGridLines) {
          this.setGridLinesColor(
            this.convertHexToRGBA(this.stroke_color, value / 10.0)
          );
        } else {
          this.updateAdditionalLayer({
            cat: this.category,
            url: this.url,
            items: {
              opacity: value / 10.0
            }
          });
        }
      }
    },
    stroke_color: {
      get() {
        let color;
        if (this.isGridLines) {
          color = this.convertRGBAToHex(this.gridlines_color);
        } else {
          color = this.getVectorLayerColor(this.mylayer.extParams.sld_body);
        }
        console.log("color:" + color);
        return color;
      },
      set(new_color) {
        /* console.log("grid_lines:" + this.isGridLines); */
        if (this.isGridLines) {
          console.log("new_color:" + new_color);
          let out = this.convertHexToRGBA(new_color, this.layer_opacity / 10.0);
          /* console.log("set rgba color:" + out); */
          this.setGridLinesColor(out);
        } else {
          let out_sld = this.setVectorLayerAttribute(
            this.mylayer.extParams.sld_body,
            "stroke",
            new_color
          );
          this.updateAdditionalLayer({
            cat: this.category,
            url: this.url,
            items: {
              extParams: { sld_body: out_sld }
            }
          });
        }
      }
    },
    isGridLines: {
      get() {
        return this.url === "gridlines";
      }
    },
    stroke_width: {
      get() {
        if (this.isGridLines) {
          return this.gridlines_width * 10;
        } else {
          return Math.round(
            this.getVectorLayerWidth(this.mylayer.extParams.sld_body) * 10
          );
        }
      },
      set(new_value) {
        if (this.isGridLines) {
          this.setGridLinesWidth(new_value / 10.0);
        } else {
          let out_sld = this.setVectorLayerAttribute(
            this.mylayer.extParams.sld_body,
            "stroke-width",
            new_value / 10.0
          );
          this.updateAdditionalLayer({
            cat: this.category,
            url: this.url,
            items: {
              extParams: { sld_body: out_sld }
            }
          });
        }
      }
    },
    mylayer: {
      get() {
        return this.getAddlLayer({ cat: this.category, url: this.url });
      }
    }
  },
  watch: {
    show(new_val) {
      this.myshow = new_val;
    }
  },
  props: {
    category: {
      type: String,
      required: true
    },
    title: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    },
    show: {
      type: Boolean,
      required: true
    }
  },
  created() {
    this.myshow = this.show;
  },
  methods: {
    ...mapMutations([
      "updateAdditionalLayer",
      "setGridLinesWidth",
      "setGridLinesColor"
    ]),
    closeDialog() {
      this.myshow = false;
      this.$emit("visibilityChanged", false);
    }
  }
};
</script>