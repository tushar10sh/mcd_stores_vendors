<template>
  <vl-map
    ref="map"
    :load-tiles-while-animating="true"
    :load-tiles-while-interacting="true"
    @mounted="onMapMounted"
  >
    <vl-view
      :zoom.sync="view.zoom"
      :center.sync="view.center"
      :rotation.sync="view.rotation"
      :projection="view.projection"
      :minZoom="view.minZoom"
    ></vl-view>
    <!-- @change:center="viewChanged($event)"
      @change:resolution="viewChanged($event)"
      @change:rotation="viewChanged($event)"
    @change="viewChanged($event)"-->
    <NCWMSLayersList
      v-if="model_proc_prods !== undefined"
      :proc_prods="model_proc_prods"
      :layer_offset="model_layer_offset"
      layer_type="model_raster"
    />
    <NCWMSLayersList
      v-if="sat_proc_prods !== undefined"
      :proc_prods="sat_proc_prods"
      :layer_offset="sat_layer_offset"
      layer_type="satellite_raster"
    />

    <NCWMSLayersList
      v-if="radial_prods !== undefined"
      :proc_prods="radial_prods"
      :layer_offset="radial_layer_offset"
      layer_type="radial_raster"
    />

    <AnimationLayer />

    <RapidVectorLayersList
      v-if="vector_layer_config !== undefined"
      :layers_config="vector_layer_config"
      category="vector"
    />
    <RapidVectorLayersList
      v-if="base_layer_config !== undefined"
      :layers_config="base_layer_config"
      category="basemap"
    />

    <vl-graticule v-if="gridlines_visible" :show-labels="gridlines_visible">
      <vl-style-stroke slot="stroke" :color="gridlines_color" :width="gridlines_width" />
    </vl-graticule>
    <vl-layer-vector id="probe-vector" v-if="probe_info.id !== 'none'" :z-index="probe_z_index">
      <vl-source-vector ident="draw-target" :features.sync="singleFeatureArray"></vl-source-vector>
    </vl-layer-vector>
    <vl-interaction-draw
      v-if="probe_info.id !== 'none'"
      source="draw-target"
      @drawstart="probeStart($event)"
      @drawend="probeEnd($event)"
      :type="probe_info.id"
    >
      <vl-overlay
        v-if="singleFeatureArray[0] !== undefined && point_probe_visibility"
        class="feature-popup"
        :position="findPointOnSurface(singleFeatureArray[0].geometry)"
        :auto-pan="true"
        :auto-pan-animation="{ duration: 300 }"
      >
        <template slot-scope="popup">
          <v-card>
            <v-card-title>
              Point Probe
              <v-spacer />
              <v-icon @click="point_probe_visibility = false">mdi-close</v-icon>
            </v-card-title>

            <v-card-text>
              Lat:
              {{ popup.position[1].toFixed(2) }}
              Lon:
              {{ popup.position[0].toFixed(2) }}
              <br />

              <span v-html="variable_feature_info"></span>
            </v-card-text>
          </v-card>
        </template>
      </vl-overlay>
    </vl-interaction-draw>
  </vl-map>
</template>

<script>
//import "ol/ol.css";

import { mapMutations, mapGetters, mapState } from "vuex";
import {
  NCWMSHelper,
  XmlHelper,
  FetchHelper,
  OLHelpers,
  LocalStorageHelper
} from "../mixins/";

import NCWMSLayersList from "./NCWMSLayersList";
import AnimationLayer from "./AnimationLayer";
import RapidVectorLayersList from "./RapidVectorLayersList.vue";

//VueLayer Imports
import Vue from "vue";
import Map from "vuelayers/lib/map";
import { findPointOnSurface } from "vuelayers/lib/ol-ext";
import VectorLayer from "vuelayers/lib/vector-layer";
import VectorSource from "vuelayers/lib/vector-source";
import DrawInteraction from "vuelayers/lib/draw-interaction";
import Overlay from "vuelayers/lib/overlay";
import Graticule from "vuelayers/lib/graticule";
import StrokeStyle from "vuelayers/lib/stroke-style";

//OL Imports

import ScaleLine from "ol/control/ScaleLine";
import MousePosition from "ol/control/MousePosition";
import { createStringXY } from "ol/coordinate";

Vue.use(Map);
Vue.use(VectorLayer);
Vue.use(VectorSource);
Vue.use(DrawInteraction);
Vue.use(Overlay);
Vue.use(Graticule);
Vue.use(StrokeStyle);

export default {
  props: {
    projection_name: {
      type: String,
      required: true
    }
  },
  mixins: [NCWMSHelper, FetchHelper, XmlHelper, OLHelpers, LocalStorageHelper],
  data() {
    return {
      layer_opacity: 0,
      probe_z_index: 14,
      radial_layer_offset: 11,
      model_layer_offset: 9,
      sat_layer_offset: 7,

      view: {
        zoom: 4,
        minZoom: 3,
        drawer: null,
        center: [76, 23],
        rotation: 0,
        projection: "EPSG:4326"
      },
      open_tab: false,
      drawnFeatures: [],
      point_probe_visibility: false,
      variable_feature_info: "",
      point_responses_map: undefined,

      vector_layer_config: undefined,
      base_layer_config: undefined,
      sat_proc_prods: undefined,
      model_proc_prods: undefined,
      radial_prods: undefined
    };
  },

  components: {
    RapidVectorLayersList,
    NCWMSLayersList,
    AnimationLayer
    //ProbeControl

    //    LayerListDialog,
    //LayerConfigurationUI
  },
  computed: {
    ...mapGetters(["isLayerListOpen", "getFromMetadataCache"]),
    ...mapState([
      "probe_info",
      "gridlines_visible",
      "gridlines_color",
      "gridlines_width"
    ]),

    singleFeatureArray: {
      get() {
        //console.log("drawnFeatures:" + this.drawnFeatures.length);
        return this.drawnFeatures;
      },
      set(feature) {
        //console.log("feature:" + feature.length);
        this.drawnFeatures = feature.slice(feature.length - 1, feature.length);
      }
    }
  },

  watch: {
    probe_info: {
      deep: true,
      handler(new_probe_info) {
        console.log(
          "In watch RapidMap:" +
            new_probe_info.caption +
            " " +
            new_probe_info.id
        );
        if (new_probe_info.caption === "none") {
          this.drawnFeatures = [];
        }

        this.point_probe_visibility =
          this.singleFeatureArray[0] !== undefined &&
          new_probe_info.caption === "point" &&
          new_probe_info.location.length > 0;

        //console.log("this.singleFeatureArray:" + this.singleFeatureArray[0]);
        //console.log("probe_info:" + this.probe_info.id);
        if (this.singleFeatureArray[0] !== undefined) {
          if (new_probe_info.caption === "point") {
            let probe_info_pt = this.getProbeInfoTS(new_probe_info.location);
            probe_info_pt.layer = new_probe_info.layer;
            this.updatePointProbe(probe_info_pt);
          } else if (
            new_probe_info.caption === "timeseries" ||
            new_probe_info.caption === "verticalprofile" ||
            new_probe_info.caption === "skewt"
          ) {
            let probe_info_ts = this.getProbeInfoTS(new_probe_info.location);
            this.updateProbeInfo(probe_info_ts);
          }
        }
      }
    }
  },

  created() {
    this.fetchSatProducts();
    this.fetchModelProducts();
    this.fetchRadialProducts();
    this.fetchVectorLayers();
    this.fetchBaseLayers();
  },

  methods: {
    lonlabelFormatter(lon) {
      let frmted_lon = lon.toFixed(3);

      frmted_lon += lon < 0 ? "W" : lon > 0 ? "E" : "";
      return frmted_lon;
    },

    latlabelFormatter(lat) {
      let frmted_lat = lat.toFixed(3);

      frmted_lat += lat < 0 ? "W" : lat > 0 ? "E" : "";
      return frmted_lat;
    },

    async fetchRadialProducts() {
      let fetched_prods = await this.fetchUrl(["jsons/radial_prods.json"]);
      this.addJSONObjToLocalStorage("radial_raster", fetched_prods[0]);
      this.radial_prods = fetched_prods[0];
    },
    async fetchSatProducts() {
      let fetched_prods = await this.fetchUrl(["jsons/proc_prods.json"]);
      this.addJSONObjToLocalStorage("satellite_raster", fetched_prods[0]);
      this.sat_proc_prods = fetched_prods[0];
    },
    async fetchModelProducts() {
      let fetched_model_prods = await this.fetchUrl(["jsons/model_prods.json"]);
      this.addJSONObjToLocalStorage("model_raster", fetched_model_prods[0]);
      this.model_proc_prods = fetched_model_prods[0];
    },
    async fetchVectorLayers() {
      let fetched_vec_config = await this.fetchUrl([
        "jsons/vector_layers.json"
      ]);
      this.vector_layer_config = fetched_vec_config[0];
      this.addJSONObjToLocalStorage("vector", this.vector_layer_config);
    },
    async fetchBaseLayers() {
      let fetched_baselayer_config = await this.fetchUrl([
        "jsons/basemap_layers.json"
      ]);
      this.base_layer_config = fetched_baselayer_config[0];
      this.addJSONObjToLocalStorage("basemap", this.base_layer_config);
    },

    onMapMounted() {
      let ol_map = this.$refs.map.$map;
      ol_map.getControls().extend([
        new ScaleLine(),
        new MousePosition({
          coordinateFormat: createStringXY(3)
        })
      ]);
    },
    async updatePointProbe(new_probe_info) {
      if (new_probe_info.location.length > 0) {
        await this.fetchPointInfo(new_probe_info);
        this.formatOutput(new_probe_info);
      }
    },
    getProbeInfoTS(coordinates) {
      let updated_probe_info = {};
      let ol_map = this.$refs.map.$map;
      let map_size = ol_map.getSize(); //First is width, second is height
      let map_bbox = ol_map.getView().calculateExtent(map_size);
      let scan_pix = ol_map.getPixelFromCoordinate(coordinates);
      scan_pix[0] = Math.round(scan_pix[0]);
      scan_pix[1] = Math.round(scan_pix[1]);

      updated_probe_info.map_bbox = map_bbox;
      updated_probe_info.scan_pix = scan_pix;
      updated_probe_info.map_size = map_size;
      updated_probe_info.location = coordinates;
      return updated_probe_info;
    },
    findPointOnSurface,
    async fetchPointInfo(my_probe_info) {
      console.log("scan_pix:" + my_probe_info.scan_pix);
      console.log("map_bbox:" + my_probe_info.map_bbox);
      console.log("map_size:" + my_probe_info.map_size);
      let point_probe_url = this.getFeatureInfoUrl(
        my_probe_info.layer,
        my_probe_info.map_bbox,
        my_probe_info.map_size,
        my_probe_info.scan_pix,
        "GetFeatureInfo",
        my_probe_info.layer.time,
        "text/xml"
      );
      //console.log("point_probe_url:" + point_probe_url);
      let response_xml = await this.fetchUrlXml(point_probe_url);
      //console.log("response_xml:" + response_xml);

      this.point_responses_map = this.parsePointProbeResponseMap(response_xml);
    },

    formatOutput(my_probe_info) {
      let raster_layer = my_probe_info.layer;
      let metadata_url = this.createLayerDetailsUrl(
        raster_layer.url,
        raster_layer.layerName
      );

      let metadata_arr = this.getFromMetadataCache(metadata_url);
      let band_names = [];
      let all_from_same_ds = true;
      if (raster_layer.layerName.includes(",")) {
        band_names = this.createArrayFromLayerName(raster_layer.layerName);
        //console.log("band_names:" + band_names.length);
        let ds_name = band_names[0].split("/")[0];

        //console.log("ds_name:" + typeof ds_name);
        for (let indx = 1; indx < band_names.length; indx++) {
          if (!band_names[indx].startsWith(ds_name)) {
            all_from_same_ds = false;
            break;
          }
        }
      } else {
        band_names = [raster_layer.layerName];
      }
      let band_colors = ["#f44336", "#4caf50", "#2196f3"];

      let num_bands = band_names.length;
      let isRGB = Object.keys(this.point_responses_map).length === 3;
      let output = isRGB ? "<div>" : "<span>";

      for (let i = 0; i < num_bands; i++) {
        let value = "";

        if (band_names[i].endsWith("-group")) {
          let grp_layers = this.getGroupLayerComponents(band_names[i]);
          value += "(";
          for (let indx = 0; indx < grp_layers.length; indx++) {
            let ind_layer = grp_layers[indx];
            let band_value = this.point_responses_map[ind_layer];
            value +=
              band_value === undefined
                ? "N.A"
                : band_value + " " + metadata_arr[i].units;
            if (indx != grp_layers.length - 1) {
              value += ",";
            }
          }
          value += ")";
        } else {
          let band_value = this.point_responses_map[band_names[i]];
          value =
            band_value === undefined
              ? "N.A"
              : band_value + " " + metadata_arr[i].units;
        }

        output += isRGB ? "<span style='color:" + band_colors[i] + "'>" : "";
        output +=
          (all_from_same_ds ? band_names[i].split("/")[1] : band_names[i]) +
          ": " +
          value;
        output += isRGB ? "</span>" : "";
        if (i != num_bands - 1) {
          output += "<br/>";
        }

        output += isRGB ? "</div>" : "</span>";

        this.variable_feature_info = output;
        //console.log("Going for updateProbeInfo 2");
        this.updateProbeInfo(my_probe_info);
      }
    },
    getGroupLayerComponents(band_group) {
      //band_group=> 3DIMG_L2P_IRW/UCOMP:VCOMP-group
      let ds_lname = band_group.split("/");
      let ds = ds_lname[0]; //3DIMG_L2P_IRW
      let only_grpname = ds_lname[1]; //UCOMP:VCOMP=group
      let grp_lnames = only_grpname.substr(0, only_grpname.indexOf("-group")); //UCOMP:VCOMP
      let ind_layers = grp_lnames.split(":"); //UCOMP,VCOMP
      return ind_layers.map(l => ds + "/" + l);
    },

    ...mapMutations([
      "setLayerListOpen",
      "updateProbeInfo",
      "updateDistanceProbe",
      "updateAreaProbe"
    ]),
    async openLayersControl() {
      //console.log("is.isLayerListOpen:" + this.isLayerListOpen);
      this.setLayerListOpen(!this.isLayerListOpen);
    },
    probeEnd(evt) {
      let geom = evt.feature.getGeometry();
      //console.log("probe_visibilty:" + this.probe_info.id);
      this.calculateAreaDist(geom);
    },
    calculateAreaDist(geom) {
      let proj = this.$refs.map.$map.getView().getProjection();
      if (this.probe_info.caption === "distance") {
        this.updateDistanceProbe(this.formatLength(geom, proj));
      } else if (this.probe_info.caption === "area") {
        this.updateAreaProbe(this.formatArea(geom, proj));
      }
    },

    async probeStart(evt) {
      //console.log("In probeStart " + this.probe_info.caption);
      let coordinates = evt.feature.getGeometry().getCoordinates();
      if (this.probe_info.caption === "point") {
        this.point_probe_visibility = true;
        let probe_info_ts = this.getProbeInfoTS(coordinates);
        probe_info_ts.layer = this.probe_info.layer;
        await this.fetchPointInfo(probe_info_ts);
        this.formatOutput(probe_info_ts);
      } else if (
        this.probe_info.caption === "timeseries" ||
        this.probe_info.caption === "verticalprofile" ||
        this.probe_info.caption === "skewt"
      ) {
        let probe_info_ts = this.getProbeInfoTS(coordinates);
        //console.log("Going for updateProbeInfo 3");
        this.updateProbeInfo(probe_info_ts);
      } else if (
        this.probe_info.caption === "distance" ||
        this.probe_info.caption === "area"
      ) {
        let me = this;
        evt.feature.getGeometry().on("change", function(evt1) {
          me.calculateAreaDist(evt1.target);
        });
      }
    }
  }
};
</script>
<style>
#layers_panel {
  position: absolute;
  bottom: 0px;
  left: 0px;
  z-index: 9999;
  /* width: 100%; */
}
@media only screen and (max-device-width: 960px) {
  .ol-attribution {
    bottom: 10vh;
  }

  .ol-scale-line {
    bottom: 10vh;
  }
}
.ol-mouse-position {
  color: white;
}

/* #header {
  background-color: rgb(50, 50, 50);
  position: absolute;
  top: 0px;
  left: calc(50vw-10px);
  z-index: 9999;
} */
.feature-popup {
  position: absolute;
  left: -50px;
  bottom: 12px;
  width: 20em;
  max-width: none;
}
.feature-popup:after,
.feature-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.feature-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}
feature-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}
.card-content {
  max-height: 20em;
  overflow: auto;
}
.content {
  word-break: break-all;
}
</style>
