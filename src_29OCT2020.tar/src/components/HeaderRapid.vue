<template>
  <div>
          <!-- <v-btn @click.stop="navbar_open=!navbar_open">
        <v-icon dark>mdi-layers</v-icon>
      </v-btn>-->

    <v-app-bar app dense dark elevation="10">

      <v-app-bar-nav-icon @click.stop="navbar_open = !navbar_open" />
      <v-container fluid>
        <v-col cols="12">
          <v-row :align="alignment" :justify="justify">
            <v-avatar :tile="tile_logo">
              <img src="imgs/isro-logo.gif" />
            </v-avatar>

            <v-avatar :tile="tile_logo">
              <img src="imgs/Rapid_logo.png" />
            </v-avatar>

            <v-avatar :tile="tile_logo">
              <img src="imgs/imd-logo.png" />
            </v-avatar>
          </v-row>
        </v-col>
      </v-container>
    </v-app-bar>

    <v-navigation-drawer
      v-if="!mobileView"
      width="30%"
      v-model="navbar_open"
      absolute
      dark  
      :permanent="perm"
    >
     
      <LayerConfigurationUI />
     
    </v-navigation-drawer>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
export default {
  name: "HeaderRapid",
  methods: {
    ...mapMutations(["setLayerListOpen"])
  },

  computed: {
    ...mapState(["layerlist_open", "mobileView"]),
    navbar_open: {
      get() {
        return this.layerlist_open;
      },
      set(value) {
        this.setLayerListOpen(value);
      }
    }
  },
  components: {
    LayerConfigurationUI: () => import("./LayerConfigurationUI")
  },
  data() {
    return {
      perm: false,
      tile_logo: true,
      alignment: "center",
      justify: "center"
    };
  }
};
</script>
