<!-- <template>
  <div id="map-container">
    <vl-map
      :load-tiles-while-animating="true"
      :load-tiles-while-interacting="true"
      data-projection="EPSG:4326"
    >
      <vl-view
        :zoom.sync="view.zoom"
        :center.sync="view.center"
        :rotation.sync="view.rotation"
        :projection="view.projection"
      ></vl-view>

      <vl-layer-tile v-for="layer in layers" :key="layer.url+'_'+layer.layerName">
        <vl-source-wms
          :attributions="layer.attribution"
          :url="layer.url"
          :layers="layer.layerName"
          :format="layer.format"
          :styleName="layer.styleName"
          :projection="layer.projection"
        ></vl-source-wms>
      </vl-layer-tile>
    </vl-map>
  </div>
</template> -->

<template>
  <!-- <v-container class="fill-height" fluid> -->
  <div id="map-container">
    <RapidMap projection_name="EPSG:4326" />

    <!-- <v-btn absolute dark fab bottom left color="primary" @click="open_tab=!open_tab">
      <v-icon>mdi-layers</v-icon>
    </v-btn>
    <LayerConfigurationUI :open_state="open_tab" />-->
    <!-- <div id="layers_panel">
      <v-btn
        id="layers_btn"
        small
        color="primary"
        top
        right
        fixed
        @click.stop="setLayerListOpen(true);"
      >
        <v-icon dark>mdi-layers</v-icon>
      </v-btn>


    </div>
    -->
    <!--  <vl-map
      :load-tiles-while-animating="true"
      :load-tiles-while-interacting="true"
      data-projection="EPSG:4326"
    >
      
      <vl-view
        :zoom.sync="view.zoom"
        :center.sync="view.center"
        :rotation.sync="view.rotation"
        :projection="view.projection"
      ></vl-view>

      <NCWMSLayersList />
      <RapidVectorLayers />
      <LayerListDialog id="layers_panel"/>
      
    </vl-map>
    
    -->
    <!-- </v-container> -->
  </div>
</template>
<script>
/* import NCWMSLayersList from "./NCWMSLayersList.vue";
import RapidVectorLayers from "./RapidVectorLayers.vue";
*/
//import RapidMap from "./RapidMap.vue";
/* import BottomSheet from "./BottomSheet.vue"; */
/* import { mapMutations, mapGetters } from "vuex";

import LayerListDialog from "./LayerListDialog.vue"; */
export default {
  name: "BodyRapid",

  /*  computed: {
    ...mapGetters(["isLayerListOpen", "getProcProds"])
  },
  methods: {
    ...mapMutations(["setLayerListOpen"])
  }, */
  components: {
    RapidMap: () => import("./RapidMap.vue"),
    //LayerConfigurationUI: () => import("./LayerConfigurationUI.vue")
  },
  data() {
    return {
      open_tab: false,
      /* view: {
        zoom: 2,
        drawer: null,
        center: [76, 23],
        rotation: 0,
        projection: "EPSG:4326"
      },
      model1: "tab-0",
      text: "Ghansham",
      tabs: [
        {
          title: "sat",
          text: "Satellite Data Layers"
        },
        {
          title: "vectors",
          text: "Vector Layers"
        },
        {
          title: "baselayers",
          text: "Base Layers"
        }
      ] */
      //sat_layers: [],
      /* sat_layers: [
        {
          projection: "EPSG:4326",
          url:
            "http://rapid.imd.gov.in/ncWMS2/wms?version=1.3.0&DATASET=3DIMG_L2B_OLR",
          styleName: "default",
          layerName: "OLR",
          format: "image/png",
          attribution: "3DIMG_OLR"
        },
      ],
      vector_layers: [
        {
          projection: "EPSG:4326",
          url: "http://103.215.208.83/cgi-bin/mapserv?map=boundary_3857.map",
          styleName: "default",
          layerName: "worldcoastline,,state_boundary_2",
          format: "image/png",
          attribution: "WorldCoastline"
        }
      ] */
    };
  },
};
</script>

<style scoped>
html,
body,
#map-container {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;

  right: 0px;
  width: 100%;
  height: 100%;
  height: 100%;

  margin: 0;
  padding: 0;
  display: block;
  background-color: black;
}
</style>
<!--height: calc(var(--vh, 1vh) * 100);-->
