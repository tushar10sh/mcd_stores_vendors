<template>
  <div>
    <v-card style=" overflow-y:auto; overflow-x:hidden;" :max-height="componentHeight">
      <v-btn v-show="mobileView" @click="changeWindowSize" icon small>
        <v-icon v-if="maximized">mdi-window-restore</v-icon>
        <v-icon v-else>mdi-window-maximize</v-icon>
      </v-btn>

      <v-layout ref="sktchart" id="sktchart">
        <v-flex xs12>
          <svg class="sktchart" />
        </v-flex>
      </v-layout>
      <br />

      <div v-show="my_probe_info !== undefined && my_probe_info.location.length > 0">
        <v-layout>
          <v-flex xs6>P_lcl: {{P_lcl.toFixed(2)}} hPa</v-flex>
          <v-flex xs6>T_lcl: {{T_lcl.toFixed(2)}} °C</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>P_lfc: {{P_lfc.toFixed(2)}} hPa</v-flex>
          <v-flex xs6>P_el: {{P_el.toFixed(2)}} hPa</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>CAPE: {{CAPE.toFixed(2)}} J/Kg</v-flex>
          <v-flex xs6>CIN: {{CIN.toFixed(2)}} J/Kg</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>TConv: {{tconv.toFixed(2)}}°C</v-flex>
          <v-flex xs6>CCL: {{pccl.toFixed(2)}} hPa</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>P_sfc: {{P_sfc.toFixed(2)}} hPa</v-flex>
          <v-flex xs6>Td: {{Td.toFixed(2)}} °C</v-flex>
        </v-layout>
        <v-layout v-if="skt_anc_layers['surf_vars'] !== undefined">
          <v-flex
            v-if="skt_anc_layers['surf_vars']['tpw'] !== undefined"
            xs6
          >TPW: {{tpw.toFixed()}} mm</v-flex>
          <v-flex
            v-if="skt_anc_layers['surf_vars']['li'] !== undefined"
            xs6
          >LI: {{li.toFixed(2)}} °C</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>KI: {{ki.toFixed(2)}} °C</v-flex>
          <v-flex xs6>TT: {{tt.toFixed(2)}} °C</v-flex>
        </v-layout>
        <v-layout>
          <v-flex xs6>SI: {{si.toFixed(2)}} °C</v-flex>
        </v-layout>
      </div>
    </v-card>
  </div>
</template>

<script>
import d3 from "../plugins/D3Importer.js";
import {
  thermodynamic,
  interpolation,
  NCWMSHelper,
  XmlHelper,
} from "../mixins/";
import { mapState } from "vuex";
export default {
  name: "SkewT",
  mixins: [thermodynamic, interpolation, NCWMSHelper, XmlHelper],
  computed: {
    ...mapState(["mobileView"]),
    componentHeight() {      
      return this.mobileView ? (this.maximized ? "70vh" : "20vh") : "100vh";
    },
  },
  data() {
    return {
      maximized: false,
      temp_layerName: "",
      wv_layerName: "",
      dewpt_layerName: "",
      my_probe_info: undefined,
      margin: undefined,
      width: 0,
      height: 0,
      temp_values: [],
      pressure_values: [],
      dewpt_values: [],
      topp: 100,
      basep: 1050,
      plines: [1000, 850, 700, 500, 300, 200, 100],
      pticks: [950, 900, 800, 750, 650, 600, 550, 450, 400, 350, 250, 150],
      deg2rad: Math.PI / 180.0,
      svg: undefined,
      x: undefined,
      y: undefined,
      tan: 0,
      xAxis: undefined,
      yAxis: undefined,
      yAxis2: undefined,
      yAxisRight: undefined,
      gYAxis_right: undefined,
      xAxisTop: undefined,
      bot_xaxis_min: -50,
      bot_xaxis_max: 50,
      t_dp_hgt_prof: [],

      top_xaxis_min: -120,
      top_xaxis_max: -20,
      bisectTemp: undefined,
      circle_radius: 4,
      query_startplevel: 100,
      query_endplevel: 1000,
      temp_probe: undefined,
      dewpt_probe: undefined,
      gph_probe: undefined,

      //Derived Parameters
      P_lcl: 0,
      T_lcl: 0,
      P_lfc: 0,
      P_el: 0,
      CAPE: 0,
      CIN: 0,
      tconv: 0,
      pccl: 0,
      P_sfc: 0,
      Td: 0,
      tpw: 0,
      li: 0,
      ki: 0,
      tt: 0,
      si: 0,
    };
  },

  props: {
    skt_probe_info: {
      type: Object,
      required: false,
    },

    skt_anc_layers: {
      type: Object,
      required: false,
    },
  },

  watch: {
    skt_probe_info: {
      handler(new_val) {
        //console.log("Got new value for skt_probe_info in skewT");
        if (new_val !== undefined && new_val.location.length > 0) {
          if (
            this.my_probe_info === undefined ||
            this.isVPProbeInfoChanged(this.my_probe_info, new_val)
          ) {
            this.wv_layerName = this.skt_anc_layers["wv_var"];
            this.dewpt_layerName = this.skt_anc_layers["dewpt_var"];
            this.height_layerName = this.skt_anc_layers["height_var"];

            if (
              (this.wv_layerName !== undefined ||
                this.dewpt_layerName !== undefined) &&
              this.height_layerName !== undefined
            ) {
              this.my_probe_info = this.deepCopy(new_val);

              this.initialize();
              this.plot();
            }
          }
        }
      },
      deep: true,
    },
  },
  mounted() {
    //console.log("In skewT mounted");
    if (this.skt_probe_info !== undefined) {
      this.my_probe_info = this.deepCopy(this.skt_probe_info);
      this.wv_layerName = this.skt_anc_layers["wv_var"];
      this.dewpt_layerName = this.skt_anc_layers["dewpt_var"];
      this.height_layerName = this.skt_anc_layers["height_var"];
      this.initialize();
      this.plot();
    }
  },
  methods: {
    changeWindowSize() {
      this.maximized = !this.maximized;
    },

    initialize() {
      this.temp_layerName = this.my_probe_info.layer.layerName;
      this.tan = Math.tan(55 * this.deg2rad);
      this.bisectTemp = d3.bisector(function (d) {
        return d.press;
      }).left;

      this.margin = { top: 50, right: 50, bottom: 50, left: 50 };
      //this.margin = { top: 20, right: 50, bottom: 20, left: 40 };
      /*this.width = 700 - this.margin.left - this.margin.right;
      this.height = 700 - this.margin.top - this.margin.bottom; */

      //this.margin = { top: 20, right: 40, bottom: 25, left: 40 };

      //if (this.width === 0) {
      let div_width = parseInt(this.$refs.sktchart.clientWidth);

      this.width = div_width - this.margin.left - this.margin.right;
      // }
      // if (this.height === 0) {
      /* let div_height = parseInt(window.innerHeight * 0.25);
      console.log("div_width:" + div_width + " div_height:" + div_height); */
      this.height = div_width - this.margin.top - this.margin.bottom;

      //}
      //console.log("width:" + this.width + " height:" + this.height);
    },
    calculateDewPt(wv_values) {
      let num_vals = this.temp_values.length;
      let q1, p1, e, td;
      this.dewpt_values = [];
      for (let indx = 0; indx < num_vals; indx++) {
        if (!isNaN(wv_values[indx]) && wv_values[indx] > 0) {
          q1 = wv_values[indx] * 0.001; //Mixing Ratio in Kg/Kg
          p1 = this.pressure_values[indx] * 0.1; //Pressure in KPa
          e = (p1 * q1) / (0.622 + q1);
          td = (116.9 + 237.3 * Math.log(e)) / (16.78 - Math.log(e)); // + 273.16;
        } else {
          td = NaN;
        }
        this.dewpt_values.push(td);
      }
    },
    async getData() {
      /* let date_time = "2020-5-25T08:59Z";
      let url =
        "http://10.61.141.62:8090/ncWMS2/wms?version=1.3.0&CRS=CRS:84&service=WMS&request=GetVerticalProfile&LAYERS=" +
        this.temp_layerName +
        "&QUERY_LAYERS=" +
        this.temp_layerName +
        "," +
        this.wv_layerName +
        "," +
        this.height_layerName +
        "&BBOX=30.600586,1.977539,134.399414,43.022461&I=347&J=210&WIDTH=1181&HEIGHT=467&INFO_FORMAT=text/json";
      url += "&TIME=" + date_time;
      url +=
        "&elevation=" + this.query_startplevel + "/" + this.query_endplevel;
      let response = await d3.json(url); */
      let plevel_clause = this.query_startplevel + "/" + this.query_endplevel;

      /* this.my_probe_info.layer.layerName =
        this.temp_layerName +
        "," +
        this.wv_layerName.split("/")[1] +
        "," +
        this.height_layerName.split("/")[1]; */

      let my_layer = {
        layerName:
          this.my_probe_info.layer.layerName +
          "," +
          (this.wv_layerName !== undefined
            ? this.wv_layerName
            : this.dewpt_layerName) +
          "," +
          this.height_layerName,
        /* (this.wv_layerName !== undefined
            ? this.wv_layerName.split("/")[1]
            : this.dewpt_layerName.split("/")[1]) +
          "," +
          this.height_layerName.split("/")[1], */

        url: this.my_probe_info.layer.url,
        version: this.my_probe_info.layer.version,
        projection: this.my_probe_info.layer.projection,
        extParams: {
          elevation: this.my_probe_info.layer.extParams.elevation,
        },
      };
      let url_arr = [];

      let url = this.getFeatureInfoUrl(
        //        this.my_probe_info.layer,
        my_layer,
        this.my_probe_info.map_bbox,
        this.my_probe_info.map_size,
        this.my_probe_info.scan_pix,
        "GetVerticalProfile",
        this.my_probe_info.layer.time,
        "text/json",
        plevel_clause
      );
      //console.log("vertical profile url:" + url);
      url_arr.push(url);

      let surf_vars_present = true;
      let surf_vars = this.skt_anc_layers["surf_vars"];

      if (surf_vars !== undefined) {
        let cnt = 0;
        let surface_layername = "";

        let surf_var_keys = Object.keys(surf_vars);
        if (surf_var_keys.length) {
          for (let key of surf_var_keys) {
            if (cnt == 0) {
              surface_layername += surf_vars[key];
            } else {
              surface_layername += surf_vars[key];
            }
            if (cnt !== surf_var_keys.length - 1) {
              surface_layername += ",";
            }
            cnt++;
          }

          let surf_layer = {
            layerName: surface_layername,
            url: this.my_probe_info.layer.url,
            version: this.my_probe_info.layer.version,
            projection: this.my_probe_info.layer.projection,
            extParams: {
              elevation: 0,
            },
          };

          let surf_url = this.getFeatureInfoUrl(
            //        this.my_probe_info.layer,
            surf_layer,
            this.my_probe_info.map_bbox,
            this.my_probe_info.map_size,
            this.my_probe_info.scan_pix,
            "GetFeatureInfo",
            this.my_probe_info.layer.time,
            "text/xml"
          );

          //console.log("surf_url:" + surf_url);
          url_arr.push(surf_url);
          surf_vars_present = true;
        }
      }

      //Reset
      //this.my_probe_info.layer.layerName = this.temp_layerName;

      let response_arr = await this.fetchUrlXmls(url_arr);
      let response = JSON.parse(response_arr[0]);

      //console.log("response:" + response);

      let ranges = response.ranges;

      this.pressure_values = response.domain.axes.z.values;
      this.temp_values = ranges[this.temp_layerName.split("/")[1]].values.map(
        (t) => t - this.degCtoK
      );
      let wv_values;
      if (this.wv_layerName !== undefined) {
        wv_values = ranges[this.wv_layerName.split("/")[1]].values;
      } else {
        this.dewpt_values = ranges[this.dewpt_layerName.split("/")[1]].values;
      }
      let geopothgt_values = ranges[this.height_layerName.split("/")[1]].values;
      if (surf_vars_present) {
        let surface_response_value_map = this.parsePointProbeResponseMap(
          response_arr[1]
        );

        let surf_pres_varname = surf_vars["pres"];
        let surf_temp_varname = surf_vars["temp"];
        let surf_wv_varname = surf_vars["wv"];
        let surf_dewpt_varname = surf_vars["dewpt"];

        /* console.log("surf_temp_varname:" + surf_temp_varname);
        console.log("surf_wv_varname:" + surf_wv_varname); */

        if (
          surf_pres_varname !== undefined &&
          surf_temp_varname !== undefined &&
          (surf_wv_varname !== undefined || surf_dewpt_varname != undefined)
        ) {
          let surf_pres = parseFloat(
            //surface_response_value_map[surf_pres_varname.split("/")[1]]
            surface_response_value_map[surf_pres_varname]
          );
          let surf_temp =
            parseFloat(surface_response_value_map[surf_temp_varname]) -
            this.degCtoK; //Convert Temperature from Kelvin to Celsius
          let surf_wv, surf_dewpt;
          if (surf_wv_varname !== undefined) {
            surf_wv = parseFloat(surface_response_value_map[surf_wv_varname]);
            wv_values.push(surf_wv);
          } else {
            surf_dewpt = parseFloat(
              surface_response_value_map[surf_dewpt_varname]
            );
            this.dewpt_values.push(surf_dewpt);
          }

          this.temp_values.push(surf_temp);

          this.pressure_values.push(surf_pres);
          geopothgt_values.push(NaN);

          let tpw_varname = surf_vars["tpw"];
          //console.log("tpw_varname:" + tpw_varname);
          if (tpw_varname !== undefined) {
            this.tpw = +surface_response_value_map[tpw_varname];
          }
          let li_varname = surf_vars["li"];
          if (li_varname !== undefined) {
            this.li = +surface_response_value_map[li_varname];
          }
        }
      }
      if (this.wv_layerName !== undefined) {
        this.calculateDewPt(wv_values);
      } else {
        this.dewpt_values = this.dewpt_values.map((v) => v - this.degCtoK);
      }

      let num_levels = this.temp_values.length;
      let nan_plevels = [];
      this.t_dp_hgt_prof = [];
      for (let indx = 0; indx < num_levels; indx++) {
        if (
          this.temp_values[indx] !== null &&
          (this.dewpt_values[indx] !== null || wv_values[indx] !== null) &&
          geopothgt_values[indx] !== null
        ) {
          this.t_dp_hgt_prof.push({
            temp: this.temp_values[indx],
            dewpt: this.dewpt_values[indx],
            press: this.pressure_values[indx],
            hgt: geopothgt_values[indx],
          });
        } else {
          nan_plevels.push(this.pressure_values[indx]);
        }
      }
      /* if (nan_plevels.length) {
        console.log(
          "Nan values found at following pressure levels:" + nan_plevels
        );
      } */

      this.pressure_values = this.t_dp_hgt_prof.map((entry) => entry.press);
      this.temp_values = this.t_dp_hgt_prof.map((entry) => entry.temp);
      this.dewpt_values = this.t_dp_hgt_prof.map((entry) => entry.dewpt);

      this.t_dp_hgt_prof = this.t_dp_hgt_prof.sort((val1, val2) =>
        val1.press < val2.press ? -1 : val1.press > val2.pres ? 1 : 0
      );
    },

    mousemove(mousepressure) {
      let me = this;

      let tdp_prof = [...me.t_dp_hgt_prof];
      /*tdp_prof.sort((val1, val2) =>
        val1.press < val2.press ? -1 : val1.press > val2.pres ? 1 : 0
      ); */

      let i = me.bisectTemp(tdp_prof, mousepressure, 1);

      let d0 = tdp_prof[i - 1];
      let d1 = tdp_prof[i];
      let d;
      if (d0 == undefined) {
        d = d1;
      } else if (d1 === undefined) {
        d = d0;
      } else {
        d = mousepressure - d0.press > d1.press - mousepressure ? d1 : d0;
      }
      /* console.log("d0:" + d0 + " d1:" + d1 + " i:" + i);
      console.log("d:" + d); */
      /* console.log(
        "pos x:" + me.x(d.temp) + (me.y(me.basep) - me.y(d.press)) / me.tan
      );
      console.log("pos y:" + me.y(d.press)); */
      //console.log("tdp_prof length:" + tdp_prof.length);
      //console.log("d:" + d.temp + " pres:" + d.press + " dewpt:" + d.dewpt);

      me.temp_probe
        .select("text")
        .text(d.temp.toFixed(2) + "°C")
        .attr("x", me.x(d.temp) + (me.y(me.basep) - me.y(d.press)) / me.tan)
        .attr("y", me.y(d.press));
      me.temp_probe
        .select("circle")
        .attr("cx", me.x(d.temp) + (me.y(me.basep) - me.y(d.press)) / me.tan)
        .attr("cy", me.y(d.press));

      me.dewpt_probe
        .select("text")
        .text(d.dewpt.toFixed(2) + "°C")
        .attr("x", me.x(d.dewpt) + (me.y(me.basep) - me.y(d.press)) / me.tan)
        .attr("y", me.y(d.press));
      me.dewpt_probe
        .select("circle")
        .attr("cx", me.x(d.dewpt) + (me.y(me.basep) - me.y(d.press)) / me.tan)
        .attr("cy", me.y(d.press));

      me.gph_probe
        .select("text")
        .text((isNaN(d.hgt) ? "NA" : (d.hgt / 1000).toFixed(2) + " Km") + " --")
        .attr("x", this.width)
        .attr("y", me.y(d.press));
    },

    addProbe() {
      let me = this;
      this.probegroup = me.svg.append("g").attr("class", "probe_group");

      this.temp_probe = me.probegroup.append("g").style("display", "none");
      this.temp_probe
        .append("circle")
        .attr("r", this.circle_radius)
        .attr("fill", "red");
      this.temp_probe.append("text").attr("class", "probe_text");

      this.dewpt_probe = this.probegroup.append("g").style("display", "none");
      this.dewpt_probe
        .append("circle")
        .attr("r", this.circle_radius)
        .attr("fill", "green");
      this.dewpt_probe
        .append("text")
        .attr("class", "probe_text")
        .attr("text-anchor", "end");

      this.gph_probe = this.probegroup.append("g").style("display", "none");
      this.gph_probe
        .append("text")
        .attr("class", "probe_text")
        .attr("text-anchor", "end");

      this.svg
        .append("rect")
        .attr("id", "mousemove_rect")
        .attr("class", "overlay")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height)
        .on("mouseenter", function () {
          me.temp_probe.style("display", null);
          me.dewpt_probe.style("display", null);
          me.gph_probe.style("display", null);
        })
        .on("mouseleave", function () {
          me.temp_probe.style("display", "none");
          me.dewpt_probe.style("display", "none");
          me.gph_probe.style("display", "none");
        })
        .on("mousemove", function () {
          let mousepressure = me.y.invert(d3.mouse(this)[1]);
          me.mousemove(mousepressure);
        });
    },

    drawBackground() {
      let pp = d3.range(this.topp, this.basep + 1, 10);

      //let ptop = 10;
      //console.log(p_step_size);

      let me = this;

      // Add clipping path
      this.svg
        .append("clipPath")
        .attr("id", "clipper")
        .append("rect")
        .attr("class", "overlay")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height);

      // Skewed temperature lines
      this.svg
        .selectAll("gline")
        .data(d3.range(-200, 40, 10))
        .enter()
        .append("line")
        .attr("x1", function (d) {
          //return me.x(d) - 0.5 + (me.y(me.basep) - me.y(100)) / me.tan;
          return me.x(d) - 0.5 + (me.y(me.basep) - me.y(100)) / me.tan;
        })
        .attr("x2", function (d) {
          return me.x(d) - 0.5;
        })
        .attr("y1", 0)
        .attr("y2", this.height)
        .attr("class", function (d) {
          if (d == 0) {
            return "tempzero";
          } else {
            return "gridline_temp";
          }
        })
        .attr("clip-path", "url(#clipper)");

      //Pressure Lines

      this.svg
        .selectAll("gline2")
        .data(this.plines)
        .enter()
        .append("line")
        .attr("x1", 0)
        .attr("x2", this.width)
        .attr("y1", function (d) {
          return me.y(d);
        })
        .attr("y2", function (d) {
          return me.y(d);
        })
        .attr("class", "gridline_pres");

      let dryline = d3
        .line()
        .x((d, i) => me.x(d) + (me.y(me.basep) - me.y(pp[i])) / me.tan)
        .y((d, i) => me.y(pp[i]));

      // create array to plot dry adiabats
      var dryad = d3.range(-30, 220, 20);
      var dry_adiabat_lines = [];
      for (let i = 0; i < dryad.length; i++) {
        var z = [];

        for (let j = 0; j < pp.length; j++) {
          let pot_temp =
            (273.15 + dryad[i]) * Math.pow(pp[j] / 1000, 0.286) - 273.15;
          z.push(pot_temp);
        }
        dry_adiabat_lines.push(z);
      }

      this.svg
        .selectAll(".dryline")
        .data(dry_adiabat_lines)
        .enter()
        .append("path")
        .attr("class", "gridline_dry")
        .attr("clip-path", "url(#clipper)")
        .attr("d", dryline);

      let p_nsteps = 501;
      let preswet = this.logspace(this.basep, this.topp, p_nsteps);
      //console.log("From function preswet:" + preswet);

      let wetline = d3
        .line()
        .x((d, i) => me.x(d) + (me.y(me.basep) - me.y(preswet[i])) / me.tan)
        .y((d, i) => me.y(preswet[i]));

      let wet_adiabat_lines = this.getMoistAdiabats(-32, 49, 4, preswet);

      this.svg
        .selectAll(".wetline")
        .data(wet_adiabat_lines)
        .enter()
        .append("path")
        .attr("class", "gridline_wet")
        .attr("clip-path", "url(#clipper)")
        .attr("d", wetline);

      let mr_nsteps = 101;
      let mr_plevels = this.logspace(this.basep, this.topp, mr_nsteps);

      let filtered_mr_plevels = mr_plevels.filter((value) => value >= 300, []);

      let w = [
        0.0001,
        0.0004,
        0.001,
        0.002,
        0.004,
        0.007,
        0.01,
        0.016,
        0.024,
        0.032,
        0.04,
        0.048,
      ];

      let mixing_ratio_lines = this.getMixingRatioIsoPleths(
        filtered_mr_plevels,
        w
      );

      let mr_line_function = d3
        .line()
        .x(
          (d, i) =>
            me.x(d) + (me.y(me.basep) - me.y(filtered_mr_plevels[i])) / me.tan
        )
        .y((d, i) => me.y(filtered_mr_plevels[i]));

      this.svg
        .selectAll(".mrline")
        .data(mixing_ratio_lines)
        .enter()
        .append("path")
        .attr("class", "gridline_mr")
        .attr("clip-path", "url(#clipper)")
        .attr("d", mr_line_function);

      //console.log(filtered_mr_plevels[filtered_mr_plevels.length - 1]);

      let num_lines = mixing_ratio_lines.length;
      let mr_label_data = [];
      for (let indx = 0; indx < num_lines; indx++) {
        mr_label_data.push({
          temp: mixing_ratio_lines[indx][mixing_ratio_lines[indx].length - 1],
          pres: filtered_mr_plevels[filtered_mr_plevels.length - 1],
          label: w[indx] * 1000,
        });
      }

      let mrlabel_text = this.svg
        .selectAll(".mrline_text")
        .data(mr_label_data)
        .enter()
        .append("text")
        .attr("clip-path", "url(#clipper)");

      mrlabel_text
        .attr(
          "x",
          (d) => me.x(d.temp) + (me.y(me.basep) - me.y(d.pres)) / me.tan
        )
        .attr("y", (d) => me.y(d.pres))
        .text((d) => d.label);

      // Line along right edge of plot
      this.svg
        .append("line")
        .attr("x1", this.width - 0.5)
        .attr("x2", this.width - 0.5)
        .attr("y1", 0)
        .attr("y2", this.height)
        .attr("class", "gridline_right");

      //X-Axis labels to top
      /*let gXAxis_top = */ this.svg
        .append("g")
        .attr("class", "xaxis")
        /* .attr(
          "transform",
          "translate(0," + (-this.height + this.margine.top) + ")"
        ) */
        .call(this.xAxisTop);

      //X-Axis
      let gXAxis = this.svg
        .append("g")
        .attr("class", "xaxis")
        .attr("transform", "translate(0," + (this.height - 0.5) + ")")
        .call(this.xAxis);

      gXAxis
        .append("text")
        .attr("transform", "translate(" + this.width / 2 + ",20)")
        //.attr("fill", "currentColor")
        /* .style("text-anchor", "middle")
        .style("stroke", "black") */
        .attr("class", "axislabels")
        .text("Temperature (C)");

      /* gXAxis_top
        .append("text")
        .attr("transform", "translate(" + this.width / 2 + ",-30)")
        //.attr("fill", "currentColor")
        //.style("text-anchor", "middle")
        .attr("class", "axislabels")
        .text("Temperature (C)"); */

      //Y-Axis
      let gYAxis = this.svg
        .append("g")
        .attr("class", "yaxis")
        .attr("transform", "translate(-0.5,0)")
        .call(this.yAxis);

      gYAxis
        .append("text")
        .attr(
          "transform",
          "translate(" +
            (-this.margin.left + 10) +
            "," +
            this.height / 2 +
            ") rotate(-90)"
        )
        .attr("class", "axislabels")
        .text("Pressure (mb)");

      //Y-Axis Ticks
      this.svg
        .append("g")
        .attr("class", "y axis ticks")
        .attr("transform", "translate(-0.5,0)")
        .call(this.yAxis2);

      this.gYAxis_right = this.svg
        .append("g")
        .attr("class", "yaxis")
        .attr("transform", "translate(" + (this.width - 2) + ",0)")
        .call(this.yAxisRight);

      this.gYAxis_right
        .append("text")
        .attr(
          "transform",
          "translate(" +
            (this.margin.right - 5) +
            "," +
            this.height / 2 +
            ") rotate(90)"
        )
        .attr("class", "axislabels")
        .text("Geopotential Height (Km)");
    },

    async plot() {
      await this.getData();
      // bisector function for tooltips
      this.bisectTemp = d3.bisector(function (d) {
        return d.press;
      }).left;

      if (this.svg !== undefined) {
        this.svg.selectAll(".tprof_curve").remove();
        this.svg.selectAll(".dp_prof_curve").remove();
        this.svg.selectAll(".parcel_curve").remove();
        this.svg.selectAll(".lcl_point").remove();
        this.svg.selectAll(".lfc_point").remove();
        this.svg.selectAll(".el_point").remove();
        this.svg.selectAll(".probe_group").remove();
        this.svg.selectAll(".probe_text").remove();
        this.svg.selectAll("#mousemove_rect").remove();

        this.yAxisRight.tickFormat((d) => {
          let filtered_values = this.t_dp_hgt_prof.filter(
            (entry) => entry.press == d
          );
          if (filtered_values.length) {
            return (filtered_values[0].hgt / 1000).toFixed(2);
          } else {
            return "NA";
          }
        });
        this.gYAxis_right.call(this.yAxisRight);
      } else {
        this.svg = d3
          .select(".sktchart")
          /* .attr("viewBox", [
            0,
            0,
            this.width + this.margin.left + this.margin.right,
            this.height + this.margin.top + this.margin.bottom
          ]) */
          .attr("width", this.width + this.margin.left + this.margin.right)
          .attr("height", this.height + this.margin.top + this.margin.bottom)
          .style("background", "white")
          .append("g")

          .attr(
            "transform",
            "translate(" + this.margin.left + "," + this.margin.top + ")"
          );

        this.createAxes();

        this.drawBackground();
      }
      this.drawProfile();
      this.liftParcel();
    },

    createAxes() {
      this.x = d3
        .scaleLinear()
        .range([0, this.width])
        .domain([this.bot_xaxis_min, this.bot_xaxis_max]);

      //YScale Pressure
      this.y = d3
        .scaleLog()
        .range([0, this.height])
        .domain([this.topp, this.basep]);

      this.xAxis = d3.axisBottom().scale(this.x).tickSize(0, 0).ticks(10);

      this.yAxis = d3
        .axisLeft()
        .scale(this.y)
        .tickSize(0, 0)
        .tickValues(this.plines)
        .tickFormat(d3.format(".0d"));

      this.xScaleTop = d3
        .scaleLinear()
        .range([0, this.width])
        .domain([this.top_xaxis_min, this.top_xaxis_max]);

      this.xAxisTop = d3
        .axisTop()
        .scale(this.xScaleTop)
        .tickSize(0, 0)
        .ticks(10);

      this.yAxis2 = d3
        .axisRight()
        .scale(this.y)
        .tickSize(5, 0)
        .tickValues(this.pticks);

      this.yAxisRight = d3
        .axisRight()
        .scale(this.y)
        .tickSize(0, 0)
        .tickValues(this.plines)
        .tickFormat((d) => {
          let filtered_values = this.t_dp_hgt_prof.filter(
            (entry) => entry.press == d
          );
          if (filtered_values.length) {
            return (filtered_values[0].hgt / 1000).toFixed(2);
          } else {
            return "NA";
          }
        });
    },

    async liftParcel() {
      let pmax = d3.max(this.t_dp_hgt_prof.map((value) => value.press));
      let base_value = this.t_dp_hgt_prof.filter(
        (value) => value.press == pmax
      );
      //console.log("base_value length:" + base_value.length);
      if (base_value.length) {
        let startt = base_value[0].temp;
        let startdp = base_value[0].dewpt;
        let startp = pmax;

        let presdry_arr, preswet_arr, tempdry_arr, tempiso_arr, tempwet_arr;

        [
          this.P_lcl,
          this.T_lcl,
          this.P_lfc,
          this.P_el,
          this.CAPE,
          this.CIN,
          presdry_arr,
          tempdry_arr,
          tempiso_arr,
          preswet_arr,
          tempwet_arr,
          this.si,
        ] = this.getCape(this.t_dp_hgt_prof, startp, startt, startdp);

        //[preswet_arr, tempwet_arr] = this.moist_ascent(this.P_lcl, this.T_lcl); //Calculate for 501 levels

        let T_lfc = this.evaluateLinear(
          this.P_lfc,
          [...preswet_arr].reverse(),
          [...tempwet_arr].reverse()
        );

        let T_el = this.evaluateLinear(
          this.P_el,
          [...preswet_arr].reverse(),
          [...tempwet_arr].reverse()
        );

        [this.tconv, this.pccl] = this.getCCL_ConvT(this.t_dp_hgt_prof);
        ///console.log("tconv:" + this.tconv);

        this.Td = base_value[0].dewpt;
        this.P_sfc = pmax;
        //console.log("P_sfc:" + this.P_sfc);

        //K-Index and TT Index Calculation
        let prof_850 = this.t_dp_hgt_prof.filter((value) => value.press == 850);
        let prof_700 = this.t_dp_hgt_prof.filter((value) => value.press == 700);
        let prof_500 = this.t_dp_hgt_prof.filter((value) => value.press == 500);
        if (prof_850.length && prof_700.length && prof_500.length) {
          //K-Index: K = T850 + Td850 + Td700 - T700 – T500
          this.ki =
            prof_850[0].temp +
            prof_850[0].dewpt +
            prof_700[0].dewpt -
            prof_700[0].temp -
            prof_500[0].temp;
          /* console.log(
            "temp_850:" +
              prof_850[0].temp +
              " dwpt_850:" +
              prof_850[0].dewpt +
              " temp_700:" +
              prof_700[0].temp +
              " dewpt_700:" +
              prof_700[0].dewpt +
              " temp_500:" +
              prof_500[0].temp
          ); */

          // TT = T850 + Td850 – 2T500
          this.tt = prof_850[0].temp + prof_850[0].dewpt - 2 * prof_500[0].temp;
        } else {
          this.ki = NaN;
          this.tt = NaN;
        }

        let parcel_data = [];
        for (let indx = 0; indx < presdry_arr.length; indx++) {
          parcel_data.push({
            presdry: presdry_arr[indx],
            tempdry: tempdry_arr[indx],
            tempiso: tempiso_arr[indx],
          });
        }

        let parcel_data_wet = [];
        for (let indx = 0; indx < tempwet_arr.length; indx++) {
          parcel_data_wet.push({
            preswet: preswet_arr[indx],
            tempwet: tempwet_arr[indx],
          });
        }

        let me = this;
        //Plot traces below LCL
        this.svg
          .append("path")
          .attr("clip-path", "url(#clipper)")
          .datum(parcel_data)
          .attr(
            "d",
            d3
              .line()
              .defined((d) => !isNaN(d.tempdry))
              .x(
                (d) =>
                  me.x(d.tempdry) + (me.y(me.basep) - me.y(d.presdry)) / me.tan
              )
              .y((d) => me.y(d.presdry))
          )
          .attr("class", "parcel_curve");

        this.svg
          .append("path")
          .attr("clip-path", "url(#clipper)")
          .datum(parcel_data)
          .attr(
            "d",
            d3
              .line()
              .defined((d) => !isNaN(d.tempiso))
              .x(
                (d) =>
                  me.x(d.tempiso) + (me.y(me.basep) - me.y(d.presdry)) / me.tan
              )
              .y((d) => me.y(d.presdry))
          )
          .attr("class", "parcel_curve");
        if (!isNaN(me.P_lcl) && !isNaN(me.T_lcl)) {
          this.svg
            .append("circle")
            .attr("class", "lcl_point")
            .attr(
              "cx",
              me.x(me.T_lcl) + (me.y(me.basep) - me.y(me.P_lcl)) / me.tan
            )
            .attr("cy", me.y(me.P_lcl))
            .attr("r", 5);
        }
        // Plot trace above LCL
        this.svg
          .append("path")
          .attr("clip-path", "url(#clipper)")
          .datum(parcel_data_wet)
          .attr(
            "d",
            d3
              .line()
              .defined((d) => !isNaN(d.tempwet))
              .x(
                (d) =>
                  me.x(d.tempwet) + (me.y(me.basep) - me.y(d.preswet)) / me.tan
              )
              .y((d) => me.y(d.preswet))
          )
          .attr("class", "parcel_curve");

        //Plot LFC and EL
        if (!isNaN(me.P_lfc) && !isNaN(T_lfc)) {
          this.svg
            .append("circle")
            .attr("class", "lfc_point")
            .attr(
              "cx",
              me.x(T_lfc) + (me.y(me.basep) - me.y(me.P_lfc)) / me.tan
            )
            .attr("cy", me.y(me.P_lfc))
            .attr("r", 5);
        }

        if (!isNaN(me.P_el) && !isNaN(T_el)) {
          this.svg
            .append("circle")
            .attr("class", "el_point")
            .attr("cx", me.x(T_el) + (me.y(me.basep) - me.y(me.P_el)) / me.tan)
            .attr("cy", me.y(me.P_el))
            .attr("r", 5);
        }

        //Shade CIN and CAPE Areas
        if (!isNaN(this.P_lfc) && !isNaN(T_lfc)) {
          //Shade CIN
          let tparcel_arr = tempdry_arr.concat(tempwet_arr.slice(1));
          let pparcel_arr = presdry_arr.concat(preswet_arr.slice(1));
          let cin_polygon = [];
          for (let index = 0; index < tparcel_arr.length; index++) {
            if (pparcel_arr[index] > this.P_lfc) {
              cin_polygon.push({
                parcel_temp: tparcel_arr[index],
                press: pparcel_arr[index],
              });
            }
          }
          let cin_parcel_pressures = cin_polygon.map((value) => value.press);

          /*console.log("cin_parcel_pressures:" + cin_parcel_pressures);
          console.log("profile pressure_values:" + this.pressure_values);*/

          let interp_temp_values = this.evaluateLinear(
            [...cin_parcel_pressures].reverse(),
            this.pressure_values,
            this.temp_values
          );
          interp_temp_values.reverse();

          //console.log("interp_temp_values:" + interp_temp_values);
          for (let indx = 0; indx < cin_polygon.values; indx++) {
            cin_polygon[indx].prof_temp = interp_temp_values[indx];
          }
          //console.log("cin_polygon:" + cin_polygon);

          let d3_cin_area = d3
            .area()
            .x0(function (d) {
              /* console.log(
                "x0:" +
                  me.x(
                    d.prof_temp < d.parcel_temp ? d.prof_temp : d.parcel_temp
                  ) +
                  (me.y(me.basep) - me.y(d.press)) / me.tan
              ); */
              return (
                me.x(
                  d.prof_temp < d.parcel_temp ? d.prof_temp : d.parcel_temp
                ) +
                (me.y(me.basep) - me.y(d.press)) / me.tan
              );
            })
            .x1(function (d) {
              /* console.log(
                "x1:" +
                  me.x(
                    d.prof_temp > d.parcel_temp ? d.prof_temp : d.parcel_temp
                  ) +
                  (me.y(me.basep) - me.y(d.press)) / me.tan
              ); */
              return (
                me.x(
                  d.prof_temp > d.parcel_temp ? d.prof_temp : d.parcel_temp
                ) +
                (me.y(me.basep) - me.y(d.press)) / me.tan
              );
            })
            .y(function (d) {
              //console.log("y:" + me.y(d.press));
              return me.y(d.press);
            });

          this.svg
            .append("path")
            .datum(cin_polygon)
            .attr("class", "cin_area")
            .attr("d", d3_cin_area);
        }

        this.addProbe();
      }
    },

    async drawProfile() {
      let me = this;

      this.svg
        .append("path")
        .attr("clip-path", "url(#clipper)")
        .datum(this.t_dp_hgt_prof)
        .attr(
          "d",
          d3
            .line()
            .defined((d) => !isNaN(d.temp))
            .x((d) => me.x(d.temp) + (me.y(me.basep) - me.y(d.press)) / me.tan)
            .y((d) => me.y(d.press))
        )
        .attr("class", "tprof_curve");

      this.svg
        .append("path")
        .attr("clip-path", "url(#clipper)")
        .datum(this.t_dp_hgt_prof)
        .attr(
          "d",
          d3
            .line()
            .defined((d) => !isNaN(d.dewpt))
            .x(
              (d) => me.x(d.dewpt) + (me.y(this.basep) - me.y(d.press)) / me.tan
            )
            .y((d) => me.y(d.press))
        )
        .attr("class", "dp_prof_curve");
    },
  },
};
</script>
<style >
/* body {
  font: 14px helvetica;
  text-align: center;
}
#container {
  width: 1000px;
  margin: auto;
}
#mainbox,
#hodobox {
  float: left;
}
#hodobox {
  width: 300px;
} */

/*.axis path,
.axis line {
  fill: none;
  stroke: #fff;
  stroke-width: 1px;
  shape-rendering: crispEdges;
}
.axis {
  fill: #fff;
} */

.cin_area {
  fill: #000000;
}
.axislabels {
  stroke: black;
  text-anchor: middle;
}
.probe_text {
  font-size: 11px;
  /*stroke: white;*/
}
.y.axis {
  font-size: 13px;
}
.y.axis.hght {
  font-size: 9px;
  fill: red;
}
.x.axis {
  font-size: 13px;
}
.y.axis.ticks text {
  display: none;
}
.dp_prof_curve {
  fill: none;
  stroke-width: 3px;
  stroke: green;
  /*stroke-dasharray: 10, 10;*/
}

.tprof_curve {
  fill: none;
  stroke-width: 2px;
  stroke: #ff0000;
}

.parcel_curve {
  fill: none;
  stroke-width: 2px;
  stroke: #aaaaaa;
}

.lcl_point {
  fill: #aaaaaa;
}
.lfc_point {
  fill: #0000ff;
}
.el_point {
  fill: #ff0000;
}

.temp_circle_class {
  fill: #111111;
}

.temp {
  fill: none;
  stroke: red;
  stroke-width: 2px;
}
.dwpt {
  fill: none;
  stroke: green;
  stroke-width: 2px;
}
.member {
  stroke-width: 1.5px;
  opacity: 0.4;
}
.mean {
  stroke-width: 2.5px;
}
.hodoline {
  stroke: #aaa;
  fill: none;
  opacity: 0.5;
}
.hodoline.mean {
  stroke: #000;
  opacity: 1;
  stroke-width: 3.5px;
}
.hododot {
  stroke: #000;
  opacity: 0.8;
}
.hododot.hgt0 {
  fill: gray;
}
.hododot.hgt1 {
  fill: #225ea8;
}
.hododot.hgt3 {
  fill: #41b6c4;
}
.hododot.hgt6 {
  fill: #a1dab4;
}
.hododot.hgt9 {
  fill: #ffffcc;
}

.gridline_pres {
  stroke: #5f5d5d;
  stroke-width: 0.5px;
  fill: none;
}

.gridline_mr {
  stroke: #ff55ff;
  stroke-width: 0.5px;
  fill: none;
}

.gridline_right {
  stroke: #000;
  stroke-width: 1px;
  fill: none;
  shape-rendering: crispEdges;
}

.gridline_temp {
  stroke: #5f5d5d;
  stroke-width: 0.5px;
  fill: none;
}

.gridline_dry {
  stroke: #aaffaa;
  stroke-width: 1px;
  fill: none;
}

.gridline_wet {
  stroke: #5555ff;
  stroke-width: 0.75px;
  fill: none;
}

.tempzero {
  stroke: #5f5d5d;
  stroke-width: 0.5px;
  fill: none;
}

.barline {
  stroke: #000;
  stroke-width: 0.5px;
}
.rectline {
  fill: #aaa;
  opacity: 0.5;
}

.index {
  font-size: 13px;
}
.header {
  font-weight: bold;
  font-size: 11px;
}
.hodolabels {
  font-size: 9px;
  opacity: 0.5;
}
.lcltext {
  font-size: 11px;
}
.key {
  font-size: 10px;
}

.windbarb {
  stroke: #000;
  stroke-width: 0.75px;
  fill: none;
}
.flag {
  fill: #000;
}

.overlay {
  fill: none;
  pointer-events: all;
  /*stroke: white;*/
}
.xaxis {
  stroke: black;
}

.yaxis {
  background: white;
  stroke: black;
}
.focus.tmpc circle {
  fill: red;
  stroke: none;
}
.focus.dwpc circle {
  fill: green;
  stroke: none;
}
.focus text {
  font-size: 12px;
}
div.rollover {
  padding: 15px 5px 15px 5px;
  display: inline;
  cursor: pointer;
}
div.rollover.selected {
  background-color: #efefef;
  border-bottom: 2px solid gray;
}
</style>