<template>
  <div>
    <v-card style="overflow-y:auto; overflow-x:hidden;" :max-height="getComponentHeight()">
      <ul class="rapid_list" id="vector_layers">
        <li>
          <v-row align="center">
            <v-checkbox
              hide-details
              class="shrink mr-2 mt-0 mb-0"
              dark
              v-model="graticule_visibility"
              label="GridLines"
            ></v-checkbox>
            <v-btn
              :disabled="!graticule_visibility"
              @click="openDialog('GridLines', 'gridlines')"
              icon
            >
              <v-icon>mdi-pencil</v-icon>
            </v-btn>
          </v-row>
        </li>
        <li v-for="vlayer in vector_layers" :key="vlayer.url + '/'+vlayer.layerName">
          <v-row align="center">
            <v-checkbox
              hide-details
              class="shrink mr-2 mt-0 mb-0"
              dark
              v-model="vlayer.visible"
              :label="vlayer.attribution"
            ></v-checkbox>
            <v-btn
              :disabled="!vlayer.visible"
              @click="openDialog(vlayer.attribution, vlayer.url + '/'+vlayer.layerName)"
              icon
            >
              <v-icon>mdi-pencil</v-icon>
            </v-btn>
          </v-row>
        </li>
      </ul>
      <EditVecLayer
        v-if="myshow"
        :show="myshow"
        :title="mytitle"
        :url="myurl"
        :category="tab_layer_type"
        @visibilityChanged="myshow=false"
      />
    </v-card>
  </div>
</template>
<script>
import { mapState, mapMutations, mapGetters } from "vuex";
import EditVecLayer from "./EditVecLayer";
export default {
  components: { EditVecLayer },
  computed: {
    ...mapState(["mobileView", "gridlines_visible"]),
    ...mapGetters(["getAddlLayersListByCat"]),
    graticule_visibility: {
      get() {
        return this.gridlines_visible;
      },
      set(new_val) {
        this.setGridLineVisibility(new_val);
      }
    },
    vector_layers() {
      return this.getAddlLayersListByCat(this.tab_layer_type);
    }
  },
  data() {
    return {
      mytitle: "",
      myurl: "",
      myshow: false
    };
  },
  methods: {
    ...mapMutations(["setGridLineVisibility"]),
    getComponentHeight() {
      return this.mobileView ? "30vh" : "100vh";
    },
    openDialog(caption, url) {
      console.log("In openDialog");
      this.mytitle = caption;
      this.myurl = url;
      this.myshow = true;
    }
  },
  props: {
    tab_layer_type: {
      type: String,
      required: true
    }
  }
};
</script>
<style >
.rapid_list {
  list-style: none;
}
</style>