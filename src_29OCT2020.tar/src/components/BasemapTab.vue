<template>
  <v-card style="overflow-y:auto; overflow-x:hidden;" :max-height="component_height">
    <v-radio-group v-model="sel_base_layer">
      <v-radio key="None" label="None" value="None" />
      <v-radio
        v-for="blayer of basemap_layers"
        :key="blayer.url + '/' + blayer.layerName"
        :label="blayer.attribution"
        :value="blayer.url + '/' + blayer.layerName"
      />
    </v-radio-group>
  </v-card>
</template>
<script>
import { mapState, mapGetters, mapMutations } from "vuex";
export default {
  computed: {
    ...mapGetters(["getAddlLayersListByCat"]),
    ...mapState(["mobileView"]),
    component_height() {
      
      return this.mobileView ? "30vh" : "100vh";
    
    },
    sel_base_layer: {
      get() {
        let filtered_layers = this.basemap_layers.filter(
          (layer) => layer.visible
        );
        let out = filtered_layers.length
          ? `${filtered_layers[0].url}/${filtered_layers[0].layerName}`
          : "None";
        //console.log("sel_base_layer:" + out);
        return out;
      },
      set(new_val) {
        //console.log("new_val:" + new_val);
        for (let blayer of this.basemap_layers) {
          let key = `${blayer.url}/${blayer.layerName}`;
          this.updateAdditionalLayer({
            cat: this.tab_layer_type,
            url: key,
            items: {
              visible: key === new_val,
            },
          });
        }
      },
    },
    basemap_layers() {
      //console.log("In basemap_layers:" + this.tab_layer_type);
      return this.getAddlLayersListByCat(this.tab_layer_type);
    },
  },
  methods: {
    ...mapMutations(["updateAdditionalLayer"]),
    
  },
  props: {
    tab_layer_type: {
      type: String,
      required: true,
    },
  },
};
</script>
