<template>
  <v-layout>
    <v-flex xs1>
      <v-icon v-if="mdi_icon_name !== undefined" style="display:grid;">
        {{
        mdi_icon_name
        }}
      </v-icon>
      <v-label v-else>{{ list_caption }}</v-label>
    </v-flex>
    <v-flex xs12>
      <v-slide-group
        v-model="sel_value_index"
        @change="valueChanged($event)"
        mandatory
        center-active
        show-arrows
      >
        <v-slide-item
          v-for="(value, indx) in valuelist"
          :key="indx"
          v-slot:default="{ active, toggle }"
        >
          <v-btn small :color="active ? 'primary' : 'black'" @click="toggle">
            {{
            value
            }}
          </v-btn>
        </v-slide-item>
      </v-slide-group>
      <!--  <div v-for="(my_value,indx) of valuelist" :key="indx">{{indx}} - {{my_value}}</div> -->
    </v-flex>
  </v-layout>
</template>

<script>
export default {
  name: "RapidToggleList",
  props: {
    valuelist: {
      type: Array,
      required: true
    },
    def_value: {
      type: String,
      required: true
    },
    mdi_icon_name: {
      type: String
    },
    list_caption: {
      type: String
    }
  },

  data() {
    return {
      sel_value: this.def_value
      //my_value_list: this.valuelist
    };
  },
  computed: {
    sel_value_index: {
      get() {
        return this.valuelist.findIndex(v => v === this.sel_value);
      },
      set(indx) {
        this.sel_value = this.valuelist[indx];
      }
    }
  },

  watch: {
    def_value(new_val) {
      this.sel_value = new_val;
      /* console.log(
        "Rapid Toggle " +
          this.mdi_icon_name +
          "  watch def_value:" +
          this.sel_value
      ); */
    }
  },
  methods: {
    valueChanged(indx) {
      /* console.log(
        "In valueChanged indx:" + indx + " value:" + this.valuelist[indx]
      ); */
      this.$emit("valueChanged", this.valuelist[indx]);
      /* let indx = this.valuelist.findIndex(v => v == new_val);
      if (indx >= 0) {
        this.$emit("valueChanged", new_val);
      } */
    }
  }
};
</script>
