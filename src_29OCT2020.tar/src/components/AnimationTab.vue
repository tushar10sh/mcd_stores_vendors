<template>
  <v-tab-item :key="tab_key" :value="`tab-${tab_key}`">
    <v-card
      style="overflow-y: auto; overflow-x: hidden"
      :max-height="componentheight"
    >
      <div v-show="anim_layer_list[sel_layer_index] !== undefined">
        <v-layout class="mt-2">
          <v-flex xs2 sm1>
            <v-btn x-small :disabled="playing" @click="loadNext(-1)">
              <v-icon style="display: grid">mdi-step-backward</v-icon>
            </v-btn>
          </v-flex>
          <v-flex xs2 sm1>
            <v-btn x-small @click="playAnimation()">
              <v-icon v-if="playing" style="display: grid">mdi-pause</v-icon>
              <v-icon v-else style="display: grid">mdi-play</v-icon>
            </v-btn>
          </v-flex>
          <v-flex xs2 sm1>
            <v-btn x-small :disabled="playing" @click="loadNext(1)">
              <v-icon style="display: grid">mdi-step-forward</v-icon>
            </v-btn>
          </v-flex>
          <v-flex offset-xs1 xs2 sm2>
            <v-label> {{ sel_timezone.caption }} </v-label>
          </v-flex>
        </v-layout>
        <v-layout>
          <v-flex v-if="current_index >= 0" xs7 sm6>
            {{ current_index + 1 }}/{{ animation_timelist.length }}:
            {{ current_time }}
          </v-flex>
        </v-layout>
      </div>

      <v-layout class="mt-2">
        <v-flex xs2 md1>
          <v-icon style="display: grid">mdi-layers</v-icon>
        </v-flex>

        <v-flex xs11 md11>
          <v-slide-group
            v-model="sel_layer_index"
            @change="changeLayer"
            mandatory
            center-active
            show-arrows
          >
            <v-slide-item
              v-for="(layer, indx) in anim_layer_list"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
                >{{
                  layer.layer_type.split("_")[0] +
                  "/" +
                  layer.attribution.split("/")[1]
                }}</v-btn
              >
            </v-slide-item>
          </v-slide-group>
        </v-flex>
      </v-layout>

      <v-layout class="mt-2" align-content-space-around text-xs-center>
        <v-flex xs2 md1>Start</v-flex>
        <v-flex xs9>
          <v-slide-group
            v-model="start_date_index"
            mandatory
            center-active
            show-arrows
            @change="updateStartTimeList"
          >
            <v-slide-item
              v-for="(date, indx) in datelist"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
                >{{ date.caption }}</v-btn
              >
            </v-slide-item>
          </v-slide-group>
        </v-flex>
      </v-layout>

      <v-layout class="mt-2" align-content-space-around text-xs-center>
        <v-flex xs1 md1>
          <v-icon style="display: grid">mdi-clock</v-icon>
        </v-flex>
        <v-flex xs9>
          <v-slide-group
            v-model="start_time_index"
            mandatory
            center-active
            show-arrows
            @change="updateAnimationTimeList"
          >
            <v-slide-item
              v-for="(time, indx) in start_timelist"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
                >{{ time.caption }}</v-btn
              >
            </v-slide-item>
          </v-slide-group>
        </v-flex>
      </v-layout>

      <v-layout class="mt-2" align-content-space-around text-xs-center>
        <v-flex xs1 md1>End</v-flex>
        <v-flex xs9>
          <v-slide-group
            v-model="end_date_index"
            mandatory
            center-active
            show-arrows
            @change="updateEndTimeList"
          >
            <v-slide-item
              v-for="(date, indx) in datelist"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
                >{{ date.caption }}</v-btn
              >
            </v-slide-item>
          </v-slide-group>
        </v-flex>
      </v-layout>

      <v-layout class="mt-2" align-content-space-around text-xs-center>
        <v-flex xs1 md1>
          <v-icon style="display: grid">mdi-clock</v-icon>
        </v-flex>
        <v-flex xs9>
          <v-slide-group
            v-model="end_time_index"
            mandatory
            center-active
            show-arrows
            @change="updateAnimationTimeList"
          >
            <v-slide-item
              v-for="(time, indx) in end_timelist"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
                >{{ time.caption }}</v-btn
              >
            </v-slide-item>
          </v-slide-group>
        </v-flex>
      </v-layout>
      <v-layout
        class="mt-2"
        align-content-space-around
        text-xs-center
      ></v-layout>
      <v-layout class="mt-2" align-content-space-around text-xs-center>
        <v-flex xs12 md4
          >Number of images: {{ animation_timelist.length }}</v-flex
        >
      </v-layout>

      <v-snackbar v-model="showError" color="error" :timeout="error_timeout">
        {{ error_message }}
      </v-snackbar>
    </v-card>
  </v-tab-item>
</template>
<script>
import { NCWMSHelper } from "../mixins";
import { mapState, mapMutations, mapGetters } from "vuex";

export default {
  data() {
    return {
      fps: 1,
      animationId: null,
      sel_layer_index: 0,
      start_date_index: 0,
      end_date_index: 0,
      start_time_index: 0,
      end_time_index: 0,
      caption_date_format: "DD-MMM-YY",
      wms_only_date_format: "YYYY-MM-DD",
      caption_time_format: "HH:mm:ss",
      sat_caption_time_format: "HH:mm",
      hscroll: true,
      current_time: "",
      current_index: -1,
      start_timelist: [],
      end_timelist: [],
      animation_timelist: [],
      anim_layer: undefined,
      playing: false,
      //current_layername: "",
      error_timeout: 2000,
      showError: false,
      error_message: "",
      fetch_from_network: false,
      fetched_timestep_map: {},
      current_layer_props: {},
    };
  },
  mixins: [NCWMSHelper],

  watch: {
    map_props: {
      deep: true,
      handler(new_props) {
        if (Object.keys(new_props).length > 0) {
          this.fetched_timestep_map = {};
        }
      },
    },
    anim_layer_list: {
      deep: true,
      handler(new_layer_list) {
        if (this.sel_layer_index > new_layer_list.length - 1) {
          this.sel_layer_index = new_layer_list.length - 1;
        }

        let shouldStop = this.arePropertiesDifferent(
          new_layer_list[this.sel_layer_index]
        );

        if (shouldStop) {
          this.stopAnimation();
          this.init();
        }
      },
    },
    sel_timezone: {
      deep: true,
      handler(new_timezone) {
        console.log("Time Zone changed animation tab:" + new_timezone);
        if (new_timezone !== undefined) {
          this.updateStartTimeList();
          this.updateEndTimeList();
          if (this.current_time !== "") {
            this.current_time = this.createCurrentTimeString();
          }
        }
      },
    },
  },

  computed: {
    fcst_ref_time() {
      if (this.is_model_tab) {
        let datesWithData = this.metadata.datesWithData;
        let fcst_hr = this.anim_layer_list[this.sel_layer_index].layerName
          .split("/")[0]
          .split("_")[1];
        return this.getFcstRefTimeAct(datesWithData, fcst_hr);
      } else {
        return undefined;
      }
    },
    componentheight: {
      get() {
        return this.mobileView ? "15vh" : "100vh";
      },
    },

    ...mapState([
      "raster_layer_list",
      "sel_timezone",
      "mobileView",
      "map_props",
    ]),
    ...mapGetters(["getFromMetadataCache", "getFromTSCache"]),
    anim_layer_list: {
      get() {
        return this.raster_layer_list.filter((layer) =>
          layer.layer_type.endsWith("raster")
        );
      },
    },
    isRGBLayer: {
      get() {
        return this.anim_layer_list[this.sel_layer_index].layerName.includes(
          ","
        );
      },
    },
    firstRGBLayer: {
      get() {
        return this.createArrayFromLayerName(
          this.anim_layer_list[this.sel_layer_index].layerName
        )[0];
      },
    },
    metadata: {
      get() {
        let sel_layer = this.anim_layer_list[this.sel_layer_index];
        if (sel_layer !== undefined) {
          let metadata_url = this.createLayerDetailsUrl(
            sel_layer.url,
            sel_layer.layerName
          );
          let metadata_arr = this.getFromMetadataCache(metadata_url);
          return metadata_arr[0];
        } else {
          return undefined;
        }
      },
    },
    is_sat_tab() {
      return this.anim_layer_list[
        this.sel_layer_index
      ].layer_type.startsWith("satellite");
    },
    is_model_tab() {
      return this.anim_layer_list[
        this.sel_layer_index
      ].layer_type.startsWith("model");
    },

    datelist: {
      get() {
        if (this.metadata !== undefined) {
          let sorted_date_list = this.getDateArray(
            this.metadata.datesWithData
          ).sort((d1, d2) => d1 - d2);

          let my_date_list = this.is_model_tab
            ? [sorted_date_list[0]]
            : sorted_date_list;
          let cap_date_list = this.createCaptionedDateList(
            my_date_list,
            this.caption_date_format
          );
          return cap_date_list;
        } else {
          return [];
        }
      },
    },

    imgs() {
      let out = this.getItemList(this.start_date_index, this.end_date_index);
      //console.log("imgs:" + out.length);
      return out;
    },
  },

  mounted() {
    this.init();
  },

  methods: {
    ...mapMutations([
      "setAnimationLayer",
      "updateAnimationLayer",
      "addToTSCache",
      "updateRaster",
    ]),
    async init() {
      this.start_date_index = this.datelist.length - 1;
      this.end_date_index = this.datelist.length - 1;
      /* console.log(
        "start_date_index:" +
          this.start_date_index +
          " end_date_index:" +
          this.end_date_index
      ); */
      this.updateStartTimeList();
      await this.updateEndTimeList();
      this.end_time_index = this.end_timelist.length - 1;
      this.updateAnimationTimeList();
      this.current_time = "";
      this.current_index = -1;
    },
    async updateLayer() {
      let was_playing = this.playing;
      if (this.playing) {
        this.stopAnimation();
      }
      await this.updateStartTimeList();
      await this.updateEndTimeList();
      if (was_playing) {
        this.playAnimation();
      }
    },
    async updateStartTimeList() {
      if (this.datelist[this.start_date_index] !== undefined) {
        console.log("In updateStartTimeList");
        this.start_timelist = await this.createTimeList(
          this.datelist[this.start_date_index].value
        );

        this.updateAnimationTimeList();
      }
    },
    async updateEndTimeList() {
      if (this.datelist[this.end_date_index] !== undefined) {
        this.end_timelist = await this.createTimeList(
          this.datelist[this.end_date_index].value
        );
        this.updateAnimationTimeList();
      }
    },

    async updateAnimationTimeList() {
      if (this.start_date_index >= 0 && this.end_date_index >= 0) {
        let start_indx = this.start_date_index,
          end_indx = this.end_date_index;

        let result = [];
        for (let indx = start_indx; indx < end_indx + 1; indx++) {
          let my_time_list = await this.createTimeList(
            this.datelist[indx].value
          );
          let st_tm_indx = indx == start_indx ? this.start_time_index : 0;
          let end_tm_indx =
            indx == end_indx ? this.end_time_index : my_time_list.length - 1;
          for (let indx2 = st_tm_indx; indx2 < end_tm_indx + 1; indx2++) {
            if (my_time_list[indx2] !== undefined) {
              result.push(my_time_list[indx2].value);
            }
          }
        }
        let was_playing = this.playing;
        if (was_playing) {
          this.stopAnimation();
        }
        this.animation_timelist = result;
        if (was_playing) {
          this.current_index = 0;

          this.playAnimation();
        }
      }
    },

    changeLayer() {
      this.stopAnimation();
      this.init();
    },

    stopAnimation() {
      if (this.animationId !== null) {
        window.clearInterval(this.animationId);
        this.animationId = null;
      }
      //console.log("playing:"+ this.playing);

      if (this.playing) {
        this.setRasterLayerVisibility(true);
        this.playing = false;
        /* if (this.is_model_tab) {
          let tm_value = this.animation_timelist[this.current_index];
          this.current_time =
            "F" +
            this.format1DigitTo2Digit(
              (tm_value.getTime() - this.fcst_ref_time.getTime()) /
                (3600 * 1000)
            );
        } else {
          this.current_time = this.createFormattedTimeString(
            this.animation_timelist[this.current_index],
            this.caption_date_format +
              " " +
              (this.is_sat_tab
                ? this.sat_caption_time_format
                : this.caption_time_format),

            this.sel_timezone.id
          );
        } */
        this.current_time = this.createCurrentTimeString();

        this.updateAnimationLayer({
          items: {
            visible: false,
          },
        });
      }
    },

    setRasterLayerVisibility(visibility) {
      let raster_layer = this.anim_layer_list[this.sel_layer_index];
      this.updateRaster({
        layer_type: raster_layer.layer_type,
        items: {
          visible: visibility,
        },
      });
    },

    async playAnimation() {
      if (this.playing) {
        this.stopAnimation();
      } else {
        if (this.animation_timelist.length <= 1) {
          this.error_message =
            "Animation Cannot be generated from single or zero image(s)";
          this.showError = true;
          return;
        }

        let start_time = this.animation_timelist[0];
        let end_time = this.animation_timelist[this.animation_timelist.length-1];
        let dur_in_hrs = (end_time.getTime() - start_time.getTime()) / (3600 * 1000);
        if (dur_in_hrs > 48) {
          this.error_message =
            "Animation duration cannot be more than 48 hours. Currently it is " + dur_in_hrs + " hours";
          this.showError = true;
          return;
        }
        
        

        this.setRasterLayerVisibility(false);
        let sel_layer = this.anim_layer_list[this.sel_layer_index];

        let local_anim_layer = this.deepCopy(sel_layer);

        if (this.current_index === -1) {
          this.current_index = 0;
        }
        this.setCurrentLayerProps(local_anim_layer);
        local_anim_layer.time = this.createFormattedDateTimeString(
          this.animation_timelist[this.current_index]
        );

        this.setAnimationLayer(local_anim_layer);
        let suffix =
          true !== this.fetched_timestep_map[local_anim_layer.time]
            ? "Loading..."
            : "";
        this.current_time = this.createCurrentTimeString() + " " + suffix;
        this.fetched_timestep_map[local_anim_layer.time] = true;

        let me = this;
        this.animationId = window.setInterval(function () {
          me.updateTime();
        }, 1000 / this.fps);
        this.playing = true;
      }
    },

    setCurrentLayerProps(layer) {
      if (layer.extParams.sld_body === undefined) {
        this.current_layer_props = {
          layerName: layer.layerName,
          sld_body: layer.extParams.sld_body,
        };
      } else {
        this.current_layer_props = {
          layerName: layer.layerName,
          style: layer.extParams.style,
          elevation: layer.extParams.elevation,
          COLORSCALERANGE: layer.extParams.COLORSCALERANGE,
        };
      }
    },

    arePropertiesDifferent(new_layer) {
      let different = false;
      if (new_layer.extParams.sld_body !== undefined) {
        if (this.current_layer_props.sld_body !== undefined) {
          different =
            new_layer.layerName !== this.current_layer_props.layerName ||
            this.current_layer_props.sld != new_layer.extParams.sld_body;
        } else {
          different = true;
        }
      } else {
        if (this.current_layer_props.sld_body !== undefined) {
          different = true;
        } else {
          different =
            new_layer.layerName !== this.current_layer_props.layerName ||
            new_layer.style !== this.current_layer_props.style ||
            new_layer.elevation !== this.current_layer_props.elevation ||
            new_layer.COLORSCALERANGE !==
              this.current_layer_props.COLORSCALERANGE;
        }
      }
      return different;
    },

    loadNext(incr) {
      this.current_index += incr;
      if (this.current_index < 0) {
        this.current_index = this.animation_timelist.length - 1;
      }

      this.current_index = this.current_index % this.animation_timelist.length;
      let frmt_dt_time = this.createFormattedDateTimeString(
        this.animation_timelist[this.current_index]
      );

      let suffix =
        this.playing && true !== this.fetched_timestep_map[frmt_dt_time]
          ? "Loading..."
          : "";
      this.current_time = this.createCurrentTimeString();
      this.current_time += " " + suffix;

      this.fetched_timestep_map[frmt_dt_time] = true;
      this.updateAnimationLayer({
        items: {
          time: frmt_dt_time,
          visible: true,
        },
      });
    },
    updateTime() {
      this.loadNext(1);
    },
    createCurrentTimeString() {
      let out_time_str = undefined;
      if (this.is_model_tab) {
        let tm_value = this.animation_timelist[this.current_index];
        out_time_str =
          "F" +
          this.format1DigitTo2Digit(
            (tm_value.getTime() - this.fcst_ref_time.getTime()) / (3600 * 1000)
          );
      } else {
        out_time_str = this.createFormattedTimeString(
          this.animation_timelist[this.current_index],
          this.caption_date_format +
            " " +
            (this.is_sat_tab
              ? this.sat_caption_time_format
              : this.caption_time_format),

          this.sel_timezone.id
        );
      }
      return out_time_str;
    },

    async createTimeList(mydate) {
      let sel_layer = this.anim_layer_list[this.sel_layer_index];
      let date_str = this.creatFormattedDateString(
        mydate,
        this.wms_only_date_format
      );

      let single_layer_name = this.isRGBLayer
        ? this.firstRGBLayer
        : sel_layer.layerName;
      let timesteps_url = this.createTimeStepsUrl(
        sel_layer.url,
        single_layer_name,
        date_str
      );
      let new_times = this.getFromTSCache(timesteps_url);

      if (new_times === undefined) {
        let fetched_ts_data = await this.fetchUrl([timesteps_url]);
        let ts_data = fetched_ts_data[0].timesteps;
        new_times = this.getLayerTimes([mydate], [ts_data]);
        this.addToTSCache({ url: timesteps_url, val: new_times });
      }
      console.log("mydate:" + mydate);
      let sorted_times = new_times.sort(
        (t1, t2) => t1.getTime() - t2.getTime()
      );
      return this.createCaptionedTimeList(
        sorted_times,
        mydate,
        this.is_sat_tab
          ? this.sat_caption_time_format
          : this.caption_time_format,
        this.sel_timezone.id,
        this.is_model_tab,
        this.fcst_ref_time
      );
    },
  },

  props: {
    tab_key: {
      type: Number,
      required: true,
    },
  },
};
</script>
