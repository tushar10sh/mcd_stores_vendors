<template>
  <div
    v-show="my_probe_info !== undefined && my_probe_info.location.length > 0"
  >
    <v-layout ref="vpchart" id="vpchart">
      <v-flex xs12>
        <svg class="vpchart" />
      </v-flex>
    </v-layout>
    <v-layout>
      <v-flex xs2>Y-Axis:</v-flex>
      <v-flex xs10>
        <v-range-slider
          thumb-label="always"
          thumb-size="20"
          height="10"
          color="white"
          thumb-color="primary"
          :min="min_indx"
          :max="100"
          v-model="slider_range"
          :value="slider_range"
          @end="changeRange"
          @click="changeRange"
        >
          <template v-slot:thumb-label="{ value }">{{
            getThumbLabel(value)
          }}</template>
        </v-range-slider>
      </v-flex>
    </v-layout>
    <v-layout>
      <v-flex xs12>
        <div v-html="probe_value" />
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
import d3 from "../plugins/D3Importer.js";
import { NCWMSHelper, FetchHelper } from "../mixins/";
import { mapGetters } from "vuex";
export default {
  name: "VerticalProfile",
  mixins: [NCWMSHelper, FetchHelper],
  computed: {
    ...mapGetters(["getFromMetadataCache"]),
  },
  data() {
    return {
      margin: undefined,
      width: 0,
      height: 0,
      min_indx: 0,
      circle_radius: 3,
      xScale: undefined,
      yScale: undefined,
      values_arr: undefined,
      layerName: "",
      units_string: "",
      param_description: "",
      xAxis: undefined,
      yAxis: undefined,
      yAxisRight: undefined,
      gXAxis: undefined,
      gYAxis: undefined,
      gLines: undefined,
      svg: undefined,
      //tooltip: undefined,
      tooltip_rect: undefined,
      graph: undefined,
      my_probe_info: undefined,
      pressure_values: [],
      slider_range: [0, 100],
      probe_value: "",
      cursorLine: undefined,
    };
  },
  props: {
    vp_probe_info: {
      type: Object,
      required: false,
    },
  },
  mounted() {
    if (this.vp_probe_info !== undefined) {
      this.my_probe_info = this.deepCopy(this.vp_probe_info);
      this.initialize();
      this.plot();
    }
  },

  watch: {
    vp_probe_info: {
      handler(new_val) {
        console.log("In vp watch");
        if (new_val !== undefined && new_val.location.length > 0) {
          if (
            this.my_probe_info === undefined ||
            this.isVPProbeInfoChanged(this.my_probe_info, new_val)
          ) {
            let metadata = this.getMetadata(new_val.layer);
            if (metadata.zaxis !== undefined) {
              this.my_probe_info = this.deepCopy(new_val);
              this.initialize();

              this.plot();
            }
          }
        }
      },
      deep: true,
    },
  },

  methods: {
    getThumbLabel(value) {
      let slope =
        (this.pressure_values[this.pressure_values.length - 1] -
          this.pressure_values[0]) /
        100;
      return (this.pressure_values[0] + slope * value).toFixed(1);

      /*console.log("value:" + value + " indx:" + indx);
      return this.pressure_values[indx];*/
    },
    getMetadata(layer) {
      let metadata_url = this.createLayerDetailsUrl(layer.url, layer.layerName);
      let metadata_arr = this.getFromMetadataCache(metadata_url);
      return metadata_arr[0];
    },
    changeRange() {
      let start_plevel = this.getThumbLabel(this.slider_range[0]);
      let end_plevel = this.getThumbLabel(this.slider_range[1]);

      this.yScale.domain([end_plevel, start_plevel]);
      this.updateChart(this.xScale, this.yScale);
    },
    initialize() {
      this.layerName = this.my_probe_info.layer.layerName;
      this.values_arr = [];
      let metadata = this.getMetadata(this.my_probe_info.layer);

      //let metadata = metadata_arr[0];
      this.units_string = metadata.units;
    },

    async getData() {
      let url = this.getFeatureInfoUrl(
        this.my_probe_info.layer,
        this.my_probe_info.map_bbox,
        this.my_probe_info.map_size,
        this.my_probe_info.scan_pix,
        "GetVerticalProfile",
        this.my_probe_info.layer.time,
        "text/json"
      );

      //let response = await d3.json(url);
      let fetched_vp_response = await this.fetchUrl([url]);
      let response = fetched_vp_response[0];

      this.pressure_values = response.domain.axes.z.values;
      console.log("this.pressure_values:" + this.pressure_values);

      let ranges = response.ranges;
      let parameters = response.parameters;
      let param_names = Object.keys(parameters);
      this.param_description = param_names[0];
      let param_values = ranges[param_names[0]].values;

      let num_levels = this.pressure_values.length;
      console.log("param_values:" + param_values);

      let values_arr = [];
      for (let indx = 0; indx < num_levels; indx++) {
        if (param_values[indx] !== null) {
          values_arr.push({
            pressure: this.pressure_values[indx],
            param_value: param_values[indx],
          });
        }
      }
      return values_arr;
    },
    zoomed() {
      //  console.log("zoomed");
      let transform = d3.getEvent().transform;

      let yNewScale = transform.rescaleY(this.yScale);
      let xNewScale = transform.rescaleX(this.xScale);

      this.updateChart(xNewScale, yNewScale);
    },
    updateChart(xNewScale, yNewScale) {
      this.yAxis = this.yAxis.scale(yNewScale);
      this.gYAxis.call(this.yAxis);

      this.xAxis = this.xAxis.scale(xNewScale);
      this.gXAxis.call(this.xAxis);

      let me = this;
      //let pressure_vals = this.values_arr.map(value => value.pressure);
      this.gLines.attr(
        "d",
        d3
          .line()
          .x((d) => xNewScale(d.param_value))
          .y((d) => yNewScale(d.pressure))
      );

      this.svg
        .selectAll("circle")
        .attr("cx", (d) => xNewScale(d.param_value))
        .attr("cy", (d) => yNewScale(d.pressure));

      this.tooltip_rect.on("mousemove", function () {
        let evt = d3.mouse(this);
        me.mousemove(evt, me.pressure_values, yNewScale);
      });
    },
    async plot() {
      this.margin = { top: 5, right: 5, bottom: 40, left: 40 };

      if (this.width === 0) {
        let div_width = parseInt(this.$refs.vpchart.clientWidth);
        //console.log("div_width:" + div_width);
        this.width = div_width - this.margin.left - this.margin.right;
      }
      if (this.height === 0) {
        let div_height = parseInt(window.innerHeight * 0.25);
        this.height = div_height - this.margin.top - this.margin.bottom;
      }

      //console.log("width:" + this.width + " height:" + this.height);
      /* this.width = 760 - this.margin.left - this.margin.right;
      this.height = 400 - this.margin.top - this.margin.bottom; */

      this.values_arr = await this.getData();

      /*this.slider_range = [
        this.pressure_values[0],
        this.pressure_values[this.pressure_values.length - 1]
      ];*/

      console.log(
        "slider_range:" +
          this.slider_range +
          " thsi.pressure_values:" +
          this.pressure_values.length
      );

      this.values_arr = this.values_arr.reverse();
      //let pressure_vals = this.values_arr.map(value => value.pressure);
      let param_vals = this.values_arr.map((value) => value.param_value);

      this.xScale = d3
        .scaleLinear()
        .range([0, this.width])
        .domain([d3.min(param_vals) - 2, d3.max(param_vals) + 2]);

      this.yScale = d3
        //.scaleSymlog()
        .scaleLinear()
        .domain([d3.max(this.pressure_values), d3.min(this.pressure_values)])
        .range([this.height, 0])
        .nice();

      let pan = d3
        .zoom()
        .scaleExtent([1, 50])

        .on("zoom", () => {
          this.zoomed();
        });

      if (this.svg !== undefined) {
        this.svg.selectAll("*").remove();
      } else {
        this.svg = d3
          .select(".vpchart")
          .attr("width", this.width + this.margin.left + this.margin.right)
          .attr("height", this.height + this.margin.top + this.margin.bottom)
          .call(pan)
          .append("g")
          .attr(
            "transform",
            "translate(" + this.margin.left + "," + this.margin.top + ")"
          );
      }

      this.svg
        .append("clipPath")
        .attr("id", "axis-clip")
        .append("rect")
        .attr("class", "overlay")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height);

      let xaxis_caption = this.param_description;
      if (this.units_string !== "") {
        xaxis_caption += " (" + this.units_string + ")";
      }

      this.xAxis = d3
        .axisBottom()
        .scale(this.xScale)
        .ticks(5)
        .tickSize(-this.height);

      this.gXAxis = this.svg
        .append("g")
        .attr("class", "grid")
        .attr("transform", "translate(0," + this.height + ")")
        .call(this.xAxis);

      this.gXAxis
        .append("text")
        .attr("transform", "translate(" + this.width / 2 + ",30)")
        .attr("fill", "currentColor")
        .style("text-anchor", "middle")
        .text(xaxis_caption);

      this.yAxis = d3
        .axisLeft()
        .scale(this.yScale)
        .ticks(4)
        //.tickValues(this.plines)
        .tickSize(-this.width, 0, 0);

      this.gYAxis = this.svg
        .append("g")
        .attr("class", "leftygrid")
        .call(this.yAxis);

      this.gYAxis
        .append("text")
        .attr(
          "transform",
          "translate(" +
            (-this.margin.left + 10) +
            "," +
            this.height / 2 +
            ") rotate(-90) "
        )
        .attr("fill", "currentColor")
        .style("text-anchor", "middle")
        .text("Pressure(mb)");

      let me = this;
      this.gLines = this.svg
        .append("path")
        .attr("clip-path", "url(#axis-clip)")
        .datum(this.values_arr)
        .attr(
          "d",
          d3
            .line()
            .x((d) => me.xScale(d.param_value))
            .y((d) => me.yScale(d.pressure))
        )
        .attr("fill", "none")
        .attr("stroke", "steelblue");

      /* this.tooltip = d3
        .select("body")
        .append("div")
        .attr("class", "tooltip")
        .style("opactiy", 0); */

      this.cursorLine = this.svg
        .append("g")
        .attr("class", "mouse-over-effects")
        .append("path")
        .attr("class", "cursorLine")
        .style("stroke", "white")
        .style("stroke-width", "1px")
        .style("opacity", "0");

      this.svg
        .selectAll("circle")
        .data(this.values_arr)
        .enter()
        .append("circle")
        .attr("clip-path", "url(#axis-clip)")
        .attr("fill", "steelblue")
        .attr("stroke", "none")
        .attr("cx", (d) => me.xScale(d.param_value))
        .attr("cy", (d) => me.yScale(d.pressure))
        .attr("r", this.circle_radius);

      this.tooltip_rect = this.svg
        .append("rect")
        .attr("class", "overlay")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", this.width)
        .attr("height", this.height);

      this.tooltip_rect
        .on("mouseleave", function () {
          me.probe_value = "Pressure: Value:";
          me.cursorLine.style("opacity", "0");
        })
        .on("mousemove", function () {
          //console.log("mousemove");
          let evt = d3.mouse(this);
          me.mousemove(evt, me.pressure_values, me.yScale);
        });
    },
    mousemove(evt, pressure_vals, my_yscale) {
      //console.log("yscale domain:" + my_yscale.domain());
      let mousepressure = my_yscale.invert(evt[1]);
      console.log("mousepressure:" + mousepressure);
      let sorted_pressure_vals = pressure_vals.sort((a, b) => a - b);
      let bisect_pressure = d3.bisector((d) => d);
      let indx = bisect_pressure.left(sorted_pressure_vals, mousepressure, 1);
      let d0 = sorted_pressure_vals[indx - 1];
      let d1 = sorted_pressure_vals[indx];
      let probe_pressure = mousepressure - d0 > d1 - mousepressure ? d1 : d0;

      let entry = this.values_arr.find((val) => {
        return val.pressure === probe_pressure;
      });

      //let sorted_pressure_vals = pressure_vals.sort((a, b) => a - b);

      let param_y_coord = my_yscale(probe_pressure);
      //console.log("param_x_coord:" + param_x_coord);

      let me = this;
      this.cursorLine.style("opacity", "1").attr("d", function () {
        var d = "M" + me.width + "," + param_y_coord;
        d += " " + 0 + "," + param_y_coord;
        //console.log("d:" + d);
        return d;
      });

      let param_val = entry.param_value;
      this.probe_value =
        "Pressure:" +
        probe_pressure.toFixed(2) +
        " Value: " +
        param_val.toFixed(2) +
        " " +
        this.units_string;

      /* let pos = [me.getXPosition(d3.getEvent().pageX, 20), d3.getEvent().pageY];
      me.showCaption(probe_pressure, pos); */
    },

    /* showCaption(pressure, pos) {
      let entry = this.values_arr.find(val => {
        return val.pressure === pressure;
      });
      let param_val = entry.param_value;
      let caption =
        "Pressure:" +
        pressure.toFixed(2) +
        " mb " +
        "<br/>" +
        this.param_description +
        ":" +
        param_val.toFixed(2) +
        " " +
        this.units_string;
      this.tooltip.style("opacity", 1);
      this.tooltip
        .html(caption)
        .style("left", pos[0] + "px")
        .style("top", pos[1] + "px");
    },
    getXPosition(event_x, cushion) {
      let tt_width = parseInt(this.tooltip.style("width"), 10);
      let chart_width = parseInt(d3.select("svg").attr("width"), 10);
      let xpos = 0;
      if (event_x + tt_width > chart_width) {
        xpos = event_x - cushion - tt_width;
      } else {
        xpos = event_x + cushion;
      }
      return parseInt(xpos);
    } */
  },
};
</script>
<style>
.overlay {
  fill: none;
  pointer-events: all;
}
.tooltip {
  /*font-family: Georgia;*/
  position: absolute;
  background: #fff;
  box-shadow: 0 6px 8px rgba(52, 73, 94, 0.2), 0 1px 1px rgba(52, 73, 94, 0.1);
  z-index: 10;
  transition: all 0.2s ease-out;

  font-size: 12px;
  z-index: 9999;
}

.grid .tick {
  stroke: white;
  opacity: 0.8;
}
.grid line {
  stroke: white;
  stroke-opacity: 0.5;
  shape-rendering: crispEdges;
}

.leftygrid .tick {
  stroke: white;
  opacity: 0.8;
}
.leftygrid line {
  stroke: grey;
  stroke-opacity: 0.5;
  shape-rendering: crispEdges;
}

.rightgrid .tick {
  opacity: 0.8;
}
.rightygrid line {
  stroke: grey;
  stroke-opacity: 0.5;
  stroke-dasharray: 10 5;
  shape-rendering: crispEdges;
}
</style>