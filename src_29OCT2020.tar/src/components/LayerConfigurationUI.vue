<template>
  <v-card dark>
    <v-system-bar class="mb-md-5" color="primary">
      <v-spacer></v-spacer>
      <v-icon @click="setLayerListOpen(false)">mdi-close</v-icon>
    </v-system-bar>

    <v-card-text>
      <v-layout row>
        <v-flex>
          <v-tabs
            dark
            next-icon="mdi-arrow-right-bold-box-outline"
            prev-icon="mdi-arrow-left-bold-box-outline"
            v-model="active"
            color="white"
            show-arrows
            max-height="300px"
            slider-color="primary"
          >
            <v-tabs-slider color="yellow"></v-tabs-slider>
            <v-tab v-for="(t, i) in tabs" :key="i" :href="`#tab-${i}`">{{
              t.title
            }}</v-tab>
          </v-tabs>

          <v-tabs-items dark v-model="active">
            <v-tab-item
              color="white"
              v-for="(t, i) in tabs"
              :key="i"
              :value="`tab-${i}`"
            >
              <component
                v-bind:is="t.tab_component"
                :tab_layer_type="t.layer_type"
                :layer_list="t.layer_list"
                :tab_key="i"
                :is_model_data="t.is_model_data"
              />
            </v-tab-item>
          </v-tabs-items>
        </v-flex>
      </v-layout>
    </v-card-text>
  </v-card>
</template>

<script>
import { LocalStorageHelper } from "../mixins/";
import { mapMutations, mapGetters } from "vuex";
export default {
  mixins: [LocalStorageHelper],
  components: {
    SatTab: () => import(/*webpackChunkName: "SatTab"*/ "./SatTab"),
    ProbeTab: () => import(/*webpackChunkName: "ProbeTab"*/ "./ProbeTab"),
    AnimationTab: () =>
      import(/*webpackChunkName: "AnimationTab"*/ "./AnimationTab"),
    VecTab: () => import(/*webpackChunkName: "VecTab"*/ "./VecTab"),
    BasemapTab: () => import(/*webpackChunkName: "BasemapTab"*/ "./BasemapTab"),
  },
  data() {
    return {
      active: "tab-0",
    };
  },

  name: "LayerConfigurationUI",
  methods: {
    ...mapMutations(["setLayerListOpen"]),
    changeTab() {
      console.log("changeTab");
    },
  },
  computed: {
    ...mapGetters(["getRasterLayer", "getAddlLayersListByCat"]),

    vector_layers() {
      return this.getAddlLayersListByCat("vector");
    },
    basemap_layers() {
      return this.getAddlLayersListByCat("basemap");
    },

    tabs: {
      get() {
        let mtabs = [];
        let sat_layer = this.getRasterLayer("satellite_raster");
        let model_layer = this.getRasterLayer("model_raster");
        let radial_layer = this.getRasterLayer("radial_raster");
        if (sat_layer && model_layer && radial_layer) {
          //console.log("adding sat layer");
          let sat_proc_prods = this.getJSONObjFromLocalStorage(
            "satellite_raster"
          );

          mtabs.push({
            title: "Satellite",
            tab_component: "SatTab",
            layer_type: "satellite_raster",
            layer_list: sat_proc_prods,
          });

          //console.log("adding model layer");
          let model_proc_prods = this.getJSONObjFromLocalStorage(
            "model_raster"
          );
          mtabs.push({
            title: "Model",
            tab_component: "SatTab",
            layer_type: "model_raster",
            layer_list: model_proc_prods,
            is_model_data: true,
          });

          //console.log("adding radial layer");
          let radial_prods = this.getJSONObjFromLocalStorage("radial_raster");
          mtabs.push({
            title: "Radar",
            tab_component: "SatTab",
            layer_type: "radial_raster",
            layer_list: radial_prods,
            is_model_data: false,
          });

          mtabs.push({
            title: "Probe",
            tab_component: "ProbeTab",
          });
          mtabs.push({
            title: "Animation",
            tab_component: "AnimationTab",
          });
        }
        if (this.vector_layers !== undefined && this.vector_layers.length) {
          mtabs.push({
            title: "Vectors",
            tab_component: "VecTab",
            layer_type: "vector",
          });
        }
        if (this.basemap_layers !== undefined && this.basemap_layers.length) {
          mtabs.push({
            title: "Base Layers",
            tab_component: "BasemapTab",
            layer_type: "basemap",
          });
        }
        //console.log("mtabs:" + mtabs.length);

        return mtabs;
      },
    },
  },
};
</script>
