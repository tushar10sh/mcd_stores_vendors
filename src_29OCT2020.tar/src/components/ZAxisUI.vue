<template>
  <v-layout v-if="zaxis !== undefined">
    <v-flex xs1>Zaxis</v-flex>
    <v-flex xs11>
      <v-slide-group v-model="sel_z_index" mandatory center-active show-arrows>
        <v-slide-item
          v-for="(zval,indx) in zaxis.values"
          :key="indx"
          v-slot:default="{ active, toggle }"
        >
          <v-btn
            class="text_transform_none"
            small
            :color="active ? 'primary' : 'black'"
            @click="toggle"
          >{{ zval.toFixed(1)}} {{ zaxis.units}}</v-btn>
        </v-slide-item>
      </v-slide-group>
    </v-flex>
  </v-layout>
</template>
<script>
import { mapGetters, mapMutations } from "vuex";
//import moment from "moment";
import { NCWMSHelper } from "../mixins/";
export default {
  mixins: [NCWMSHelper],
  props: {
    layer_type: {
      type: String,
      required: true
    }
  },

  computed: {
    ...mapGetters([
      "getFromMetadataCache",
      "getRasterLayer",
      "getFromMinMaxCache"
    ]),
    zaxis: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);

        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );

        let metadata_arr = this.getFromMetadataCache(metadata_url);

        return metadata_arr[0].zaxis;
      }
    },
    sel_z_index: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        let elevation = raster_layer.extParams.elevation;
        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        let metadata = metadata_arr[0];
        return metadata.zaxis === undefined
          ? 0
          : metadata.zaxis.values.findIndex(el => el == elevation);
      },
      set(indx) {
        this.changeZValue(indx);
        this.$emit("valueChanged", indx);
      }
    }
  },
  methods: {
    ...mapMutations(["addToMinMaxCache", "updateRaster"]),
    //...mapActions(["updateRaster"]),
    async changeZValue(indx) {
      let raster_layer = this.getRasterLayer(this.layer_type);

      let new_extParams = {};

      for (let key of Object.keys(raster_layer.extParams)) {
        new_extParams[key] = raster_layer.extParams[key];
      }
      new_extParams.elevation = this.zaxis.values[indx];

      if (raster_layer.autoscl) {
        //let ds = this.getURLParameter(raster_layer.url, "dataset");
        let layer_info = {
          url_prefix: raster_layer.url,
          sat_projection: raster_layer.projection,
          wms_version: raster_layer.version,
          layer_name: raster_layer.layerName
        };

        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        let elevation_values = [this.zaxis.values[indx]];

        let layerRangeUrls = this.createLayerRangeUrl(
          layer_info,
          metadata_arr,
          raster_layer.time,
          //new Date(moment(raster_layer.time + "Z", "YYYY-MM-DDhh:mmZ")),
          elevation_values
        );
        let mm_response_arr = this.getFromMinMaxCache(layerRangeUrls);

        if (mm_response_arr.length === 0) {
          mm_response_arr = await this.fetchUrl(layerRangeUrls);
          console.log(
            "Add minmax to cache:" +
              mm_response_arr[0].min +
              " " +
              mm_response_arr[0].max
          );
          this.addToMinMaxCache({ url: layerRangeUrls, val: mm_response_arr });
        } else {
          console.log("fetched minmax from cache");
        }
        let scaleRange = [mm_response_arr[0].min, mm_response_arr[0].max];
        /* console.log(
          "scaleRange for pressure level:" +
            this.zaxis.values[indx] +
            ":" +
            scaleRange[0] +
            "," +
            scaleRange[1]
        ); */

        new_extParams["COLORSCALERANGE"] = scaleRange[0] + "," + scaleRange[1];
      }
      this.updateRaster({
        layer_type: raster_layer.layer_type,
        items: {
          extParams: new_extParams
        }
      });
    }
  }
};
</script>
