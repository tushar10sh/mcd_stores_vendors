<template>
  <div>
    <v-layout class="mt-1 ml-2" row wrap>
      <v-flex xs2 md3>
        <v-btn-toggle class="mt-2" v-model="contour_visibility" @change="showContours">
          <v-btn :color="contoursVisible ? 'primary' : 'black'" small>Contours</v-btn>
        </v-btn-toggle>
      </v-flex>
    </v-layout>
    <div v-if="contoursVisible">
      <v-layout class="mt-2">
        <!-- <v-flex xs2 v-if="contour_visibility !== undefined">
      <v-label>Interval:</v-label>
        </v-flex>-->
        <v-flex offset-xs1 xs2 md2 lg1>
          <v-text-field
            v-model="cont_info.cnt_int"
            class="mt-0 pt-0"
            hide-details
            single-line
            type="number"
            style="width:60px"
          ></v-text-field>
        </v-flex>
        <v-flex xs4 md3 lg2>
          <v-slide-group v-model="sel_contstyle_indx" mandatory center-active show-arrows>
            <v-slide-item
              v-for="(cs, indx) in contour_styles"
              :key="indx"
              v-slot:default="{ active, toggle }"
            >
              <v-btn
                class="text_transform_none"
                small
                :color="active ? 'primary' : 'black'"
                @click="toggle"
              >{{ cs.caption }}</v-btn>
            </v-slide-item>
          </v-slide-group>
        </v-flex>
        <v-flex xs1 md1 lg1>
          <v-btn small @click="applyContourProps()">
            <v-icon small style="display:grid">mdi-check</v-icon>
          </v-btn>
        </v-flex>
      </v-layout>
      <v-layout class="mt-2">
        <v-flex xs8 md6 lg4 offset-xs1>
          <v-color-picker light hide-canvas hide-mode-switch v-model="contour_color"></v-color-picker>
        </v-flex>
      </v-layout>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapMutations } from "vuex";
import { SLDHelpers, NCWMSHelper } from "../mixins";
import sld_json from "../assets/sld_locations.json";
export default {
  props: {
    raster_layer_type: {
      type: String,
      required: true
    }
  },
  mixins: [SLDHelpers, NCWMSHelper],
  computed: {
    ...mapGetters(["getRasterLayer", "getFromSLDCache"]),
    raster_layer: {
      get() {
        return this.getRasterLayer(this.raster_layer_type);
      }
    },
    contoursVisible: {
      get() {
        return this.contour_visibility !== undefined;
      },
      set(value) {
        this.contour_visibility = value;
      }
    },
    contour_layer_type: {
      get() {
        return this.raster_layer_type.replace("raster", "contours");
      }
    }
  },
  watch: {
    raster_layer: {
      handler(new_layer) {
        let contour_layer = this.getRasterLayer(this.contour_layer_type);
        if (contour_layer === undefined) {
          if (this.contoursVisible) {
            this.updateContours(new_layer);
          }
        } else {
          if (contour_layer.visible) {
            this.updateContours(new_layer);
          }
        }
      },
      deep: true
    }
  },
  data() {
    return {
      contour_visibility: undefined,
      cont_info: { cnt_min: 0, cnt_max: 0, cnt_int: 0 },
      contour_color: "#EBFF00",
      contour_styles: [
        {
          id: "SOLID",
          caption: "___"
        },
        { id: "DASHED", caption: "_ _ _" }
      ],
      sel_contstyle_indx: 0
    };
  },
  /* created() {
    console.log("Contours widget created");
  }, */
  methods: {
    ...mapMutations(["addRasterLayer", "addToSLDCache", "updateRaster"]),
    //...mapActions(["updateRaster"]),
    async showContours() {
      //console.log("In show contours");
      let contour_layer = this.getRasterLayer(this.contour_layer_type);
      if (this.contour_visibility !== undefined) {
        if (contour_layer === undefined) {
          contour_layer = await this.createContourLayerObject(
            this.raster_layer
          );
          this.addRasterLayer(contour_layer);
        } else {
          //TODO: Check if the layer has changed
          let contour_layer = this.getRasterLayer(this.contour_layer_type);
          if (
            contour_layer.layerName !== this.raster_layer.layerName ||
            contour_layer.time !== this.raster_layer.time
          ) {
            this.updateContours(this.raster_layer);
          } else {
            this.updateRaster({
              layer_type: contour_layer.layer_type,
              items: {
                visible: true
              }
            });
          }
        }
      } else {
        this.updateRaster({
          layer_type: contour_layer.layer_type,
          items: {
            visible: false
          }
        });
      }
    },

    applyContourProps() {
      let contour_layer = this.getRasterLayer(this.contour_layer_type);

      //let full_layer_name = contour_layer.layerName;
      let sld_xml = contour_layer.extParams.sld_body;
      let updated_sld = this.updateContourSLD(
        sld_xml,
        contour_layer.layerName,
        this.cont_info,
        this.contour_color,
        this.contour_styles[this.sel_contstyle_indx].id
      );

      let new_extParams = {};
      for (let key of Object.keys(contour_layer.extParams)) {
        new_extParams[key] = contour_layer.extParams[key];
      }
      new_extParams.sld_body = updated_sld;
      //console.log("updated_sld:" + updated_sld);
      this.updateRaster({
        layer_type: this.contour_layer_type,
        items: {
          extParams: new_extParams
        }
      });
    },

    async createContourLayerObject(new_raster_layer) {
      let contour_layer = this.deepCopy(new_raster_layer);

      contour_layer.layer_type = this.contour_layer_type;

      let curr_range = new_raster_layer.extParams.COLORSCALERANGE.split(",");

      this.cont_info = this.calculateContInfo(
        Number.parseFloat(curr_range[0]),
        Number.parseFloat(curr_range[1])
      );

      /*console.log("cont_info:" + this.cont_info);
      console.log(
        "contour_style:" + this.contour_styles[this.sel_contstyle_indx].id
      );*/

      let url = sld_json.prefix + "/" + sld_json.slds.single_color_contour;
      let sld_xml = this.getFromSLDCache(url);

      let not_found = sld_json === undefined;

      //console.log("contour layername:" + new_raster_layer.layerName);

      contour_layer.extParams.sld_body = await this.getContourSLD(
        url,
        sld_xml,
        new_raster_layer.layerName,
        this.cont_info,
        this.contour_color,
        this.contour_styles[this.sel_contstyle_indx].id
      );
      if (not_found) {
        this.addToSLDCache({ sld: url, val: contour_layer.extParams.sld_body });
      }
      contour_layer.layer_type = this.contour_layer_type;
      //console.log("sld:" + contour_layer.extParams.sld_body);
      return contour_layer;
    },

    async updateContours(new_raster_layer) {
      //console.log("In updateContours");
      let contour_layer = await this.createContourLayerObject(new_raster_layer);
      //console.log("contour_layer_type:" + this.contour_layer_type);
      this.updateRaster({
        layer_type: this.contour_layer_type,
        items: {
          time: contour_layer.time,
          layerName: contour_layer.layerName,
          extParams: contour_layer.extParams,
          visible: true
        }
      });
    }
  }
};
</script>
