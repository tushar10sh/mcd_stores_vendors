<template>
  <div>
    <RapidVectorLayer
      v-for="(layer, index) in vector_layers"
      :key="layer.url + '_' + layer.layerName"
      :vector_layer="layer"
      :index="layer_offset + index"
      :category="category"
    />
  </div>
</template>
<script>
import RapidVectorLayer from "./RapidVectorLayer.vue";
import { mapGetters, mapMutations } from "vuex";
import { VectorSLDHelper } from "../mixins/";

export default {
  name: "RapidVectorLayersList",
  created() {
    this.createVectorLayers();
  },
  components: {
    RapidVectorLayer,
  },
  mixins: [VectorSLDHelper],
  computed: {
    ...mapGetters(["getAddlLayersListByCat"]),
    vector_layers() {
      return this.getAddlLayersListByCat(this.category);
    },
  },

  methods: {
    ...mapMutations(["setAdditionLayerList"]),
    createVectorLayers() {
      let sources = this.layers_config["sources"];
      this.layer_offset = this.layers_config["layer_offset"];
      let local_layers_list = [];
      let projection = this.layers_config["projection"];
      let img_format = this.layers_config["img_format"];
      let version = this.layers_config["version"];
      let opacity = this.layers_config["opacity"];
      for (let source of sources) {
        let source_projection = source.projection;
        let source_version = source.version;
        version = source_version !== undefined ? source_version : version;
        source_projection =
          source_projection === undefined ? projection : source_projection;

        let layers_list = source.layers.map((layer) => {
          let extParams = {};
          if (layer.sld !== undefined) {
            let decoded_sld = this.decodeSLD(layer.sld);
            extParams = {
              sld_body: this.createSLD(layer.layerName, decoded_sld),
            };
          }

          layer = Object.assign(layer, {
            projection: source_projection,
            url: source.url,
            version: version,
            img_format: img_format,
            attribution:
              layer.attribution === undefined
                ? layer.layerName
                : layer.attribution,
            opacity: layer.opacity === undefined ? opacity : layer.opacity,
            extParams: extParams,
          });

          return layer;
        });
        local_layers_list = local_layers_list.concat(layers_list);
      }
      this.setAdditionLayerList({
        cat: this.category,
        layers_list: local_layers_list,
      });
    },
  },
  data() {
    return {
      layer_offset: 0,
    };
  },
  props: {
    layers_config: {
      type: Object,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
  },
};
</script>
