<template>
  <div>
    <vl-layer-tile
      v-if="satlayer != undefined"
      :key="satlayer.url + '_' + satlayer.layerName"
      :z-index="index"
      :opacity="satlayer.opacity"
      :visible="satlayer.visible"
      :minResolution="satlayer.minResolution"
      :maxResolution="satlayer.maxResolution"
    >
      <vl-source-wms
        :url="satlayer.url"
        :version="satlayer.version"
        :layers="satlayer.layerName"
        :projection="satlayer.projection"
        :img_format="satlayer.img_format"
        :attributions="satlayer.attribution"
        :time="satlayer.time"
        :extParams="satlayer.extParams"
      ></vl-source-wms>
    </vl-layer-tile>

    <vl-layer-tile
      v-if="sat_contourlayer != undefined"
      :key="
        sat_contourlayer.url + '_' + sat_contourlayer.layerName + '_contours'
      "
      :z-index="index + 1"
      :opacity="sat_contourlayer.opacity"
      :visible="sat_contourlayer.visible"
    >
      <vl-source-wms
        :url="sat_contourlayer.url"
        :version="sat_contourlayer.version"
        :layers="sat_contourlayer.layerName"
        :projection="sat_contourlayer.projection"
        :img_format="sat_contourlayer.img_format"
        :attributions="sat_contourlayer.attribution"
        :time="sat_contourlayer.time"
        :extParams="sat_contourlayer.extParams"
      ></vl-source-wms>
    </vl-layer-tile>
  </div>
</template>
<script>
import Vue from "vue";
import TileLayer from "vuelayers/lib/tile-layer";
import WmsSource from "vuelayers/lib/wms-source";

Vue.use(TileLayer);
Vue.use(WmsSource);

import { mapGetters, mapMutations } from "vuex";
import { NCWMSHelper, FetchHelper, SLDHelpers } from "../mixins/";
export default {
  name: "NCWMSLayer",
  mixins: [NCWMSHelper, FetchHelper, SLDHelpers],
  props: {
    ncwms_layer: {
      type: Object,
      required: true
    },
    index: {
      type: Number,
      default: 0
    }
  },
  computed: {
    ...mapGetters(["getRasterLayer", "getFromTSCache", "getFromMinMaxCache"]),
    satlayer: {
      get() {
        //console.log("raster_layer_type:" + this.layer_type);
        return this.getRasterLayer(this.layer_type);
      }
    },
    sat_contourlayer: {
      get() {
        let cont_layer_type = this.ncwms_layer.layer_type.replace(
          "raster",
          "contours"
        );
        let layer = this.getRasterLayer(cont_layer_type);
        //console.log("GHANSHAM contour_layer_type:" + this.contour_layer_type);
        //let layer = this.getRasterLayer(this.contour_layer_type);
        /* if (layer !== undefined) {
          console.log("contlayer extParams:" + layer.extParams);
        } */
        return layer;
      }
    }
  },
  data() {
    return {
      layer_type: ""
      //contour_layer_type: ""
      /*       minResolution: 0.04,
      maxResolution: 1, */
    };
  },
  methods: {
    ...mapMutations([
      "addRasterLayer",
      "addToMetadataCache",
      "addToTSCache",
      "addToMinMaxCache",
      "addToSLDCache"
    ]),

    async fetchTimeList(url_prefix, layer_name, mydate) {
      let dt_tm_list = [];

      if (typeof layer_name === "string") {
        dt_tm_list = await this.getDateTimeListSingleLayer(
          url_prefix,
          layer_name,
          mydate
        );
      } else {
        let rgb_layers = layer_name;
        let unique_ds_map = new Map();
        for (let indx = 0; indx < rgb_layers.length; indx++) {
          let ds_lname = rgb_layers[indx].split("/");
          unique_ds_map.set(ds_lname[0], ds_lname[1]);
        }
        let my_lnames = [];
        for (let [ds, lname] of unique_ds_map) {
          my_lnames.push(ds + "/" + lname);
        }
        let layers_times = await Promise.all(
          my_lnames.map(lname =>
            this.getDateTimeListSingleLayer(url_prefix, lname, mydate)
          )
        );
        dt_tm_list = layers_times[0];
        for (let indx = 1; indx < layers_times.length; indx++) {
          dt_tm_list = dt_tm_list.filter(
            item =>
              layers_times[indx].findIndex(
                dt => dt.getTime() === item.getTime()
              ) >= 0
          );
        }
      }
      return dt_tm_list;
    },

    async getDateTimeListSingleLayer(url, single_layer, mydate) {
      let date_arr = Array.isArray(mydate) ? mydate : [mydate];
      //console.log("mydate:" + mydate);
      let timesteps_urls = this.createTimeStepsUrls(
        url,
        single_layer,
        date_arr
      );

      //console.log("In getDateTimeListSingleLayer ts_url:" + timesteps_urls[0]);
      let me = this;
      let dt_tm_list = timesteps_urls.map(url => me.getFromTSCache(url));
      for (let indx = 0; indx < dt_tm_list.length; indx++) {
        if (dt_tm_list[indx] === undefined) {
          let fetched_ts_data = await this.fetchUrl(timesteps_urls);
          //let ts_data = fetched_ts_data[0].timesteps;
          let ts_data = fetched_ts_data.map(tsd => tsd.timesteps);
          dt_tm_list[indx] = this.getLayerTimes(date_arr, ts_data);
          for (let indx = 0; indx < timesteps_urls.length; indx++) {
            this.addToTSCache({
              url: timesteps_urls[indx],
              val: dt_tm_list[indx]
            });
          }
          //this.addToTSCache({ url: timesteps_urls[0], val: dt_tm_list });
        } else {
          console.log("Fetched from cache");
        }
      }

      let dt_tm_list_1d = [];
      for (let indx = 0; indx < dt_tm_list.length; indx++) {
        for (let indx2 = 0; indx2 < dt_tm_list[indx].length; indx2++) {
          dt_tm_list_1d.push(dt_tm_list[indx][indx2]);
        }
      }

      //dt_tm_list = dt_tm_list.join().split(",");
      //console.log("dt_tm_list:" + dt_tm_list);
      //let dt_tm_list = this.getFromTSCache(timesteps_urls);

      /* if (dt_tm_list === undefined) {
        let fetched_ts_data = await this.fetchUrl(timesteps_urls);
        //let ts_data = fetched_ts_data[0].timesteps;
        let ts_data = fetched_ts_data.map(tsd => tsd.timesteps);
        dt_tm_list = this.getLayerTimes(date_arr, ts_data);
        for (let indx = 0; indx < timesteps_urls.length; indx++) {
          this.addToTSCache({
            url: timesteps_urls[indx],
            val: dt_tm_list[indx]
          });
        }
        //this.addToTSCache({ url: timesteps_urls[0], val: dt_tm_list });
      } else {
        console.log("Fetched from cache");
      } */
      return dt_tm_list_1d;
    },

    async createLayer(layer_info) {
      let metadata_url_arr = this.createLayerDetailsUrl(
        layer_info.url_prefix,
        layer_info.layer_name
      );

      let metadata_arr = await this.fetchUrl(metadata_url_arr);
      this.addToMetadataCache({ url: metadata_url_arr, val: metadata_arr });

      let date_arr = this.getDateArray(metadata_arr[0].datesWithData);

      let dt_tm_list = undefined;
      if (this.layer_type.startsWith("model")) {
        dt_tm_list = await this.fetchTimeList(
          layer_info.url_prefix,
          layer_info.layer_name,
          date_arr
        );
        dt_tm_list = dt_tm_list.sort((t1, t2) => t1.getTime() - t2.getTime());
      } else {
        dt_tm_list = await this.fetchTimeList(
          layer_info.url_prefix,
          layer_info.layer_name,
          date_arr[0]
        );
      }

      let layer_time = dt_tm_list[0];

      let my_satlayer;

      //console.log("layer_time:" + layer_time);

      let scaleRange = [];

      let elevation_values = [];
      for (let metadata of metadata_arr) {
        elevation_values.push(
          metadata.zaxis === undefined ? 0 : metadata.zaxis.values[0]
        );
      }
      if (layer_info.range_options !== undefined) {
        let layerRangeUrl_arr = this.createLayerRangeUrl(
          layer_info,
          metadata_arr,
          layer_time,
          elevation_values
        );
        let cnt = 0;
        /* for (let url of layerRangeUrl_arr) {
          console.log("url:" + url);
        } */
        for (let opt of layer_info.range_options) {
          if (typeof opt === "boolean") {
            if (opt) {
              //console.log("opt is true");
              let mm_response_arr = await this.fetchUrl([
                layerRangeUrl_arr[cnt]
              ]);
              this.addToMinMaxCache({
                url: layerRangeUrl_arr[cnt],
                val: mm_response_arr[0]
              });

              scaleRange.push([mm_response_arr[0].min, mm_response_arr[0].max]);
            } else {
              //console.log("opt is false");
              scaleRange.push(metadata_arr[cnt].scaleRange);
            }
          } else if (opt instanceof Array) {
            //console.log("opt is array");
            scaleRange.push(opt);
          }
          cnt++;
        }
      } else if (layer_info.autoscl) {
        let layerRangeUrl_arr = this.createLayerRangeUrl(
          layer_info,
          metadata_arr,
          layer_time,
          elevation_values
        );

        let mm_response_arr = await this.fetchUrl(layerRangeUrl_arr);
        this.addToMinMaxCache({ url: layerRangeUrl_arr, val: mm_response_arr });
        for (let mm_response of mm_response_arr) {
          scaleRange.push([mm_response.min, mm_response.max]);
        }
      } else {
        for (let metadata of metadata_arr) {
          scaleRange.push(metadata.scaleRange);
        }
        //console.log("scaleRange:" + scaleRange);
      }
      let opacity = 1;
      let plt = metadata_arr[0].defaultPalette;
      if (layer_info.sld_template !== undefined) {
        let plt = metadata_arr[0].defaultPalette;
        let sld_body = await this.getSLD(
          layer_info.sld_template,
          undefined,
          layer_info.layer_name,
          scaleRange
        );
        //console.log("sld:" + sld_body);

        this.addToSLDCache({ sld: layer_info.sld_template, val: sld_body });
        //console.log("range_options:" + layer_info.range_options);
        my_satlayer = this.createWmsLayer(
          layer_info,
          layer_time,
          plt,
          elevation_values,
          scaleRange,
          opacity,
          sld_body
        );
      } else {
        my_satlayer = this.createWmsLayer(
          layer_info,
          layer_time,
          plt,
          elevation_values,
          scaleRange,
          opacity
        );
        //this.contour_layer_type = this.layer_type.replace("raster", "contours");
      }
      my_satlayer.layer_type = this.layer_type;
      this.addRasterLayer(my_satlayer);
    }
  },
  created() {
    //console.log("In NCWMSLayer.vue ncwms_layer:" + this.ncwms_layer.clipRange);

    let layer_info = {
      url_prefix: this.ncwms_layer.url_prefix.trim(),
      sat_projection: this.ncwms_layer.projection.trim(),
      wms_version: this.ncwms_layer.wms_version.trim(),
      img_format: this.ncwms_layer.format.trim(),
      style: this.ncwms_layer.style.trim(),
      layer_name: this.ncwms_layer.layer_name,
      visible: this.ncwms_layer.visible,
      sld_template: this.ncwms_layer.sld_template,
      range_options: this.ncwms_layer.range_options,
      autoscl: this.ncwms_layer.autoscl,
      attribution: this.ncwms_layer.attribution,
      minResolution: this.ncwms_layer.minResolution,
      maxResolution: this.ncwms_layer.maxResolution,
      clipRange: this.ncwms_layer.clipRange,
      sld: this.ncwms_layer.sld
    };

    /* if (typeof layer_info.layer_name === "string") {
      this.contour_layer_type = this.ncwms_layer.layer_type.replace(
        "raster",
        "contours"
      );
    } */
    this.layer_type = this.ncwms_layer.layer_type;
    this.createLayer(layer_info);
  }
};
</script>
