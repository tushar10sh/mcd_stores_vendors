<template>
  <vl-layer-image
    v-if="Object.keys(mylayer).length !== 0"
    :key="mylayer.url + '_' + mylayer.layerName + '_animation'"
    :z-index="index"
    :opacity="mylayer.opacity"
    :visible="mylayer.visible"
    :preload="preload"
  >
    <!--<vl-source-wms
      :url="mylayer.url"
      :version="mylayer.version"
      :layers="mylayer.layerName"
      :projection="mylayer.projection"
      :img_format="mylayer.img_format"
      :attributions="mylayer.attribution"
      :time="mylayer.time"
      :extParams="mylayer.extParams"
    ></vl-source-wms>-->
    <vl-source-image-wms
      :url="mylayer.url"
      :version="mylayer.version"
      :layers="mylayer.layerName"
      :projection="mylayer.projection"
      :img_format="mylayer.img_format"
      :attributions="mylayer.attribution"
      :time="mylayer.time"
      :extParams="mylayer.extParams"
      :ratio="ratio"
      @imageloadstart="startLoading($event)"
    >
      <!-- @imageloadend="endLoading($event)" -->
    </vl-source-image-wms>
  </vl-layer-image>
</template>

<script>
import Vue from "vue";
import { NCWMSHelper } from "../mixins/";
import ImageWmsSource from "vuelayers/lib/image-wms-source";
import ImageLayer from "vuelayers/lib/image-layer";
Vue.use(ImageWmsSource);
Vue.use(ImageLayer);
import { mapState, mapMutations } from "vuex";
export default {
  computed: {
    ...mapState(["animationlayer"]),
    mylayer: {
      get() {
        let out = this.animationlayer;
        return out;
      }
    }
  },
  mixins: [NCWMSHelper],
  mounted() {},
  methods: {
    ...mapMutations(["updateMapProps"]),
    startLoading(evt) {
      if (
        !this.compareScalarArrays(this.imageSize, evt.target.imageSize_) ||
        !this.compareScalarArrays(this.imageextent, evt.target.image_.extent)
      ) {
        this.updateMapProps({
          imageSize: [...evt.target.imageSize_],
          extent: [...evt.target.image_.extent]
        });

        this.imageSize = [...evt.target.imageSize_];
        this.imageextent = [...evt.target.image_.extent];
      }
    }
  },
  data() {
    return {
      index: 13,
      ratio: 1,
      imageSize: [],
      imageextent: [],
      preload: 1
    };
  }
};
</script>
