<template>
  <v-tab-item :key="tab_key" class="mx-0 px-0" :value="`tab-${tab_key}`">
    <v-card
      style="overflow-y: auto; overflow-x: hidden"
      width="100%"
      :max-height="getComponentHeight()"
    >
      <v-layout class="mt-2 ml-3" align-content-space-around text-xs-center>
        <v-flex xs1>
          <v-switch
            hide-details
            class="shrink ml-1 mt-0 mb-1"
            v-model="raster_layer_visible"
            label="Enable"
          ></v-switch>
        </v-flex>
      </v-layout>

      <div v-show="raster_layer_visible">
        <RapidToggleList
          class="mt-2"
          :valuelist="satsenlist"
          :def_value="sel_satsen_value"
          mdi_icon_name="mdi-satellite"
          @valueChanged="changeSatSen($event)"
        />
        <div v-if="!is_model_tab">
          <RapidToggleList
            class="mt-2"
            :valuelist="satsen_ptype_map.get(this.sel_satsen_value).ptypes"
            :def_value="sel_prod_type"
            mdi_icon_name="mdi-file"
            @valueChanged="prodTypeChanged($event)"
          />

          <v-layout class="mt-2" align-content-space-around text-xs-center>
            <v-flex xs1>
              <v-icon class="my_icon">mdi-layers</v-icon>
            </v-flex>
            <v-flex xs11>
              <v-slide-group
                v-model="sel_layer_index"
                @change="changeLayer"
                mandatory
                show-arrows
                center-active
              >
                <v-slide-item
                  v-for="(layer, indx) in layerslist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ layer.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>

          <v-layout class="mt-2" align-content-space-around text-xs-center>
            <v-flex xs1>
              <v-icon class="my_icon">mdi-calendar</v-icon>
            </v-flex>
            <v-flex xs11>
              <v-slide-group
                v-model="sel_date_index"
                @change="changeDate"
                mandatory
                center-active
                show-arrows
              >
                <v-slide-item
                  v-for="(date, indx) in datelist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ date.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>
          <v-layout align-content-space-around text-xs-center>
            <v-flex offset-xs1 xs11>
              <v-slide-group
                class="mt-2"
                v-model="sel_time_index"
                @change="changeTime"
                mandatory
                center-active
                show-arrows
              >
                <v-slide-item
                  v-for="(time, indx) in timelist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ time.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>
          <v-layout class="mt-2">
            <v-flex xs1>
              <v-icon class="my_icon">mdi-clock</v-icon>
            </v-flex>
            <v-flex xs1>
              <v-btn small @click="changeTimeZone">
                {{
                sel_timezone.caption
                }}
              </v-btn>
            </v-flex>
          </v-layout>
        </div>
        <div v-else>
          <v-layout class="mt-2" align-content-space-around text-xs-center>
            <v-flex xs1>
              <v-icon class="my_icon">mdi-calendar</v-icon>
            </v-flex>
            <v-flex xs11>
              <v-slide-group
                v-model="sel_date_index"
                @change="changeDate"
                mandatory
                center-active
                show-arrows
              >
                <v-slide-item
                  v-for="(date, indx) in datelist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ date.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>
          <RapidToggleList
            class="mt-2"
            :valuelist="satsen_ptype_map.get(this.sel_satsen_value).ptypes"
            :def_value="sel_prod_type"
            mdi_icon_name="mdi-file"
            @valueChanged="prodTypeChanged($event)"
          />
          <v-layout align-content-space-around text-xs-center>
            <v-flex offset-xs1 xs11>
              <v-slide-group
                class="mt-2"
                v-model="sel_time_index"
                @change="changeTime"
                mandatory
                center-active
                show-arrows
              >
                <v-slide-item
                  v-for="(time, indx) in timelist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ time.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>
          <v-layout class="mt-2" align-content-space-around text-xs-center>
            <v-flex xs1>
              <v-icon class="my_icon">mdi-layers</v-icon>
            </v-flex>
            <v-flex xs11>
              <v-slide-group
                v-model="sel_layer_index"
                @change="changeLayer"
                mandatory
                show-arrows
                center-active
              >
                <v-slide-item
                  v-for="(layer, indx) in layerslist"
                  :key="indx"
                  v-slot:default="{ active, toggle }"
                >
                  <v-btn
                    small
                    :color="active ? 'primary' : 'black'"
                    @click="toggle"
                  >{{ layer.caption }}</v-btn>
                </v-slide-item>
              </v-slide-group>
            </v-flex>
          </v-layout>
        </div>

        <v-layout align-center>
          <v-flex xs1>
            <v-icon class="my_icon">mdi-opacity</v-icon>
          </v-flex>
          <v-flex xs12 sm4>
            <v-slider hide-details class="pl-1" v-model="layer_opacity" min="0" max="10"></v-slider>
          </v-flex>
        </v-layout>

        <RGBScaleUI
          v-if="isRGBLayer"
          :range_options="ml_rangeoptions"
          :layernames_list="ml_layerNameList"
          :layer_type="layer_type"
          :range_list="ml_rangeList"
        />

        <div v-else>
          <div v-if="!is_categorical_data && !has_sld">
            <v-layout>
              <v-flex xs1>
                <v-icon class="my_icon">mdi-arrow-expand-horizontal</v-icon>
              </v-flex>
              <v-flex xs4 sm2 md4 lg3>
                <v-text-field
                  v-model="curr_range_min_str"
                  class="mt-0 pt-0 mr-2"
                  hide-details
                  single-line
                  type="number"
                ></v-text-field>
              </v-flex>
              <v-flex xs4 sm2 md4 lg3>
                <v-text-field
                  v-model="curr_range_max_str"
                  class="mt-0 pt-0 mr-2"
                  hide-details
                  single-line
                  type="number"
                ></v-text-field>
              </v-flex>
              <v-flex xs2 md2 lg1>
                <v-btn small @click="changeRange('apply')">
                  <v-icon small class="my_icon">mdi-check</v-icon>
                </v-btn>
              </v-flex>

              <v-snackbar
                v-if="showRangeError"
                v-model="showRangeError"
                color="error"
                :timeout="error_timeout"
              >{{ range_error_message }}</v-snackbar>
            </v-layout>
            <v-layout>
              <v-flex offset-xs1 xs3 md2 lg2>
                <v-btn
                  class="mt-2 text_transform_none"
                  small
                  @click="changeRange('default')"
                >Default</v-btn>
              </v-flex>
              <v-flex xs2 md2 lg2>
                <v-btn class="mt-2 text_transform_none" small @click="changeRange('actual')">Actual</v-btn>
              </v-flex>
              <v-flex xs2 md2 lg2>
                <v-checkbox
                  hide-details
                  class="shrink mr-2 mt-0 mb-0"
                  dark
                  v-model="cliprange"
                  label="Clip Range"
                ></v-checkbox>
              </v-flex>
            </v-layout>
          </div>
        </div>

        <ZAxisUI class="mt-2" :layer_type="layer_type" @valueChanged="setZIndex($event)" />
        <RapidPalette v-if="!isRGBLayer" class="mt-2" :layer_type="layer_type" />
        <ContourWidget
          class="mt-2"
          v-if="!isRGBLayer && !isGroupLayer && !is_categorical_data"
          :raster_layer_type="layer_type"
        />
      </div>
    </v-card>
  </v-tab-item>
</template>

<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import { NCWMSHelper, FetchHelper, SLDHelpers, Constants } from "../mixins/";
import RapidToggleList from "./RapidToggleList.vue";
import RGBScaleUI from "./RGBScaleUI.vue";
import RapidPalette from "./RapidPalette.vue";
import ZAxisUI from "./ZAxisUI.vue";
import ContourWidget from "./ContourWidget.vue";
import moment from "moment";

export default {
  name: "SatTab",
  props: {
    layer_list: {
      type: Object,
      required: true
    },
    tab_key: {
      type: Number,
      required: true
    },
    tab_layer_type: {
      type: String,
      required: true
    },
    is_model_data: {
      type: Boolean,
      required: false
    }
  },
  components: {
    RapidToggleList,
    RGBScaleUI,
    RapidPalette,
    ZAxisUI,
    ContourWidget
  },

  mixins: [NCWMSHelper, FetchHelper, SLDHelpers, Constants],

  computed: {
    ...mapState(["mobileView", "sel_timezone"]),
    ...mapGetters([
      "getFromMetadataCache",
      "getFromTSCache",
      "getFromMinMaxCache",
      "getRasterLayer",
      "getRasterLayerProperty",
      "getFromSLDCache"
    ]),

    cliprange: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        console.log("belowmincolor:" + raster_layer.extParams.BELOWMINCOLOR);
        return raster_layer.extParams.BELOWMINCOLOR !== "extend";
      },
      set(value) {
        let raster_layer = this.getRasterLayer(this.layer_type);
        let extparams_copy = { ...raster_layer.extParams };
        extparams_copy.BELOWMINCOLOR = value ? "#00000000" : "extend";
        extparams_copy.ABOVEMAXCOLOR = value ? "#00000000" : "extend";
        this.updateRaster({
          layer_type: this.layer_type,
          items: {
            extParams: extparams_copy
          }
        });
      }
    },

    is_model_tab: {
      get() {
        return this.is_model_data === undefined ? false : this.is_model_data;
      }
    },

    is_categorical_data: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);

        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        return metadata_arr[0].categorical;
      }
    },

    has_sld: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        return raster_layer.extParams.sld !== undefined;
      }
    },
    raster_layer_visible: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        //console.log("this.layer_type:"+ this.layer_type + " :" + raster_layer.visible);
        return raster_layer.visible;
      },
      set(value) {
        let raster_layer = this.getRasterLayer(this.layer_type);

        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            visible: value
          }
        });
      }
    },

    contoursVisible: {
      get() {
        return this.contour_visibility !== undefined;
      },
      set(value) {
        this.contour_visibility = value;
      }
    },

    layer_opacity: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        return Math.round(raster_layer.opacity * 10);
      },
      set(value) {
        let raster_layer = this.getRasterLayer(this.layer_type);
        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            opacity: value / 10.0
          }
        });
      }
    },
    curr_range_min_str: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        return parseFloat(
          raster_layer.extParams.COLORSCALERANGE.split(",")[0]
        ).toFixed(2);
      },
      set(value) {
        this.curr_range_min = Number.parseFloat(value);
      }
    },
    curr_range_max_str: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        return parseFloat(
          raster_layer.extParams.COLORSCALERANGE.split(",")[1]
        ).toFixed(2);
      },
      set(value) {
        this.curr_range_max = Number.parseFloat(value);
      }
    },
    ml_layerNameList: {
      get() {
        return this.createArrayFromLayerName(
          this.getRasterLayer(this.layer_type).layerName
        );
        /* let raster_layer = this.getRasterLayer(this.layer_type);
        let ds_layers = raster_layer.layerName.split("/");
        let layers = ds_layers[1].split(",");
        return layers; */
      }
    },
    ml_rangeoptions: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        /* console.log(
          "ml_rangeoptions:" +
            raster_layer.layerName +
            " " +
            raster_layer.range_options
        ); */
        return raster_layer.range_options;
      }
    },
    ml_rangeList: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        let out = this.getRGBRange(raster_layer.extParams.sld_body);
        return out;
      }
    },
    isGroupLayer() {
      let raster_layer = this.getRasterLayer(this.layer_type);
      return raster_layer.layerName.endsWith("-group");
    },
    isRGBLayer: {
      get() {
        let raster_layer = this.getRasterLayer(this.layer_type);
        /* console.log(
          raster_layer.layerName + " type :" + typeof raster_layer.layerName
        ); */
        let stat = raster_layer.layerName.includes(",");
        //console.log("isRGBLayer:" + stat);
        return stat;
      }
    },
    firstRGBLayer: {
      get() {
        return this.createArrayFromLayerName(
          this.getRasterLayer(this.layer_type).layerName
        )[0];
      }
    },

    layerslist: {
      get() {
        let layers_list = [];
        let dsinfo_list = this.satsen_ptype_layer_map.get(
          this.sel_satsen_value + "_" + this.sel_prod_type
        );

        for (let dsinfo of dsinfo_list) {
          for (let layer of dsinfo.layers) {
            let layer_info = {
              sld_template: layer.sld_template,
              caption: layer.caption === undefined ? layer.name : layer.caption,
              range_options: layer.range,
              style: layer.style === undefined ? "default" : layer.style,
              autoscl: layer.autoscl,
              minResolution: layer.minResolution,
              maxResolution: layer.maxResolution,
              sld: layer.sld
            };

            layer_info.name = this.createFormattedLayerName(
              dsinfo.ds,
              layer.name
            );

            /*if (layer.name.includes(",")) {
              let layernames = layer.name.split(",");
              let formatted_layername = "";
              for (let indx = 0; indx < layernames.length; indx++) {
                if (layernames[indx].includes("/")) {
                  formatted_layername += layernames[indx];
                } else {
                  formatted_layername += dsinfo.ds + "/" + layernames[indx];
                }
                if (indx != layernames.length - 1) {
                  formatted_layername += ",";
                }
              }
              layer_info.name = formatted_layername;
            } else {
              layer_info.name = dsinfo.ds + "/" + layer.name;
            }
            console.log("layer_info name:" + layer_info.name);*/
            layers_list.push(layer_info);
          }
        }
        //console.log("layerslist get sel_satsen_value:" + this.sel_satsen_value);
        return layers_list;
      }
    },
    sel_layer_index: {
      get() {
        //console.log("get sel layer name:" + this.sel_layer_name);
        let indx = this.layerslist.findIndex(el => {
          let ds_layer = el.name.split("/");
          if (ds_layer.includes(",")) {
            return el.name === this.sel_layer_name;
          } else {
            return el.name.split("/")[1] === this.sel_layer_name.split("/")[1];
          }
        });
        return indx;
      },
      set(indx) {
        /* console.log("sel_layer_index set:" + indx);
        console.log("In set sel_layerindex:" + this.layerslist[indx].name); */
        this.sel_layer_name = this.layerslist[indx].name;
      }
    }
  },
  created() {
    this.loadTab();
  },
  methods: {
    ...mapMutations([
      "updateTimeZone",
      "addRasterLayer",
      "setRasterLayer",
      "addToMetadataCache",
      "addToTSCache",
      "addToMinMaxCache",
      "addToSLDCache",
      "updateRaster"
    ]),
    //...mapActions(["updateRaster"]),
    getComponentHeight() {
      return this.mobileView ? "30vh" : "100vh";
    },
    loadTab() {
      let sensors = this.layer_list["sensors"];
      let found_def_layer = false;

      for (let sensor of sensors) {
        let ptypes = sensor["ptypes"];
        //console.log("sensor keys:" + Object.keys(sensor) + " :" + sensor.senid);
        let satsen = sensor["senid"];
        this.satsen_ptype_map.set(satsen, {
          ptypes: ptypes.map(pt => pt.type_id)
        });
        for (let ptype of ptypes) {
          let datasets = ptype["datasets"];
          let ds_layer_array = [];
          for (let ds of datasets) {
            let layers = ds["layers"];
            for (let l of layers) {
              if (l.minResolution === undefined) {
                l.minResolution = this.layer_list.DEFAULT_MIN_RESOLUTION;
              }
              if (l.maxResolution === undefined) {
                l.maxResolution = this.layer_list.DEFAULT_MAX_RESOLUTION;
              }
            }
            //console.log("layers:" + layers.length);
            ds_layer_array.push({
              ds: ds["ds_name"],
              layers
            });

            if (!found_def_layer) {
              let def_layer = layers.filter(layer => true == layer["def"]);
              if (def_layer.length > 0) {
                //console.log("this.sel_satsen_value:"+ satsen);
                this.sel_satsen_value = satsen;
                this.sel_prod_type = ptype.type_id;
                //console.log("this.sel_satsen_value:"+ this.sel_satsen_value);

                this.sel_layer_name = this.createFormattedLayerName(
                  ds.ds_name,
                  def_layer[0].name
                );

                //this.sel_layer_name = `${ds.ds_name}/${def_layer[0].name}`;
                //console.log("layername:" + this.sel_layer_name);
                //console.log("sel_layer_name:" + this.sel_layer_name);
                found_def_layer = true;
              }
            }
          }
          this.satsen_ptype_layer_map.set(
            satsen + "_" + ptype.type_id,
            ds_layer_array
          );
        }
      }
      //console.log("this.sel_satsen_value:" + this.sel_satsen_value);
      for (let key of this.satsen_ptype_map.keys()) {
        this.satsenlist.push(key);
      }

      this.sel_date_index = 0;
      this.setDateList();
      this.sel_time_index = 0;
      this.setTimeList();
    },

    initOpacity() {
      //console.log("layer_type:" + this.layer_type);
      this.layer_opacity = this.getRasterLayer(this.layer_type).opacity * 10;
    },

    async changeRange(option) {
      if (option === "apply") {
        //Apply mannual range
        let raster_layer = this.getRasterLayer(this.layer_type);

        if (this.curr_range_min === undefined) {
          this.curr_range_min = Number.parseFloat(this.curr_range_min_str, 10);
        }
        if (this.curr_range_max === undefined) {
          this.curr_range_max = Number.parseFloat(this.curr_range_max_str, 10);
        }
        //console.log("curr_range_min:" + this.curr_range_min);
        //console.log("curr_range_max:" + this.curr_range_max);
        /* let curr_range_min = Number.parseFloat(this.curr_range_min_str, 10);
        let curr_range_max = Number.parseFloat(this.curr_range_max_str, 10); */
        if (this.curr_range_min > this.curr_range_max) {
          this.range_error_message =
            "Minimum value cannot be greater than maximum value";
          this.showRangeError = true;
        } else {
          //let range_clause = `${this.curr_range_min},${this.curr_range_max}`;
          this.showRangeError = false;
          //console.log("rangeClause:" + range_clause);
          this.range_error_message = "";
          let new_extParams = this.getColorRangeExtParams(raster_layer, [
            [this.curr_range_min, this.curr_range_max]
          ]);
          //console.log(new_extParams);
          this.updateRaster({
            layer_type: raster_layer.layer_type,
            items: {
              extParams: new_extParams
            }
          });
        }
      } else {
        let raster_layer = this.getRasterLayer(this.layer_type);

        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);

        let scaleRanges;
        //console.log("here:");
        let layer_info = {
          url_prefix: raster_layer.url,
          sat_projection: raster_layer.projection,
          wms_version: raster_layer.version,
          layer_name: raster_layer.layerName,
          autoscl: option === "actual"
        };

        let elevation_values = [];
        if (raster_layer.extParams.elevation === undefined) {
          elevation_values.push(0);
        } else {
          elevation_values.push(raster_layer.extParams.elevation);
        }

        //console.log("Actual Range apply time:" + raster_layer.time);

        scaleRanges = await this.getScaleRanges(
          layer_info,
          metadata_arr,
          new Date(moment(raster_layer.time + "Z", "YYYY-MM-DDhh:mmZ")),
          elevation_values
        );

        let new_extParams = this.getColorRangeExtParams(
          raster_layer,
          scaleRanges
        );

        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            extParams: new_extParams
          }
        });
        //console.log("scaleRange:" + scaleRanges);
      }
      //this.updateContours();
    },
    changeSatSen(newsatsen) {
      //let old_layerlist_len = this.layerslist.length;
      //let old_layer_indx = this.sel_layer_index;

      let old_layer = this.layerslist[this.sel_layer_index];

      this.sel_satsen_value = newsatsen;
      let sel_prod_types = this.satsen_ptype_map.get(newsatsen);

      if (!sel_prod_types.ptypes.includes(this.sel_prod_type)) {
        console.log("Setting sel prodType in changeSatSen");
        this.sel_prod_type = sel_prod_types.ptypes[0];
      }

      let new_layer = this.layerslist[this.sel_layer_index];

      if (new_layer !== undefined) {
        let old_layer_ds = old_layer.name.split("/")[0];
        let old_layer_name = old_layer.name.split("/")[1];

        let new_layer_ds = new_layer.name.split("/")[0];
        let new_layer_name = new_layer.name.split("/")[1];

        if (old_layer_name === new_layer_name) {
          //Vue wont detect this
          if (old_layer_ds !== new_layer_ds) {
            this.changeLayer(this.sel_layer_index);
          }
        }
      }
    },
    prodTypeChanged(newprodtype) {
      let old_layer = this.layerslist[this.sel_layer_index];
      //console.log("prodtype:" + newprodtype);

      this.sel_prod_type = newprodtype;

      let new_layer = this.layerslist[this.sel_layer_index];

      if (new_layer !== undefined) {
        let old_layer_ds = old_layer.name.split("/")[0];
        let old_layer_name = old_layer.name.split("/")[1];

        let new_layer_ds = new_layer.name.split("/")[0];
        let new_layer_name = new_layer.name.split("/")[1];

        if (old_layer_name === new_layer_name) {
          //Vue wont detect this
          if (old_layer_ds !== new_layer_ds) {
            this.changeLayer(this.sel_layer_index);
          }
        }
      }
    },

    async changeLayerAsync(sel_layer) {
      let raster_layer = this.getRasterLayer(this.layer_type);
      //console.log("In changeLayerAsync:" + sel_layer.name);

      let layer_info = {
        url_prefix: raster_layer.url,
        sat_projection: raster_layer.projection,
        wms_version: raster_layer.version,
        style: sel_layer.style,
        img_format: raster_layer.format,
        layer_name: sel_layer.name.trim(),
        range_options: sel_layer.range_options,
        autoscl: sel_layer.autoscl,
        attribution: sel_layer.name.split("/")[0] + "/" + sel_layer.caption,
        minResolution: sel_layer.minResolution,
        maxResolution: sel_layer.maxResolution,
        visible: this.raster_layer_visible,
        sld: sel_layer.sld
      };
      //console.log("minRes:" + sel_layer.minResolution);
      //console.log("maxRes:" + sel_layer.maxResolution);

      let metadata_urls = this.createLayerDetailsUrl(
        layer_info.url_prefix,
        layer_info.layer_name
      );

      let metadata_arr = this.getFromMetadataCache(metadata_urls);
      let unfetched_metadata_urls = [];
      //console.log("metadata_arr:" + metadata_arr.length);
      for (let indx = 0; indx < metadata_arr.length; indx++) {
        if (metadata_arr[indx] === undefined) {
          unfetched_metadata_urls.push(metadata_urls[indx]);
        }
      }
      //console.log("unfetched_metadata_urls:" + unfetched_metadata_urls.length);
      if (unfetched_metadata_urls.length !== 0) {
        let fetched_metadata_arr = await this.fetchUrl(unfetched_metadata_urls);
        this.addToMetadataCache({
          url: unfetched_metadata_urls,
          val: fetched_metadata_arr
        });

        for (let indx = 0; indx < fetched_metadata_arr.length; indx++) {
          /* let url_indx = metadata_urls.findIndex(
            value => value == unfetched_metadata_urls[indx]
          ); */
          let url_indx = metadata_urls.indexOf(unfetched_metadata_urls[indx]);
          metadata_arr[url_indx] = fetched_metadata_arr[indx];
        }
      } else {
        console.log("fetched metadata from cache");
      }

      //Handle model data

      let date_arr = this.getDateArray(metadata_arr[0].datesWithData);
      let mytime = this.datelist[this.sel_date_index].value.getTime();
      let date_index = date_arr.findIndex(el => el.getTime() === mytime);
      if (date_index < 0) {
        date_index = 0;
      }

      this.sel_date_index = date_index;
      let dt_tm_list = undefined;
      if (this.layer_type.startsWith("model")) {
        dt_tm_list = await this.fetchTimeList(
          layer_info.url_prefix,
          layer_info.layer_name,
          date_arr
        );
        dt_tm_list = dt_tm_list.sort((t1, t2) => t1.getTime() - t2.getTime());
      } else {
        dt_tm_list = await this.fetchTimeList(
          layer_info.url_prefix,
          layer_info.layer_name,
          date_arr[date_index]
        );
      }

      let elevation_values = [];

      for (let metadata of metadata_arr) {
        elevation_values.push(
          metadata.zaxis === undefined
            ? 0
            : metadata.zaxis.values[this.sel_z_index]
        );
      }

      //Logic to go to same time (if avaiable) on layer switch
      let my_frmt_date = this.createFormattedTimeString(
        this.timelist[this.sel_time_index].value,
        this.time_format
      );

      let time_index = dt_tm_list.findIndex(
        el =>
          this.createFormattedTimeString(el, this.time_format) === my_frmt_date
      );
      if (time_index < 0) {
        time_index = 0;
      }

      let layer_time = dt_tm_list[time_index];

      //console.log("sel_time:" + this.timelist[this.sel_time_index].value);
      //console.log("layer_time:" + layer_time);
      let scaleRanges = await this.getScaleRanges(
        layer_info,
        metadata_arr,
        layer_time,
        elevation_values
      );
      let sld_body = undefined;
      if (layer_info.layer_name.includes(",")) {
        //console.log("layer_info:" + layer_info.layer_name);
        let template_sld_body = this.getFromSLDCache(sel_layer.sld_template);
        let found = template_sld_body !== undefined;

        /* let ds_layers = layer_info.layer_name.split("/");
        let ds = ds_layers[0];
        let layers = ds_layers[1].split(",");
        layers = layers.map(layer => ds + "/" + layer); */
        let layers = this.createArrayFromLayerName(layer_info.layer_name);
        //console.log(layers);
        sld_body = await this.getSLD(
          sel_layer.sld_template,
          template_sld_body,
          layers,
          scaleRanges
        );
        if (!found) {
          this.addToSLDCache({
            sld: sel_layer.sld_template,
            val: sld_body
          });
        }
        layer_info.layer_name = layers;
      }
      let plt = metadata_arr[0].defaultPalette;
      let my_satlayer = this.createWmsLayer(
        layer_info,
        layer_time,
        plt,
        elevation_values,
        scaleRanges,
        this.layer_opacity / 10.0,
        sld_body
      );
      my_satlayer.layer_type = this.layer_type;
      this.setRasterLayer(my_satlayer);
      this.sel_date_index = date_index;

      //console.log("layer changed");

      this.setDateList();
      this.setTimeList();
      //this.setRange();
      //this.setPaletteList();
      //this.updateContours();
      //console.log("Coming out of function");
    },

    getFcstRefTime() {
      let raster_layer = this.getRasterLayer(this.layer_type);
      let metadata_url = this.createLayerDetailsUrl(
        raster_layer.url,
        raster_layer.layerName
      );
      let metadata_arr = this.getFromMetadataCache(metadata_url);
      let datesWithData = metadata_arr[0].datesWithData;
      return this.getFcstRefTimeAct(datesWithData, this.sel_prod_type);
    },

    async getScaleRanges(
      layer_info,
      metadata_arr,
      layer_time,
      elevation_values
    ) {
      let scaleRanges = [];
      if (layer_info.range_options !== undefined) {
        let layerRangeUrl_arr = this.createLayerRangeUrl(
          layer_info,
          metadata_arr,
          layer_time,
          elevation_values
        );
        let cnt = 0;
        for (let opt of layer_info.range_options) {
          if (typeof opt === "boolean") {
            if (opt) {
              //console.log("opt is true");
              let mm_response_arr = await this.fetchUrl([
                layerRangeUrl_arr[cnt]
              ]);
              this.addToMinMaxCache({
                url: layerRangeUrl_arr[cnt],
                val: mm_response_arr[0]
              });

              scaleRanges.push([
                mm_response_arr[0].min,
                mm_response_arr[0].max
              ]);
            } else {
              //console.log("opt is false");

              scaleRanges.push(metadata_arr[cnt].scaleRange);
            }
          } else if (opt instanceof Array) {
            //console.log("opt is array");
            scaleRanges.push(opt);
          }
          cnt++;
        }
      } else if (layer_info.autoscl) {
        scaleRanges = await this.getDyanmicScaleRange(
          layer_info,
          metadata_arr,
          layer_time,
          elevation_values
        );
        //console.log("returned scaleRange:" + scaleRanges.length);
      } else {
        for (let metadata of metadata_arr) {
          scaleRanges.push(metadata.scaleRange);
        }
      }
      return scaleRanges;
    },
    async getDyanmicScaleRange(
      layer_info,
      metadata_arr,
      layer_time,
      elevation_values
    ) {
      let layerRangeUrls = this.createLayerRangeUrl(
        layer_info,
        metadata_arr,
        layer_time,
        elevation_values
      );
      //console.log("metadata_arr.length:" + metadata_arr.length);

      let mm_response_arr = this.getFromMinMaxCache(layerRangeUrls);
      if (mm_response_arr.length === 0) {
        mm_response_arr = await this.fetchUrl(layerRangeUrls);
        /* console.log(
          "Add minmax to cache:" +
            mm_response_arr[0].min +
            " " +
            mm_response_arr[0].max
        ); */
        this.addToMinMaxCache({ url: layerRangeUrls, val: mm_response_arr });
      } else {
        console.log("fetched minmax from cache");
      }
      let scaleRanges = [];
      for (let mm_response of mm_response_arr) {
        scaleRanges.push([mm_response.min, mm_response.max]);
      }
      //console.log("scaleRanges:" + scaleRanges.length);

      return scaleRanges;
    },
    setDateList() {
      let raster_layer = this.getRasterLayer(this.layer_type);
      if (raster_layer === undefined) {
        return;
      }
      //console.log("layerName:" + raster_layer.layerName);
      let metadata_urls = this.createLayerDetailsUrl(
        raster_layer.url,
        raster_layer.layerName
      );
      //console.log("metadata_urls:" + metadata_urls[0]);
      let metadata = this.getFromMetadataCache(metadata_urls)[0];

      //console.log("metdata:" + metadata.datesWithData);

      if (this.is_model_tab) {
        let fcst_ref_time = this.getFcstRefTimeAct(
          metadata.datesWithData,
          this.sel_prod_type
        );
        this.datelist = this.createCaptionedDateList(
          [fcst_ref_time],
          this.date_format
        );
      } else {
        let new_datelist = this.getDateArray(metadata.datesWithData);
        if (JSON.stringify(new_datelist) !== JSON.stringify(this.datelist)) {
          this.datelist = this.createCaptionedDateList(
            new_datelist,
            this.date_format
          );
        }
      }
    },

    setTimeList() {
      //console.log("setTimeList");
      let raster_layer = this.getRasterLayer(this.layer_type);
      if (raster_layer === undefined) {
        return;
      }
      let date_time_str = raster_layer.time.split("T");
      //console.log("raster layer time:" + raster_layer.time);
      let date_str = date_time_str[0];
      //console.log("date_time_str:" + date_time_str);
      let new_times = [];
      if (this.isRGBLayer) {
        let rgb_layers = this.createArrayFromLayerName(raster_layer.layerName);

        let unique_ds_map = new Map();
        for (let indx = 0; indx < rgb_layers.length; indx++) {
          let ds_lname = rgb_layers[indx].split("/");
          //console.log("layer:" + rgb_layers[indx]);
          unique_ds_map.set(ds_lname[0], ds_lname[1]);
        }
        let my_lnames = [];
        for (let [ds, lname] of unique_ds_map) {
          //console.log("lname:" + lname);
          my_lnames.push(ds + "/" + lname);
        }

        let layers_times = [];
        for (let lname of my_lnames) {
          let timesteps_url = this.createTimeStepsUrl(
            raster_layer.url,
            lname,
            date_str
          );
          //console.log("ts_url:" + timesteps_url);
          layers_times.push(this.getFromTSCache(timesteps_url));
        }
        //console.log("layers_times:" + layers_times.length);
        new_times = layers_times[0];
        //console.log("new_times:" + new_times);

        for (let indx = 1; indx < layers_times.length; indx++) {
          //console.log("layer_Times:" + layers_times[indx]);
          new_times = new_times.filter(
            item =>
              layers_times[indx].findIndex(
                dt => dt.getTime() === item.getTime()
              ) >= 0
            //layers_times[indx].includes(item)
          );
        }
      } else {
        //if not RGB
        let timesteps_url = this.createTimeStepsUrl(
          raster_layer.url,
          raster_layer.layerName,
          date_str
        );

        new_times = this.getFromTSCache(timesteps_url);
      }

      let fcst_ref_time = undefined;
      if (this.is_model_tab) {
        fcst_ref_time = this.getFcstRefTime();
      }
      if (this.timelist === undefined) {
        this.timelist = this.createCaptionedTimeList(
          new_times,
          this.datelist[this.sel_date_index].value,
          this.layer_type.startsWith("satellite")
            ? this.sat_time_format
            : this.time_format,
          this.sel_timezone.id,
          this.is_model_tab,
          fcst_ref_time
        );
        //this.sel_time_index = 0;
      } else {
        let changed = false;
        if (this.timelist.length == new_times.length) {
          let num_times = this.timelist.length;

          for (let indx = 0; indx < num_times; indx++) {
            if (
              this.timelist[indx].value.getTime() !== new_times[indx].getTime()
            ) {
              changed = true;
              break;
            }
          }
        } else {
          changed = true;
        }
        if (changed) {
          this.timelist = this.createCaptionedTimeList(
            new_times,
            this.datelist[this.sel_date_index].value,
            this.layer_type.startsWith("satellite")
              ? this.sat_time_format
              : this.time_format,
            this.sel_timezone.id,
            this.is_model_tab,
            fcst_ref_time
          );
        }
      }

      //Set selected_time_index
      //console.log("time_str:" + raster_layer.time);
      let ncwms_layer_js_time = this.getTimeFromNcWMSLayerTimeString(
        raster_layer.time
      );
      //console.log("ncwms_layer_js_time:" + ncwms_layer_js_time);
      let time_index = this.timelist.findIndex(
        el => el.value.getTime() === ncwms_layer_js_time.getTime()
      );
      this.sel_time_index = time_index < 0 ? 0 : time_index;
      //console.log("sel_time_index:" + this.sel_time_index);
    },

    changeTimeZone() {
      if (this.sel_timezone === Constants.IST_TZ) {
        this.updateTimeZone(Constants.UTC_TZ);
      } else {
        this.updateTimeZone(Constants.IST_TZ);
      }
      let fcst_ref_time = undefined;
      if (this.is_model_tab) {
        fcst_ref_time = this.getFcstRefTime();
      }
      this.timelist = this.createCaptionedTimeList(
        this.timelist,
        this.datelist[this.sel_date_index].value,
        this.layer_type.startsWith("satellite")
          ? this.sat_time_format
          : this.time_format,
        this.sel_timezone.id,
        this.is_model_tab,
        fcst_ref_time
      );
    },
    changeLayer(indx) {
      //console.log("In changeLayer index:" + indx);
      let sel_layer = this.layerslist[indx];
      this.sel_layer_index = indx;
      this.changeLayerAsync(sel_layer);
    },

    async fetchTimeList(url_prefix, layer_name, mydate) {
      let dt_tm_list = [];
      if (layer_name.includes(",")) {
        let rgb_layers = this.createArrayFromLayerName(layer_name);
        let unique_ds_map = new Map();
        for (let indx = 0; indx < rgb_layers.length; indx++) {
          let ds_lname = rgb_layers[indx].split("/");
          unique_ds_map.set(ds_lname[0], ds_lname[1]);
        }
        let my_lnames = [];
        for (let [ds, lname] of unique_ds_map) {
          my_lnames.push(ds + "/" + lname);
        }
        let layers_times = await Promise.all(
          my_lnames.map(lname =>
            this.getDateTimeListSingleLayer(url_prefix, lname, mydate)
          )
        );
        dt_tm_list = layers_times[0];
        for (let indx = 1; indx < layers_times.length; indx++) {
          dt_tm_list = dt_tm_list.filter(
            item =>
              layers_times[indx].findIndex(
                dt => dt.getTime() === item.getTime()
              ) >= 0
          );
        }
      } else {
        dt_tm_list = await this.getDateTimeListSingleLayer(
          url_prefix,
          layer_name,
          mydate
        );
      }
      return dt_tm_list;
    },

    async getDateTimeListSingleLayer(url, single_layer, mydate) {
      let date_arr = Array.isArray(mydate) ? mydate : [mydate];
      let timesteps_urls = this.createTimeStepsUrls(
        url,
        single_layer,
        date_arr
      );

      let me = this;
      let dt_tm_list = timesteps_urls.map(url => me.getFromTSCache(url));

      for (let indx = 0; indx < dt_tm_list.length; indx++) {
        if (dt_tm_list[indx] === undefined) {
          let fetched_ts_data = await this.fetchUrl(timesteps_urls);
          //let ts_data = fetched_ts_data[0].timesteps;
          let ts_data = fetched_ts_data.map(tsd => tsd.timesteps);
          dt_tm_list[indx] = this.getLayerTimes(date_arr, ts_data);
          for (let indx = 0; indx < timesteps_urls.length; indx++) {
            this.addToTSCache({
              url: timesteps_urls[indx],
              val: dt_tm_list[indx]
            });
          }
          //this.addToTSCache({ url: timesteps_urls[0], val: dt_tm_list });
        } else {
          console.log("Fetched from cache");
        }
      }

      let dt_tm_list_1d = [];
      for (let indx = 0; indx < dt_tm_list.length; indx++) {
        for (let indx2 = 0; indx2 < dt_tm_list[indx].length; indx2++) {
          dt_tm_list_1d.push(dt_tm_list[indx][indx2]);
        }
      }

      //console.log("In getDateTimeListSingleLayer ts_url:" + timesteps_urls[0]);
      /* let dt_tm_list = this.getFromTSCache(timesteps_urls[0]);

      if (dt_tm_list === undefined) {
        let fetched_ts_data = await this.fetchUrl(timesteps_urls);
        let ts_data = fetched_ts_data[0].timesteps;
        dt_tm_list = this.getLayerTimes([mydate], [ts_data]);

        this.addToTSCache({ url: timesteps_urls[0], val: dt_tm_list });
      } else {
        console.log("Fetched from cache");
      }
      return dt_tm_list; */
      return dt_tm_list_1d;
    },

    async changeDateAsync(indx) {
      //console.log("indx:" + indx);
      //console.log("changeDate:" + this.datelist[indx].value);

      let raster_layer = this.getRasterLayer(this.layer_type);

      /* let single_layer = this.isRGBLayer
        ? this.firstRGBLayer
        : raster_layer.layerName; */

      let my_frmt_date = this.createFormattedTimeString(
        this.timelist[this.sel_time_index].value,
        this.time_format
      );

      let dt_tm_list = await this.fetchTimeList(
        raster_layer.url,
        raster_layer.layerName,
        this.datelist[indx].value
      );
      //console.log("dt_tm_list:" + dt_tm_list);

      let time_index = dt_tm_list.findIndex(
        el =>
          this.createFormattedTimeString(el, this.time_format) === my_frmt_date
      );
      if (time_index < 0) {
        time_index = 0;
      }

      let frmt_dt_time = this.createFormattedDateTimeString(
        dt_tm_list[time_index]
      );
      console.log("last date time:" + this.timelist[this.sel_time_index].value);
      console.log("frmt_dt_time:" + dt_tm_list[time_index]);

      //let local_sel_layer = this.layerslist[this.sel_layer_index];
      let should_updateRangeOptions =
        raster_layer.range_options === undefined
          ? false
          : raster_layer.range_options.findIndex(el => el == true) > -1;
      let should_updateRange =
        raster_layer.autoscl || should_updateRangeOptions;
      if (should_updateRange) {
        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        let layer_info = {
          url_prefix: raster_layer.url,
          sat_projection: raster_layer.projection,
          wms_version: raster_layer.version,
          layer_name: raster_layer.layerName,
          autoscl: raster_layer.autoscl,
          range_options: raster_layer.range_options
        };
        let elevation_values = [];
        for (let metadata of metadata_arr) {
          elevation_values.push(
            metadata.zaxis === undefined
              ? 0
              : metadata.zaxis.values[this.sel_z_index]
          );
        }
        let scaleRanges = await this.getScaleRanges(
          layer_info,
          metadata_arr,
          dt_tm_list[time_index],
          elevation_values
        );

        let new_extParams = this.getColorRangeExtParams(
          raster_layer,
          scaleRanges
        );
        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            time: frmt_dt_time,
            extParams: new_extParams
          }
        });
      } else {
        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            time: frmt_dt_time
          }
        });
      }

      this.sel_time_index = time_index;
      this.setTimeList();

      //this.updateContours();
    },
    changeDate(indx) {
      this.sel_date_index = indx;
      this.changeDateAsync(indx);
    },

    async changeTime(indx) {
      //console.log("changeTime:" + indx);
      let raster_layer = this.getRasterLayer(this.layer_type);

      let frmt_dt_time = this.createFormattedDateTimeString(
        this.timelist[indx].value
      );
      //console.log("frmt_dt_time:" + frmt_dt_time);
      ///let local_sel_layer = this.layerslist[this.sel_layer_index];

      //  console.log("range_options:" + local_sel_layer.range_options);
      let should_updateRangeOptions =
        raster_layer.range_options === undefined
          ? false
          : raster_layer.range_options.findIndex(el => el == true) > -1;
      let should_updateRange =
        raster_layer.autoscl || should_updateRangeOptions;
      //console.log("should_updateRange:" + should_updateRange);
      if (should_updateRange) {
        let metadata_url = this.createLayerDetailsUrl(
          raster_layer.url,
          raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        let layer_info = {
          url_prefix: raster_layer.url,
          sat_projection: raster_layer.projection,
          wms_version: raster_layer.version,
          layer_name: raster_layer.layerName,
          autoscl: raster_layer.autoscl,
          range_options: raster_layer.range_options
        };
        let elevation_values = [];
        for (let metadata of metadata_arr) {
          elevation_values.push(
            metadata.zaxis === undefined
              ? 0
              : metadata.zaxis.values[this.sel_z_index]
          );
        }
        let scaleRanges = await this.getScaleRanges(
          layer_info,
          metadata_arr,
          this.timelist[indx].value,
          elevation_values
        );
        //console.log("scaleRanges:" + scaleRanges);

        let new_extParams = this.getColorRangeExtParams(
          raster_layer,
          scaleRanges
        );
        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            time: frmt_dt_time,
            extParams: new_extParams
          }
        });
      } else {
        this.updateRaster({
          layer_type: raster_layer.layer_type,
          items: {
            time: frmt_dt_time
          }
        });
      }
    },
    setZIndex(indx) {
      this.sel_z_index = indx;
    }
  },

  data() {
    return {
      loaded: false,
      satsen_ptype_map: new Map(),
      satsen_ptype_layer_map: new Map(),
      sel_satsen_value: "",
      sel_prod_type: "",
      sel_layer_name: "",

      layer_type: this.tab_layer_type,
      cont_layer_type: this.tab_layer_type + "_contours",

      date_format: "DD-MMM-YY",
      time_format: "HH:mm:ss",
      sat_time_format: "HH:mm",
      date_list: [],
      sel_date_index: 0,
      timelist: [],
      sel_time_index: 0,
      /* IST_TZ: { id: "Asia/Calcutta", caption: "IST" },
      UTC_TZ: { id: "UTC", caption: "UTC" }, */
      //sel_timezone: {},
      error_timeout: 2000,
      showRangeError: false,
      range_error_message: "",
      //sel_palette_index: 0,
      //palette_list: [],
      datelist: [],
      satsenlist: [],
      sel_z_index: 0
      //layer_opacity: 10,
      /* cont_info: { cnt_min: 0, cnt_max: 0, cnt_int: 0 },
      contour_visibility: undefined,
      contour_color: "#EBFF00",
      contour_styles: [
        {
          id: "SOLID",
          caption: "___"
        },
        { id: "DASHED", caption: "_ _ _" }
      ],
      sel_contstyle_indx: 0 */
    };
  }
};
</script>
<style scoped>
.text_transform_none {
  text-transform: none;
}
.my_icon {
  display: grid;
}
</style>
