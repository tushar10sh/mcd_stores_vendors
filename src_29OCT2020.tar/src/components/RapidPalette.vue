
<template>
  <!-- <div style="overflow:hidden; min-height:150px"> -->
  <div>
    <v-layout class="mt-2" v-show="!metadata.categorical">
      <v-flex xs1>
        <v-icon style="display: grid">mdi-palette</v-icon>
      </v-flex>
      <!-- <v-flex xs8>
        <v-slide-group v-model="sel_palette_index" mandatory center-active show-arrows>
          <v-slide-item
            v-for="(pal, indx) in metadata.palettes"
            :key="indx"
            v-slot:default="{ active, toggle }"
          >
            <v-btn small :color="active ? 'primary' : 'black'" @click="toggle">{{ pal }}</v-btn>
          </v-slide-item>
        </v-slide-group>
      </v-flex>-->

      <v-flex xs8 v-if="palette_options.length>1">
        <v-slide-group v-model="palette_opt_index" mandatory center-active show-arrows>
          <v-slide-item
            v-for="(pal, indx) in palette_options"
            :key="indx"
            v-slot:default="{ active, toggle }"
          >
            <v-btn small :color="active ? 'primary' : 'black'" @click="toggle">{{ pal }}</v-btn>
          </v-slide-item>
        </v-slide-group>
      </v-flex>

      <!--<v-flex xs1>
        <v-btn x-small @click="changePalette('default')">
          <v-icon small>mdi-undo</v-icon>
        </v-btn>
      </v-flex>-->
      <!--  </v-layout> -->

      <!--     <v-layout class="mt-2" v-show="!is_categorical_data"> -->
      <v-btn v-if="!has_sld" small class="mr-2" @click="myshow = true">
        <v-icon>mdi-pencil</v-icon>
      </v-btn>
    </v-layout>
    <v-layout class="mt-2">
      <v-flex offset-xs1>
        <img :src="layer_palette_url" />
      </v-flex>
    </v-layout>
    <div v-if="!has_sld">
      <EditPalette
        v-show="myshow"
        :layer_type="layer_type"
        :show="myshow"
        @editPaletteVisibilityChanged="myshow = false"
      />
    </div>

    <!--     <div class="imagediv">
      <img :src="layer_palette_url" />
    </div>-->
    <!-- </v-row>
    </v-container>-->
  </div>
</template>
<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import { NCWMSHelper } from "../mixins/";
//import EditPalette from "./EditPalette";
export default {
  props: {
    layer_type: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      legend_height: 300,
      legend_width: 20,
      justify: "right",
      myshow: false
    };
  },
  components: {
    EditPalette: () =>
      import(/*webpackChunkName: "EditPalette"*/ "./EditPalette")
  },
  mixins: [NCWMSHelper],
  computed: {
    palette_options: {
      get() {
        console.log("raster_layer sld:" + this.raster_layer.sld_name);
        return this.raster_layer.sld_name !== undefined
          ? ["discrete", "continuous"]
          : ["continuous"];
      }
    },
    palette_opt_index: {
      get() {
        return this.raster_layer.extParams.sld !== undefined ? 0 : 1;
      },
      set(new_indx) {
        let new_extParams = { ...this.raster_layer.extParams };

        new_extParams["sld"] =
          new_indx == 0 ? this.raster_layer.sld_name : undefined;
        this.updateRaster({
          layer_type: this.raster_layer.layer_type,
          items: {
            extParams: new_extParams
          }
        });
      }
    },
    ...mapState(["mobileView"]),
    ...mapGetters(["getFromMetadataCache", "getRasterLayer"]),
    /* palette_list: {
      get() {
        //let raster_layer = this.getRasterLayer(this.layer_type);
        //Only for Single Layer List

        //let loc_palette_list = [];
         for (let pal of this.metadata.palettes) {
          let pal_url = `${raster_layer.url}&request=GetLegendGraphic&COLORBARONLY=true&palette=${pal}&WIDTH=40&HEIGHT=5&vertical=false`;
          loc_palette_list.push({ name: pal, src: pal_url });
        } 
        return this.metadata.palettes;
      }
    }, */
    has_sld() {
      return this.raster_layer.extParams.sld !== undefined;
    },
    /* is_categorical_data: {
      get() {
        

        let metadata_url = this.createLayerDetailsUrl(
          this.raster_layer.url,
          this.raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        return metadata_arr[0].categorical;
      }
    }, */

    /* palette_url: {
      get() {
        let pal = this.metadata.palettes[this.sel_palette_index];
        //console.log("indx:" + indx);
        //console.log("pal:" + pal);
        return `${this.raster_layer.url}&request=GetLegendGraphic&COLORBARONLY=true&palette=${pal}&WIDTH=40&HEIGHT=5&vertical=false`;
      }
    }, */

    layer_palette_url: {
      get() {
        let style_clause = "";
        if (this.raster_layer.extParams.sld !== undefined) {
          style_clause = `&SLD=${this.raster_layer.extParams.sld}`;
        } else if (this.raster_layer.extParams.style !== undefined) {
          style_clause =
            `&style=${this.raster_layer.extParams.style}` +
            `&COLORSCALERANGE=${this.raster_layer.extParams.COLORSCALERANGE}`;
        }
        let url =
          `${this.raster_layer.url}` +
          "&request=GetLegendGraphic" +
          `${style_clause}` +
          `&WIDTH=${this.legend_width}&HEIGHT=${this.legend_height}` +
          `&LAYERS=${this.raster_layer.layerName}` +
          "&BELOWMINCOLOR=extend&ABOVEMAXCOLOR=extend&vertical=" +
          (this.metadata.categorical
            ? "true"
            : this.mobileView
            ? "false"
            : true);
        console.log("url:" + url);
        return url;
      }
    },
    metadata: {
      get() {
        let metadata_url = this.createLayerDetailsUrl(
          this.raster_layer.url,
          this.raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        return metadata_arr[0];
      }
    },
    raster_layer: {
      get() {
        return this.getRasterLayer(this.layer_type);
      }
    },
    sel_palette_index: {
      get() {
        //console.log("In sel_palette_index");
        let sel_pal_name = this.raster_layer.extParams.style.split("/")[1];
        let my_indx = -1;
        for (let indx = 0; indx < this.metadata.palettes.length; indx++) {
          if (this.metadata.palettes[indx] === sel_pal_name) {
            my_indx = indx;
            break;
          }
        }
        //let indx = this.metadata.palettes.findIndex(el => el == sel_pal_name);
        //console.log("Out sel_palette_index");
        return my_indx;
      },
      set(new_indx) {
        let plt_name = this.metadata.palettes[new_indx];
        //console.log("setting plt_name:" + plt_name);
        //let new_extParams = this.deepCopy(this.raster_layer.extParams);
        let new_extParams = { ...this.raster_layer.extParams };

        new_extParams["style"] = "default/" + plt_name;
        this.updateRaster({
          layer_type: this.raster_layer.layer_type,
          items: {
            extParams: new_extParams
          }
        });
        //console.log(" value setted");
      }
    }
  },

  methods: {
    ...mapMutations(["updateRaster"])
    /* async changePalette() {
      let new_extParams = this.deepCopy(this.raster_layer.extParams);
      let plt_name = this.metadata.defaultPalette;
      // console.log("plt_name:" + plt_name);
      new_extParams["style"] = "default/" + plt_name;
      this.updateRaster({
        layer_type: this.raster_layer.layer_type,
        items: {
          extParams: new_extParams,
        },
      });
    }, */
  }
};
</script>
<style>
/*.rotateimage {
  transform-origin: right bottom 0px;
   -webkit-transform: rotate(90deg) translate(-200%);
  -moz-transform: rotate(90deg) translate(-200%);
  -ms-transform: rotate(90deg) translate(-200%);
  -o-transform: rotate(90deg) translate(-200%);
  transform: rotate(90deg) translate(-200%); 
}*/
.imagediv {
  height: auto;
  width: 100%;
  padding: 2rem;
  margin: 0.25rem;
}

/* .x-row {
  height: 100%;
} */
</style>
