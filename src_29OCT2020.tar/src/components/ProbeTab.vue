<template>
  <v-tab-item :key="tab_key" :value="`tab-${tab_key}`">
    <v-layout class="mt-1">
      <v-flex xs1>
        <v-icon style="display: grid">mdi-layers</v-icon>
      </v-flex>

      <v-flex xs11>
        <v-slide-group
          v-model="sel_layer_index"
          @change="changeLayer"
          mandatory
          center-active
          show-arrows
        >
          <v-slide-item
            v-for="(layer, indx) in probe_layer_list"
            :key="indx"
            v-slot:default="{ active, toggle }"
          >
            <v-btn
              small
              :color="active ? 'primary' : 'black'"
              @click="toggle"
              >{{
                layer.layer_type.split("_")[0] +
                "/" +
                layer.attribution.split("/")[1]
              }}</v-btn
            >
          </v-slide-item>
        </v-slide-group>
      </v-flex>
    </v-layout>

    <v-layout class="mt-1">
      <v-flex xs1>
        <v-icon style="display: grid">mdi-cursor-pointer</v-icon>
      </v-flex>
      <v-flex xs11>
        <v-slide-group
          v-model="sel_probe_index"
          @change="changeProbe"
          mandatory
          center-active
          show-arrows
        >
          <v-slide-item
            v-for="(pi, indx) in available_probe_infos"
            :key="indx"
            v-slot:default="{ active, toggle }"
          >
            <v-btn
              small
              :color="active ? 'primary' : 'black'"
              @click="toggle"
              >{{ pi.caption }}</v-btn
            >
          </v-slide-item>
        </v-slide-group>
      </v-flex>
    </v-layout>

    <v-layout>
      <v-flex
        xs12
        v-if="
          probe_info.location.length > 0 &&
          (probe_info.caption === 'timeseries' ||
            probe_info.caption === 'verticalprofile' ||
            probe_info.caption === 'skewt')
        "
      >
        Location(Lat/Lon): {{ probe_info.location[1].toFixed(2) }}°,
        {{ probe_info.location[0].toFixed(0) }}°
      </v-flex>
      <v-flex xs12 v-if="probe_info.caption === 'distance'"
        >Distance:{{ distance_probe }}</v-flex
      >
      <v-flex xs12 v-if="probe_info.caption === 'area'"
        >Area:{{ area_probe }}</v-flex
      >
    </v-layout>
    <v-layout>
      <v-flex xs12>
        <TimeSeriesPlot
          v-show="ts_probe_info !== undefined"
          :ts_probe_info="ts_probe_info"
        />
        <VerticalProfile
          v-show="vp_probe_info !== undefined"
          :vp_probe_info="vp_probe_info"
        />
        <SkewT
          v-show="skt_probe_info !== undefined"
          :skt_probe_info="skt_probe_info"
          :skt_anc_layers="skt_anc_variables"
        />
        <!-- :wv_layerName="getSkewTLayerName('wv_var')"
        :height_layerName="getSkewTLayerName('height_var')"-->
      </v-flex>
    </v-layout>
  </v-tab-item>
</template>
<script>
import { mapGetters, mapMutations, mapState } from "vuex";
import { NCWMSHelper, FetchHelper } from "../mixins";
//import skewTVariables from "../assets/skewTVariables.json";
//import D3Chart from "./D3Chart.vue";

export default {
  name: "ProbeTab",
  mixins: [NCWMSHelper, FetchHelper],

  mounted() {
    this.loadProbeList();
  },

  computed: {
    ...mapGetters(["getFromMetadataCache", "getFromTSCache"]),
    ...mapState([
      "probe_info",
      "raster_layer_list",
      "distance_probe",
      "area_probe",
    ]),

    skt_anc_variables() {
      let sel_layer = this.probe_layer_list[this.sel_layer_index];
      if (sel_layer !== undefined) {
        if (this.skewTVariables !== undefined) {
          let skewt_conf = this.skewTVariables[sel_layer.layerName];
          if (skewt_conf === undefined) {
            return {};
          } else {
            return skewt_conf;
          }
        } else {
          return {};
        }
      } else {
        return {};
      }
    },

    probe_layer_list: {
      get() {
        return this.raster_layer_list.filter((layer) => {
          return layer.layer_type.endsWith("raster");
        });
      },
    },
  },
  components: {
    TimeSeriesPlot: () => import("./TimeSeriesPlot"),
    VerticalProfile: () => import("./VerticalProfile"),
    SkewT: () => import("./SkewT"),
  },

  watch: {
    probe_layer_list: {
      deep: true,
      handler(new_layer_list) {
        if (this.sel_layer_index > new_layer_list.length - 1) {
          this.sel_layer_index = new_layer_list.length - 1;
        }
        /* console.log(
          "Before avail probe infos length:" + this.available_probe_infos.length
        ); */
        this.available_probe_infos = this.getAvailableProbeInfos();
        /* console.log(
          "avail probe infos length:" + this.available_probe_infos.length
        ); */
        if (this.sel_probe_index > this.available_probe_infos.length - 1) {
          this.sel_probe_index = 0;
          this.available_probe_infos[this.sel_probe_index].map_bbox = undefined;
          this.available_probe_infos[this.sel_probe_index].scan_pix = undefined;
          this.available_probe_infos[this.sel_probe_index].map_size = undefined;
          this.available_probe_infos[this.sel_probe_index].location = [];
        } else {
          this.available_probe_infos[this.sel_probe_index].layer =
            new_layer_list[this.sel_layer_index];

          this.available_probe_infos[
            this.sel_probe_index
          ].map_bbox = this.deepCopy(this.probe_info.map_bbox);
          this.available_probe_infos[
            this.sel_probe_index
          ].map_size = this.deepCopy(this.probe_info.map_size);
          this.available_probe_infos[
            this.sel_probe_index
          ].scan_pix = this.deepCopy(this.probe_info.scan_pix);
          this.available_probe_infos[
            this.sel_probe_index
          ].location = this.deepCopy(this.probe_info.location);
        }
        console.log("In watch probe_layer_list");
        this.updateProbeInfo(this.available_probe_infos[this.sel_probe_index]);
      },
    },
    probe_info: {
      handler(my_probe_info) {
        let map_bbox = my_probe_info.map_bbox;
        let scan_pix = my_probe_info.scan_pix;
        let map_size = my_probe_info.map_size;
        if (
          map_bbox !== undefined &&
          scan_pix !== undefined &&
          map_size !== undefined
        ) {
          this.ts_probe_info =
            my_probe_info.caption === "timeseries" ? my_probe_info : undefined;
          this.vp_probe_info =
            my_probe_info.caption === "verticalprofile"
              ? my_probe_info
              : undefined;

          this.skt_probe_info =
            my_probe_info.caption === "skewt" ? my_probe_info : undefined;
        } else {
          this.ts_probe_info = undefined;
          this.vp_probe_info = undefined;
          this.skt_probe_info = undefined;
        }
      },
      deep: true,
    },
  },

  data() {
    return {
      sel_layer_index: 0,
      sel_probe_index: 0,
      ts_probe_info: undefined,
      vp_probe_info: undefined,
      skt_probe_info: undefined,
      available_probe_infos: [],
      skewTVariables: undefined,

      probe_infos: [
        {
          caption: "none",
          id: "none",
          location: [],
          layer: {},
        },
        {
          caption: "point",
          id: "point",
          location: [],
          layer: {},
        },
        {
          caption: "timeseries",
          id: "point",
          location: [],
          layer: {},
        },
        {
          caption: "verticalprofile",
          id: "point",
          location: [],
          layer: {},
        },
        {
          caption: "skewt",
          id: "point",
          location: [],
          layer: {},
        },
        {
          caption: "distance",
          id: "line-string",
          location: [],
          layer: {},
        },
        {
          caption: "area",
          id: "polygon",
          location: [],
          layer: {},
        },
      ],
    };
  },

  methods: {
    ...mapMutations([
      "updateProbeInfo",
      "updateDistanceProbe",
      "updateAreaProbe",
    ]),
    async loadProbeList() {
      let skewt_fetched_resp = await this.fetchUrl([
        "jsons/skewTVariables.json",
      ]);
      //console.log("skewtvar:" + skewt_fetched_resp[0]);
      this.skewTVariables = skewt_fetched_resp[0];
      this.available_probe_infos = this.getAvailableProbeInfos();
    },
    isSameDatasource(layerName) {
      let layers = layerName.split(",");
      let ds = layers[0].split("/")[0];
      let same = true;
      for (let indx = 1; indx < layers.length; indx++) {
        if (layers[indx].split("/")[0] !== ds) {
          same = false;
          break;
        }
      }
      return same;
    },
    getAvailableProbeInfos() {
      let sel_layer = this.probe_layer_list[this.sel_layer_index];
      let out_probe_infos = [];
      //console.log("sel_layer:" + sel_layer.layerName);
      if (sel_layer !== undefined) {
        let metadata_url = this.createLayerDetailsUrl(
          sel_layer.url,
          sel_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);

        if (metadata_arr[0].zaxis === undefined) {
          out_probe_infos = this.probe_infos.filter(
            (probeinfo) =>
              probeinfo.caption !== "verticalprofile" &&
              probeinfo.caption !== "skewt"
          );
        } else {
          //console.log("skewTVars:" + this.skewTVariables);
          if (this.skewTVariables[sel_layer.layerName] === undefined) {
            out_probe_infos = this.probe_infos.filter(
              (probeinfo) => probeinfo.caption !== "skewt"
            );
          } else {
            out_probe_infos = this.probe_infos;
          }
        }

        if (!this.isSameDatasource(sel_layer.layerName)) {
          out_probe_infos = out_probe_infos.filter(
            (pi) => pi.caption != "timeseries"
          );
        }
      }
      //console.log("out_probe_infos:" + out_probe_infos.length);
      return out_probe_infos;
    },

    changeLayer() {
      this.available_probe_infos = this.getAvailableProbeInfos();
      this.available_probe_infos[
        this.sel_probe_index
      ].layer = this.probe_layer_list[this.sel_layer_index];
      //console.log("In changelayer:" + this.probe_info.location.length + " " + this.available_probe_infos[this.sel_probe_index].location.length);
      
      let my_probe_info = this.available_probe_infos[this.sel_probe_index];
console.log("In changeLayer:" + my_probe_info.layer);
      my_probe_info.location = [...this.probe_info.location];
      this.updateProbeInfo(my_probe_info);
      this.updateDistanceProbe("");
      this.updateAreaProbe("");
    },
    /*  changeLayer(newlayer) {
      console.log("Ghansham new_layer:" + newlayer);
    }, */
    changeProbe(probe_index) {
      if (probe_index !== undefined) {
        this.available_probe_infos[probe_index].layer = this.probe_layer_list[
          this.sel_layer_index
        ];

        if (
          this.available_probe_infos[probe_index].caption === "none" ||
          this.available_probe_infos[probe_index].caption === "distance" ||
          this.available_probe_infos[probe_index].caption === "area"
        ) {
          
          for (let indx = 0; indx < this.probe_infos.length; indx++) {
            this.probe_infos[indx].map_bbox = undefined;
            this.probe_infos[indx].scan_pix = undefined;
            this.probe_infos[indx].map_size = undefined;
            this.probe_infos[indx].location = [];
          }
          this.ts_probe_info = undefined;
          this.vp_probe_info = undefined;
          this.skt_probe_info = undefined;
        } else {
          this.available_probe_infos[probe_index].map_bbox = this.deepCopy(
            this.probe_info.map_bbox
          );
          this.available_probe_infos[probe_index].map_size = this.deepCopy(
            this.probe_info.map_size
          );
          this.available_probe_infos[probe_index].scan_pix = this.deepCopy(
            this.probe_info.scan_pix
          );
          this.available_probe_infos[probe_index].location = this.deepCopy(
            this.probe_info.location
          );
        }
        console.log("In changeProbe");
        this.updateProbeInfo(this.available_probe_infos[probe_index]);
        this.updateDistanceProbe("");
        this.updateAreaProbe("");
      } else {
        this.sel_probe_index = 0;
      }
    },
  },

  props: {
    /* layer_list: {
      type: String,
      required: false,
    }, */
    tab_key: {
      type: Number,
      required: true,
    },
    /* tab_layer_type: {
      type: String,
      required: false,
    }, */
  },
};
</script>
