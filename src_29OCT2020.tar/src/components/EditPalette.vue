<template>
  <v-dialog persistent v-model="myshow" max-width="500">
    <v-card dark>
      <v-card-title>Edit Palette</v-card-title>
      <v-card-text>
        <v-layout>
          <v-flex xs12>
            <v-slide-group v-model="sel_palette_index" mandatory center-active show-arrows>
              <v-slide-item
                v-for="(pal, indx) in metadata.palettes"
                :key="indx"
                v-slot:default="{ active, toggle }"
              >
                <v-btn
                  class="mx-1"
                  small
                  :rounded="tiled"
                  :color="active ? 'primary' : 'black'"
                  @click="toggle"
                >
                  <v-avatar :tile="tiled">
                    <v-img :src="getPalettePreview(indx)" />
                  </v-avatar>
                </v-btn>
              </v-slide-item>
            </v-slide-group>
          </v-flex>
        </v-layout>
        <v-layout class="mt-2">
          <v-flex xs11>
            Selected Palette: {{ metadata.palettes[sel_palette_index] }}
            <!--    <v-img
              :max-width="legend_height"
              :width="legend_height"
              :src="palette_url"
            />-->
          </v-flex>
        </v-layout>
      </v-card-text>
      <v-card-actions>
        <v-btn x-small @click="changePalette">Default</v-btn>
        <v-btn x-small @click="close">Close</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
import { mapGetters, mapMutations } from "vuex";
import { NCWMSHelper } from "../mixins/";
export default {
  mixins: [NCWMSHelper],
  watch: {
    show(new_val) {
      this.myshow = new_val;
    }
  },

  computed: {
    ...mapGetters(["getFromMetadataCache", "getRasterLayer"]),
    sel_palette_index: {
      get() {
        let sel_pal_name = this.raster_layer.extParams.style.split("/")[1];
        let my_indx = -1;
        for (let indx = 0; indx < this.metadata.palettes.length; indx++) {
          if (this.metadata.palettes[indx] === sel_pal_name) {
            my_indx = indx;
            break;
          }
        }
        return my_indx;
      },
      set(new_indx) {
        let plt_name = this.metadata.palettes[new_indx];
        //console.log("setting plt_name:" + plt_name);
        let new_extParams = this.deepCopy(this.raster_layer.extParams);

        new_extParams["style"] = "default/" + plt_name;
        this.updateRaster({
          layer_type: this.raster_layer.layer_type,
          items: {
            extParams: new_extParams
          }
        });
        //console.log(" value setted");
      }
    },
    palette_url: {
      get() {
        let pal = this.metadata.palettes[this.sel_palette_index];
        //console.log("indx:" + indx);
        //console.log("pal:" + pal);
        return `${this.raster_layer.url}&request=GetLegendGraphic&COLORBARONLY=true&palette=${pal}&WIDTH=40&HEIGHT=5&vertical=false`;
      }
    },
    metadata: {
      get() {
        let metadata_url = this.createLayerDetailsUrl(
          this.raster_layer.url,
          this.raster_layer.layerName
        );
        let metadata_arr = this.getFromMetadataCache(metadata_url);
        return metadata_arr[0];
      }
    },
    raster_layer: {
      get() {
        return this.getRasterLayer(this.layer_type);
      }
    }
  },
  props: {
    layer_type: {
      type: String,
      required: true
    },
    show: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      legend_height: 300,
      legend_width: 20,
      tiled: true,
      myshow: true
    };
  },
  created() {
    this.myshow = this.show;
    console.log("In created");
  },
  mounted() {
    console.log("In mounted");
  },
  methods: {
    ...mapMutations(["updateRaster"]),
    getPalettePreview(indx) {
      let pal = this.metadata.palettes[indx];
      //console.log("indx:" + indx);
      //console.log("pal:" + pal);
      return `${this.raster_layer.url}&request=GetLegendGraphic&COLORBARONLY=true&palette=${pal}&vertical=false`;
    },
    close() {
      this.myshow = false;
      this.$emit("editPaletteVisibilityChanged", false);
    },
    async changePalette() {
      let new_extParams = this.deepCopy(this.raster_layer.extParams);
      let plt_name = this.metadata.defaultPalette;
      // console.log("plt_name:" + plt_name);
      new_extParams["style"] = "default/" + plt_name;
      this.updateRaster({
        layer_type: this.raster_layer.layer_type,
        items: {
          extParams: new_extParams
        }
      });
    }
  }
};
</script>