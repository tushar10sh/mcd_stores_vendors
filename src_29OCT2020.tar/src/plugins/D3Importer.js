import { timeParse, utcFormat, timeFormat } from "d3-time-format";
import { format } from "d3-format";
import { csv, json } from "d3-fetch";
import { extent, min, max, bisector, ascending, range } from "d3-array";
import { scaleTime, scaleLinear, scaleSymlog, scaleLog } from "d3-scale";
import { select, mouse, selectAll, touches } from "d3-selection";
import { zoom } from "d3-zoom";
import { axisLeft, axisBottom, axisRight, axisTop } from "d3-axis";
import { line, area } from "d3-shape";
//import { transition } from "d3-transition";

const getEvent = () => require("d3-selection").event;

export default {
  timeParse,
  utcFormat,
  format,
  timeFormat,
  csv,
  json,
  extent,
  min,
  max,
  bisector,
  ascending,
  scaleTime,
  scaleLinear,
  scaleSymlog,
  scaleLog,
  getEvent,
  touches,
  mouse,
  select,
  selectAll,
  zoom,
  axisLeft,
  axisBottom,
  axisRight,
  axisTop,
  line,
  area,
  range,
};
