import { default as FetchHelper } from "./FetchHelper.js";

export default {
  mixins: [FetchHelper],

  methods: {
    async getSLD(sld_url, sld_xml, layer_list, range_list) {
      if (sld_xml === undefined) {
        //console.log("Fetching rgb xml");
        sld_xml = await this.fetchUrlXml(sld_url);
        sld_xml = sld_xml.trim();
      } else {
        sld_xml = sld_xml.trim();
        //console.log("Using already fetched rgb xml");
      }
      // console.log("xml:" + sld_xml);

      return this.updateSLD(sld_xml, layer_list, range_list);

      //return sld_body;
    },
    updateSLD(sld_xml, layer_list, range_list) {
      if (sld_xml.includes("vorticity")) {
        return this.updateVortSLD(sld_xml, layer_list, range_list);
      } else if (sld_xml.includes("RasterRGBSymbolizer")) {
        return this.updateRGBSLD(sld_xml, layer_list, range_list);
      } else if (sld_xml.includes("ColoredSizedArrowSymbolizer")) {
        //Wind Barb
        return this.updateWVSLD(sld_xml, layer_list, range_list);
      } else {
        return this.updateSandwichSLD(sld_xml, layer_list, range_list);
      }
    },

    updateVortSLD(sld_xml, layer_list, range_list) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      let named_layers = xmldoc.getElementsByTagName("NamedLayer");

      let num_layers = layer_list.length;
      let min_node_list = xmldoc.getElementsByTagName("resc:Minimum");
      let max_node_list = xmldoc.getElementsByTagName("resc:Maximum");
      console.log("num_layers:" + num_layers);
      for (let indx = 0; indx < num_layers; indx++) {
        named_layers[indx].children[0].textContent = layer_list[indx];
        min_node_list[indx].textContent = range_list[indx][0];
        max_node_list[indx].textContent = range_list[indx][1];
      }
      let xml_serializer = new XMLSerializer();
      var out_sld = xml_serializer.serializeToString(xmldoc);
      return out_sld;
    },

    updateWVSLD(sld_xml, layer_list, range_list) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      let named_layers = xmldoc.getElementsByTagName("NamedLayer");
      let ArrowSizeField = xmldoc.getElementsByTagName("resc:ArrowSizeField");
      let ArrowColorField = xmldoc.getElementsByTagName(
        "resc:ArrowColourField"
      );

      named_layers[0].children[0].textContent = layer_list[0]; //Changing layerName
      let st_indx = 1;

      if (layer_list[st_indx].endsWith("-group")) {
        named_layers[st_indx].children[0].textContent = layer_list[
          st_indx
        ].replace("-group", "-dir");

        ArrowSizeField[0].textContent = layer_list[st_indx].replace(
          "-group",
          "-mag"
        );
      } else {
        named_layers[st_indx].children[0].textContent = layer_list[st_indx]; //Changing layerName
        ArrowSizeField[0].textContent = layer_list[st_indx];
      }

      ArrowColorField[0].textContent = layer_list[st_indx + 1];
      let min_node_list = xmldoc.getElementsByTagName("resc:Minimum");
      let max_node_list = xmldoc.getElementsByTagName("resc:Maximum");

      for (let i = 0; i < range_list.length; i++) {
        min_node_list[i].textContent = range_list[i][0];
        max_node_list[i].textContent = range_list[i][1];
      }

      let xml_serializer = new XMLSerializer();
      var out_sld = xml_serializer.serializeToString(xmldoc);
      //console.log("out_sld:" + out_sld);
      return out_sld;
    },

    getRGBRange(sld_xml) {
      let dom_parser = new DOMParser();

      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      let min_node_list = xmldoc.getElementsByTagName("resc:Minimum");
      let max_node_list = xmldoc.getElementsByTagName("resc:Maximum");
      // let band_name_nodes = xmldoc.getElementsByTagName("resc:BandName");
      let num_bands = min_node_list.length;
      let ml_rangelist = [];
      //let colors = ["red", "green", "blue"]
      for (let i = 0; i < num_bands; i++) {
        //console.log("min:" + min_node_list[i].textContent);
        //console.log("max:" + max_node_list[i].textContent);
        ml_rangelist.push({
          min: min_node_list[i].textContent,
          max: max_node_list[i].textContent,
        });
      }
      return ml_rangelist;
    },
    updateSandwichSLD(sld_xml, band_list, range_list) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      let named_layers = xmldoc.getElementsByTagName("NamedLayer");
      let minrange_nodes = xmldoc.getElementsByTagName("resc:Minimum");
      let maxrange_nodes = xmldoc.getElementsByTagName("resc:Maximum");
      for (let i = 0; i < band_list.length; i++) {
        named_layers[i].children[0].textContent = band_list[i]; //Changing layerName
        minrange_nodes[i].textContent = range_list[i][0];
        maxrange_nodes[i].textContent = range_list[i][1];
      }
      let xml_serializer = new XMLSerializer();
      var out_sld = xml_serializer.serializeToString(xmldoc);
      return out_sld;
    },
    getPaletteNames(sld_xml) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      let named_layers = xmldoc.getElementsByTagName("NamedLayer");
      let layer_pal_map = {};
      for (let indx = 0; indx < named_layers.length; indx++) {
        let [layerName, colormapName] = this.getLayerNameColorMapName(
          named_layers[indx]
        );
        layer_pal_map[layerName] = "default/" + colormapName;
      }
      return layer_pal_map;
    },

    getLayerNameColorMapName(named_layer) {
      let rule = named_layer
        .getElementsByTagName("UserStyle")[0]
        .getElementsByTagName("se:CoverageStyle")[0]
        .getElementsByTagName("se:Rule")[0];
      let symbolizer = rule.getElementsByTagName("se:RasterSymbolizer");
      let colormapName, layerName;

      if (symbolizer.length) {
        layerName = named_layer.getElementsByTagName("se:Name")[0].textContent;
        colormapName = symbolizer[0]
          .getElementsByTagName("se:ColorMap")[0]
          .getElementsByTagName("resc:Segment")[0]
          .getElementsByTagName("resc:ValueList")[0]
          .getElementsByTagName("se:Name")[0].textContent;
      } else {
        symbolizer = rule.getElementsByTagName(
          "resc:ColoredSizedArrowSymbolizer"
        );
        layerName = symbolizer[0].getElementsByTagName(
          "resc:ArrowColourField"
        )[0].textContent;

        colormapName = symbolizer[0]
          .getElementsByTagName("se:ColorMap")[0]
          .getElementsByTagName("resc:Segment")[0]
          .getElementsByTagName("resc:ValueList")[0]
          .getElementsByTagName("se:Name")[0].textContent;
      }
      return [layerName, colormapName];
    },

    updateRGBSLD(sld_xml, band_list, range_list) {
      let dom_parser = new DOMParser();

      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");

      //xmldoc.getElementsByTagName("se:Name")[0].textContent = "RGB_DATASET/RGB_LAYERS";//Done for time being
      let band_name_nodes = xmldoc.getElementsByTagName("resc:BandName");
      let min_node_list = xmldoc.getElementsByTagName("resc:Minimum");
      let max_node_list = xmldoc.getElementsByTagName("resc:Maximum");
      let num_bands = band_list.length;

      for (let i = 0; i < num_bands; i++) {
        //console.log(i + ":" + band_name_nodes[i]);
        //console.log("range_list:" + range_list[i][0] + " " + range_list[i][1]);
        band_name_nodes[i].textContent = band_list[i];
        min_node_list[i].textContent = range_list[i][0];
        max_node_list[i].textContent = range_list[i][1];
      }

      let xml_serializer = new XMLSerializer();

      var out_sld = xml_serializer.serializeToString(xmldoc);

      return out_sld;
    },
    async getContourSLD(
      url,
      sld_xml,
      layerName,
      cont_info,
      contour_color,
      contour_style
    ) {
      if (sld_xml === undefined) {
        //let url = sld_json.prefix + "/" + sld_json.slds.single_color_contour;
        sld_xml = await this.fetchUrlXml(url);
        sld_xml = sld_xml.trim();
      }

      let contour_sld = this.updateContourSLD(
        sld_xml,
        layerName,
        cont_info,
        contour_color,
        contour_style
      );

      return contour_sld;
    },

    updateContourSLD(
      sld_xml,
      layerName,
      cont_info,
      contour_color,
      contour_style
    ) {
      let num_levels = Math.round(
        (cont_info.cnt_max - cont_info.cnt_min) / cont_info.cnt_int
      );
      let dom_parser = new DOMParser();
      /* console.log(
        "min:" +
          cont_info.cnt_min +
          " max:" +
          cont_info.cnt_max +
          " int:" +
          cont_info.cnt_int +
          " num_levels:" +
          num_levels
      ); */
      let xmldoc = dom_parser.parseFromString(sld_xml, "text/xml");
      xmldoc.getElementsByTagName("se:Name")[0].textContent = layerName;
      /* console.log(
        "Before NumberofContours:" +
          xmldoc.getElementsByTagName("resc:NumberOfContours")[0].textContent
      ); */
      xmldoc.getElementsByTagName(
        "resc:NumberOfContours"
      )[0].textContent = num_levels.toString();
      /* console.log(
        "After NumberofContours:" +
          xmldoc.getElementsByTagName("resc:NumberOfContours")[0].textContent
      ); */
      xmldoc.getElementsByTagName(
        "resc:Minimum"
      )[0].textContent = cont_info.cnt_min.toString();
      xmldoc.getElementsByTagName(
        "resc:Maximum"
      )[0].textContent = cont_info.cnt_max.toString();
      xmldoc.getElementsByTagName(
        "resc:ContourLineColour"
      )[0].textContent = contour_color;
      xmldoc.getElementsByTagName(
        "resc:ContourLineStyle"
      )[0].textContent = contour_style;
      let xml_serializer = new XMLSerializer();
      let out_sld = xml_serializer.serializeToString(xmldoc);
      //console.log("out_sld:" + out_sld);
      return out_sld;
    },

    calculateContInfo(min, max) {
      let span = Math.abs(max - min);
      let scale = parseInt(Math.log(span) / Math.log(10));

      if (span < 1) {
        scale = scale - 1;
      }

      let cscale = Math.pow(10, scale);
      let crange = span / cscale;
      let nrange = parseInt(crange);
      let rint = (nrange + 1) * 0.1 * cscale;
      let clInterval = 0.0;
      //let clMin, clMax;
      //console.log("span:" + span);
      if (span <= 300.0 && span > 5.0) {
        // typical case
        clInterval = parseFloat(rint);
        /* clMin = clInterval * parseInt(min / clInterval);
        clMax = clInterval * (1 + parseInt(max / clInterval)); */
      } else if (span <= 5.0) {
        // for max-min less than 5

        clInterval = parseFloat(rint);
        /* clMin = parseFloat(min);
        clMax = parseFloat(max); */
      } else {
        // for really big ranges, span > 300 make ints
        clInterval = parseFloat(parseInt(rint));
        /* clMin = parseFloat(parseInt(min));
        clMax = parseFloat(parseInt(max)); */
      }
      /*clMax = clMax + clInterval;
      clMin = clMin - clInterval;*/
      /* console.log("clMin/Max:" + clMin + "/" + clMin/clMax);
      
      console.log("min:" + typeof min + " max:" + typeof max); */
      //let cinfo = { cnt_min: clMin.toFixed(1), cnt_max: clMax.toFixed(1), cnt_int: clInterval.toFixed(1) };
      //console.log("min:" + min + " max:" + max + " interval:" + clInterval);
      let clMax = min + clInterval * (1 + parseInt((max - min) / clInterval)); //As per Guy Griffith recommendation
      //console.log("clMax:" + clMax);
      let cinfo = {
        cnt_min: min.toFixed(1),
        //cnt_max: max.toFixed(1),
        cnt_max: clMax.toFixed(1),
        cnt_int: clInterval.toFixed(1),
      };
      return cinfo;
    },
  },
};
