export default {
  methods: {
    convertIntToEvenDigitHex(num) {
      let out = (+num).toString(16).toUpperCase();
      if (out.length % 2 > 0) {
        out = `0${out}`;
      }
      return out;
    },
    //Input hex is #rrggbb, alpha is floating value
    convertHexToRGBA(hex, alpha) {
      return (
        "rgba(" +
        parseInt(hex.slice(1, 3), 16) +
        "," +
        parseInt(hex.slice(3, 5), 16) +
        "," +
        parseInt(hex.slice(5, 7), 16) +
        "," +
        alpha +
        ")"
      );
    },
    getAlphaFromRGBA(rgba_color) {
      //console.log("color:" + color);
      let rgba = rgba_color
        .slice(rgba_color.indexOf("(") + 1, rgba_color.indexOf(")"))
        .split(",");
      return parseFloat(rgba[3]);
    },

    convertRGBAToHex(rgba_color) {
      //console.log("color:" + color);
      let rgba = rgba_color
        .slice(rgba_color.indexOf("(") + 1, rgba_color.indexOf(")"))
        .split(",");
      let r, g, b;
      r = this.convertIntToEvenDigitHex(rgba[0]);
      g = this.convertIntToEvenDigitHex(rgba[1]);
      b = this.convertIntToEvenDigitHex(rgba[2]);
      return `#${r}${g}${b}`;
    },
  },
};
