export default {
  methods: {
    async fetchUrl(url_arr) {
      //console.log("url_arr:" + url_arr.length);

      let url_out = await Promise.all(
        url_arr.map((url) =>
          fetch(url).then((response) => {
            return response.ok ? response.json() : response.text();
          })
        )
      );
      //console.log("url:" + url_out.length);

      return url_out;
    },
    async fetchUrlXml(url) {
      /* let url_out = await Promise.all(
             url_arr.map(url =>
                 fetch(url).then(response => {
                     console.log("response:" + response.ok);
                     return response.text();
                 })
             )
         );*/
      let url_out = await fetch(url).then((response) => {
        //console.log("here:" + response.headers.entries());

        return response.text();
      });

      return url_out;
    },

    async fetchUrlXmls(url_arr) {
      let url_resps = await Promise.all(
        url_arr.map((url) => fetch(url).then((response) => response.text()))
      );
      return url_resps;
    },
  },
};
