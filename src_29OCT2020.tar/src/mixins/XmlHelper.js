export default {
  methods: {
    parsePointProbeResponse(xml_response) {
      let dom_parser = new DOMParser();
      let values = [];
      let xmldoc = dom_parser.parseFromString(xml_response, "text/xml");
      let value_tags = xmldoc.getElementsByTagName("value");
      for (let val_tag of value_tags) {
        let text_value = val_tag.textContent;
        values.push(Number.parseFloat(text_value, 10).toFixed(2));
      }
      return values;
    },

    getVectorStrokeElementChildren(sld) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld, "text/xml");
      let strokes = xmldoc.getElementsByTagName("sld:Stroke");
      return strokes[0].childNodes;
    },

    getStrokeChildValue(stroke_children, attrib_name) {
      let node_value = undefined;
      for (let indx = 0; indx < stroke_children.length; indx++) {
        if (stroke_children[indx].nodeType === Node.ELEMENT_NODE) {
          let child_name = stroke_children[indx].getAttribute("name");
          if (child_name === attrib_name) {
            node_value = stroke_children[indx].textContent;
            break;
          }
        }
      }
      return node_value;
    },

    setStrokeChildValue(stroke_children, attrib_name, child_value) {
      let node_value = undefined;
      for (let indx = 0; indx < stroke_children.length; indx++) {
        if (stroke_children[indx].nodeType === Node.ELEMENT_NODE) {
          let child_name = stroke_children[indx].getAttribute("name");
          if (child_name === attrib_name) {
            stroke_children[indx].textContent = child_value;
            break;
          }
        }
      }
      return node_value;
    },

    getVectorLayerColor(sld) {
      let stroke_children = this.getVectorStrokeElementChildren(sld);
      return this.getStrokeChildValue(stroke_children, "stroke");
    },
    setVectorLayerAttribute(sld, attrib_name, value) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(sld, "text/xml");
      let strokes = xmldoc.getElementsByTagName("sld:Stroke");
      let stroke_children = strokes[0].childNodes;
      this.setStrokeChildValue(stroke_children, attrib_name, value);
      let xml_serializer = new XMLSerializer();
      var out_sld = xml_serializer.serializeToString(xmldoc);
      return out_sld;
    },

    getVectorLayerWidth(sld) {
      let stroke_children = this.getVectorStrokeElementChildren(sld);
      let stroke_width = parseFloat(
        this.getStrokeChildValue(stroke_children, "stroke-width")
      );
      return stroke_width;
    },

    parsePointProbeResponseMap(xml_response) {
      let dom_parser = new DOMParser();
      let xmldoc = dom_parser.parseFromString(xml_response, "text/xml");
      let featureinfo_tags = xmldoc.getElementsByTagName("FeatureInfo");
      let feature_tags = xmldoc.getElementsByTagName("Feature");
      let response_map = {};
      //console.log("feature_info_tags:" + featureinfo_tags.length);
      //for (let fi of featureinfo_tags) {
      for (let indx = 0; indx < featureinfo_tags.length; indx++) {
        let fi = featureinfo_tags[indx];
        let ftag = feature_tags[indx];
        //let id_tag = fi.getElementsByTagName("id");
        let id_tag = ftag.getElementsByTagName("layer");
        let feature_name = id_tag.item(0).textContent;
        let value_tag = fi.getElementsByTagName("value");
        let value = value_tag.item(0).textContent;
        response_map[feature_name] = Number.parseFloat(value, 10).toFixed(2);
      }

      return response_map;
    },
  },
};
