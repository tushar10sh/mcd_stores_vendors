import { getArea, getLength } from "ol/sphere";
export default {
  methods: {
    formatLength(line, proj) {
      var length = getLength(line, proj);
      length *= proj.metersPerUnit_;
      let unit = "m;";
      if (length > 1000) {
        length /= 1000;
        unit = "Km";
      }
      return length.toFixed(2) + " " + unit;
    },

    /**
     * Format area output.
     * @param {Polygon} polygon The polygon.
     * @return {string} Formatted area.
     */
    formatArea(polygon, proj) {
      var area = getArea(polygon, proj);
      area *= Math.pow(proj.metersPerUnit_, 2);

      let unit = "m^2";
      if (area > 1000000) {
        area /= 1000000;
        unit = "Km^2";
      }
      return area.toFixed(2) + " " + unit;
    },
  },
};
