//import d3 from "../plugins/D3Importer.js";
export default {
  methods: {
    //Equivalent of numpy logspace
    logspace(start, end, nsteps) {
      //let my_start, my_end;
      /* if (start > end) {
        my_start = end;
        my_end = start;
      } else {
        my_start = start;
        my_end = end;
      } */

      /* let step_size =
        (Math.log10(my_end) - Math.log10(my_start)) / (nsteps - 1); */

      let step_size = (Math.log10(end) - Math.log10(start)) / (nsteps - 1);

      let out = [];
      for (let i = 0; i < nsteps; i++) {
        let val = Math.log10(start) + i * step_size;
        out.push(Math.pow(10, val));
        //out.push( start + i * step_size);
      }

      //console.log("mystart:" + my_start + "myend:" + my_end);

      /*let out = d3
        .range(Math.log10(my_start), Math.log10(my_end), step_size)
        .map((value) => Math.pow(10, value));*/

      /*if (start > end) {
        out = out.reverse();
      }*/
      return out;
    },

    makeItArrayIfItsNot(input) {
      return !Array.isArray(input) ? [input] : input;
    },
    findIntervalLeftBorderIndex(point, intervals) {
      //If point is beyond given intervals

      if (point <= intervals[0]) return 0;
      if (point >= intervals[intervals.length - 1]) return intervals.length - 1;
      //If point is inside interval
      //Start searching on a full range of intervals
      var indexOfNumberToCompare,
        leftBorderIndex = 0,
        rightBorderIndex = intervals.length - 1;
      //Reduce searching range till it find an interval point belongs to using binary search

      while (rightBorderIndex - leftBorderIndex !== 1) {
        indexOfNumberToCompare =
          leftBorderIndex +
          Math.floor((rightBorderIndex - leftBorderIndex) / 2);
        point >= intervals[indexOfNumberToCompare]
          ? (leftBorderIndex = indexOfNumberToCompare)
          : (rightBorderIndex = indexOfNumberToCompare);
      }
      return leftBorderIndex;
    },

    evaluateLinear(pointsToEvaluate, functionValuesX, functionValuesY) {
      var results = [];
      pointsToEvaluate = this.makeItArrayIfItsNot(pointsToEvaluate);
      let me = this;

      pointsToEvaluate.forEach(function(point) {
        var index = me.findIntervalLeftBorderIndex(point, functionValuesX);

        if (index == functionValuesX.length - 1) index--;

        //Added additional logic for thresholding the values at extrema
        let interp_val;
        if (point <= functionValuesX[0]) {
          interp_val = functionValuesY[0];
        } else if (point >= functionValuesX[functionValuesX.length - 1]) {
          interp_val = functionValuesY[functionValuesY.length - 1];
        } else {
          interp_val = me.linearInterpolation(
            point,
            functionValuesX[index],
            functionValuesY[index],
            functionValuesX[index + 1],
            functionValuesY[index + 1]
          );
        }

        results.push(interp_val);
      });
      return results;
    },

    /**
     *
     * Evaluates y-value at given x point for line that passes
     * through the points (x0,y0) and (y1,y1)
     *
     * @param x
     * @param x0
     * @param y0
     * @param x1
     * @param y1
     * @returns {Number}
     */

    linearInterpolation(x, x0, y0, x1, y1) {
      var a = (y1 - y0) / (x1 - x0);
      var b = -a * x0 + y0;
      return a * x + b;
    },
  },
};
