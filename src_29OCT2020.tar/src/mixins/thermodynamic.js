import d3 from "../plugins/D3Importer.js";
import { default as interpolate } from "./interpolation.js";
export default {
  mixins: [interpolate],
  data() {
    return {
      degCtoK: 273.15,
      Rs_da: 287.05, //Specific gas const for dry air, J kg^{-1} K^{-1}
      Cp_da: 1004.6, // Specific heat at constant pressure for dry air
      Epsilon: 0.622, //Epsilon=Rs_da/Rs_v; The ratio of the gas constants
    };
  },
  methods: {
    VaporPressure(tempc, phase = "liquid") {
      /*Water vapor pressure over liquid water or ice.

    INPUTS:
    tempc: (C) OR dwpt (C), if SATURATION vapour pressure is desired.
    phase: ['liquid'],'ice'. If 'liquid', do simple dew point. If 'ice',
    return saturation vapour pressure as follows:

    Tc>=0: es = es_liquid
    Tc <0: es = es_ice


    RETURNS: e_sat  (Pa)

    SOURCE: http://cires.colorado.edu/~voemel/vp.html (#2:
    CIMO guide (WMO 2008), modified to return values in Pa)

    This formulation is chosen because of its appealing simplicity,
    but it performs very well with respect to the reference forms
    at temperatures above -40 C. At some point I'll implement Goff-Gratch
    (from the same resource).
    */

      let over_liquid =
        6.112 *
        Math.exp((17.67 * tempc) / (tempc + 243.12)) *
        100; /*converting hPa to Pa */
      let over_ice =
        6.112 *
        Math.exp((22.46 * tempc) / (tempc + 272.62)) *
        100; /*converting hPa to Pa */
      //return where(tempc<0,over_ice,over_liquid)

      if (phase === "liquid") {
        tempc = over_liquid;
      } else if (phase === "ice") {
        tempc = tempc.map((t) => (t < 0 ? over_ice : over_liquid));
      }
      return tempc;
    },

    MixRatio(e, p) {
      /*Mixing ratio of water vapour
    INPUTS
    e (Pa) Water vapor pressure
    p (Pa) Ambient pressure

    RETURNS
    qv (kg kg^-1) Water vapor mixing ratio`
    */

      return (this.Epsilon * e) / (p - e);
    },
    VirtualTemp(tempk, pres, e) {
      /*Virtual Temperature

    INPUTS:
    tempk: Temperature (K)
    e: vapour pressure (Pa)
    p: static pressure (Pa)

    OUTPUTS:
    tempv: Virtual temperature (K)

    SOURCE: hmmmm (Wikipedia).
*/
      let tempvk = tempk / (1 - (e / pres) * (1 - this.Epsilon));
      return tempvk;
    },

    Latentc(tempc) {
      /*Latent heat of condensation (vapourisation)

    INPUTS:
    tempc (C)

    OUTPUTS:
    L_w (J/kg)

    SOURCE:
    http://en.wikipedia.org/wiki/Latent_heat#Latent_heat_for_condensation_of_water
    */

      return (
        1000 *
        (2500.8 - 2.36 * tempc + 0.0016 * tempc ** 2 - 0.00006 * tempc ** 3)
      );
    },

    GammaW(tempk, pres) {
      /*Function to calculate the moist adiabatic lapse rate (deg C/Pa) based
    on the environmental temperature and pressure.

    INPUTS:
    tempk (K)
    pres (Pa)
    RH (%)

    RETURNS:
    GammaW: The moist adiabatic lapse rate (Deg C/Pa)
    REFERENCE:
    http://glossary.ametsoc.org/wiki/Moist-adiabatic_lapse_rate
    (Note that I multiply by 1/(grav*rho) to give MALR in deg/Pa)

    */

      let tempc = tempk - this.degCtoK;

      let es = this.VaporPressure(tempc);
      let ws = this.MixRatio(es, pres);

      let tempv = this.VirtualTemp(tempk, pres, es);
      let latent = this.Latentc(tempc);

      let Rho = pres / (this.Rs_da * tempv);

      let A = -1 * (1.0 + (latent * ws) / (this.Rs_da * tempk));

      let B =
        Rho *
        (this.Cp_da +
          (this.Epsilon * latent * latent * ws) / (this.Rs_da * tempk * tempk));

      let Gamma = A / B;

      return Gamma;
    },

    getMixingRatioIsoPleths(P, w) {
      let T = [];
      for (let ww of w) {
        let T_interm = P.map((pval) => {
          let e_val = pval * (ww / (0.622 + ww));
          return 243.5 / (17.67 / Math.log(e_val / 6.112) - 1);
        });
        T.push(T_interm);
      }
      return T;
    },

    dry_ascent(startp, startt, startdp, nsteps = 101) {
      /* -------------------------------------------------------------------
     Lift a parcel dry adiabatically from startp to LCL.
     Init temp is startt in C, Init dew point is stwrtdp,
     pressure levels are in hPa
     ------------------------------------------------------------------- */

      if (startdp === startt) {
        return [[startp], [startt], [startdp]];
      }

      //let Pres_arr = this.logspace(startp, 600, nsteps);

      let Pres_arr = this.logspace(startp, 500, nsteps);
      //Lift the dry parcel
      let T_dry_arr = Pres_arr.map(
        (p) =>
          (startt + this.degCtoK) * (p / startp) ** (this.Rs_da / this.Cp_da) -
          this.degCtoK
      );

      //Mixing ratio isopleth
      let starte = this.VaporPressure(startdp); //Returns in pascal
      let startw = this.MixRatio(starte, startp * 100);

      let e_arr = Pres_arr.map((p) => (p * startw) / (0.622 + startw));

      let T_iso_arr = e_arr.map(
        (e) => 243.5 / (17.67 / Math.log(e / 6.112) - 1)
      );

      /*Solve for the intersection of these lines (LCL).
    interp requires the x argument (argument 2)
    to be ascending in order! */
      let T_iso_arr_minus_T_dry_arr = [];
      let num_eles = T_iso_arr.length;
      for (let indx = 0; indx < num_eles; indx++) {
        T_iso_arr_minus_T_dry_arr.push(T_iso_arr[indx] - T_dry_arr[indx]);
      }

      let P_lcl_arr = this.evaluateLinear(
        [0],
        T_iso_arr_minus_T_dry_arr,
        Pres_arr
      );
      /* console.log("startp:" + startp);
      console.log("P_lcl:" + P_lcl_arr[0]); */

      //presdry=linspace(startp,P_lcl)
      let presdry_arr = this.logspace(startp, P_lcl_arr[0], nsteps);

      let tempdry_arr = this.evaluateLinear(
        presdry_arr,
        [...Pres_arr].reverse(),
        [...T_dry_arr].reverse()
      );

      let tempiso_arr = this.evaluateLinear(
        presdry_arr,
        [...Pres_arr].reverse(),
        [...T_iso_arr].reverse()
      );

      /* 
      console.log(
        "presdry:" +
          presdry_arr +
          " tempdry:" +
          tempdry_arr +
          " tempiso:" +
          tempiso_arr
      ); */

      return [presdry_arr, tempdry_arr, tempiso_arr];
    },
    moist_ascent(startp, startt, ptop = 10, nsteps = 501) {
      /*-------------------------------------------------------------------
    # Lift a parcel moist adiabatically from startp to endp.
    # Init temp is startt in C, pressure levels are in hPa
    # -------------------------------------------------------------------*/
      let preswet_arr = this.logspace(startp, ptop, nsteps);
      let temp = startt;
      let tempwet_arr = [];
      tempwet_arr.push(startt);

      for (let ii = 0; ii < preswet_arr.length - 1; ii++) {
        let delp = preswet_arr[ii] - preswet_arr[ii + 1];
        temp =
          temp +
          100 *
            delp *
            this.GammaW(
              temp + this.degCtoK,
              (preswet_arr[ii] - delp / 2) * 100
            );
        tempwet_arr.push(temp);
      }

      return [preswet_arr, tempwet_arr];
    },
    //numpy sign function js translation
    signarr(arr) {
      return arr.map((value) => (value < 0 ? -1 : 1));
    },
    signscalar(val) {
      return val < 0 ? -1 : 1;
    },

    npdiff(arr) {
      let out = [];
      for (let indx = 0; indx < arr.length - 1; indx++) {
        out.push(arr[indx + 1] - arr[indx]);
      }
      return out;
    },
    absarr(arr) {
      return arr.map((entry) => Math.abs(entry));
    },

    makeArrayWithValue(num_eles, value) {
      let out = new Array(num_eles);
      for (let indx = 0; indx < num_eles; indx++) {
        out[indx] = value;
      }
      return out;
    },

    solveEquation(preswet_arr, func_arr) {
      //console.log("preswet_arr:" + preswet_arr);
      let dsign = this.signarr(func_arr);
      let isdiff = this.makeArrayWithValue(dsign.length, false);
      let shift = this.makeArrayWithValue(dsign.length, false);
      let abs_diff_flag = this.absarr(this.npdiff(dsign)).map((value) =>
        value <= 0 ? false : true
      );

      shift[shift.length - 1] = isdiff[0];
      for (let indx = 1; indx < isdiff.length; indx++) {
        isdiff[indx] = abs_diff_flag[indx - 1];
        shift[indx - 1] = isdiff[indx];
      }

      let preswet_func_enh = [];

      for (let indx = 0; indx < isdiff.length; indx++) {
        preswet_func_enh.push({
          preswet: preswet_arr[indx],
          func: func_arr[indx],
          shift: shift[indx],
          isdiff: isdiff[indx],
        });
      }

      let num_eles = isdiff.reduce((ac, val) => ac + (val ? 1 : 0), 0);

      /*let sols = [];
      let stab = [];*/
      let result = [];
      for (let indx = 0; indx < num_eles; indx++) {
        let shift_values = preswet_func_enh.filter((entry) => entry.shift);
        let isdiff_values = preswet_func_enh.filter((entry) => entry.isdiff);
        let shift_preswet = shift_values.map((svalue) => svalue.preswet);
        let shift_func = shift_values.map((dvalue) => dvalue.func);

        let isdiff_preswet = isdiff_values.map((svalue) => svalue.preswet);
        let isdiff_func = isdiff_values.map((dvalue) => dvalue.func);

        let f0 = isdiff_func[indx];
        let f1 = shift_func[indx];
        let p0 = isdiff_preswet[indx];
        let p1 = shift_preswet[indx];

        let slope = (f1 - f0) / (p1 - p0);
        result.push({ sol: p0 - f0 / slope, stab: this.signscalar(slope) });
      }

      return result;
    },

    getCape(t_dp_prof, startp, startt, startdp) {
      let [presdry_arr, tempdry_arr, tempiso_arr] = this.dry_ascent(
        startp,
        startt,
        startdp,
        501
        //101
      );
      /* console.log(
        "startp:" + startp + " startp:" + startt + " startdp:" + startdp
      ); */

      let P_lcl = presdry_arr[presdry_arr.length - 1];
      let T_lcl = tempdry_arr[tempdry_arr.length - 1];

      let [preswet_arr, tempwet_arr] = this.moist_ascent(
        P_lcl,
        T_lcl,
        10,
        501 /*101*/
      );

      let tparcel_arr = tempdry_arr.concat(tempwet_arr.slice(1));
      let pparcel_arr = presdry_arr.concat(preswet_arr.slice(1));
      //let dpparcel = tempiso_arr.concat(tempwet_arr.slice(1));
      let pres_arr = t_dp_prof.map((prof) => prof.press);
      let temp_arr = t_dp_prof.map((prof) => prof.temp);
      //let dewpt_arr = t_dp_prof.map((prof) => prof.dewpt);
      let hght_arr = t_dp_prof.map((prof) => prof.hgt);

      let tempenv_arr = this.evaluateLinear(pparcel_arr, pres_arr, temp_arr);

      /*console.log("temp_arr:" + temp_arr);
      console.log("pparcel_arr:" + pparcel_arr[0]);
      console.log("pres_arr:" + [...pres_arr].reverse()[0]);
      console.log("temp_arr:" + [...temp_arr].reverse()[0]);*/
      //console.log("tempenv_arr:" + tempenv_arr);

      let pparcel_lt_plcl_arr = pparcel_arr
        .filter((p) => p <= P_lcl, [])
        .reverse();

      let tparcel_tempenv_diff_press_arr = [];
      for (let indx = 0; indx < tparcel_arr.length; indx++) {
        tparcel_tempenv_diff_press_arr.push({
          diff: tparcel_arr[indx] - tempenv_arr[indx],
          press: pparcel_arr[indx],
        });
      }

      let tparcel_tempenv_diff_lt_plcl_arr = tparcel_tempenv_diff_press_arr
        .filter((entry) => entry.press <= P_lcl, [])
        .map((entry) => entry.diff)
        .reverse();

      let eqlev_stab_arr = this.solveEquation(
        pparcel_lt_plcl_arr,
        tparcel_tempenv_diff_lt_plcl_arr
      );

      let descorder_eqlev_stab_arr = eqlev_stab_arr
        .sort((v1, v2) => (v1.sol < v2.sol ? -1 : v1.sol > v2.sol ? 1 : 0))
        .reverse();

      let eqlev_stab_unstab_arr = descorder_eqlev_stab_arr.map((entry) => ({
        sol: entry.sol,
        isstab: entry.stab === 1 ? true : false,
        unstab: entry.stab === 1 ? false : true,
      }));

      let tenv_lcl = this.evaluateLinear(
        P_lcl,
        [...pparcel_arr].reverse(),
        [...tempenv_arr].reverse()
      )[0];

      let P_lfc, P_el;

      if (eqlev_stab_unstab_arr.length == 0) {
        P_lfc = NaN;
        P_el = NaN;
      } else if (T_lcl > tenv_lcl) {
        P_lfc = P_lcl;
        //P_el = eqlev_arr[isstab][0];
        P_el = eqlev_stab_unstab_arr.filter((entry) => entry.isstab, [])[0].sol;
      } else if (eqlev_stab_unstab_arr.length > 0) {
        //P_lfc = eqlev_arr[unstab][0];
        P_lfc = eqlev_stab_unstab_arr.filter((entry) => entry.unstab, [])[0]
          .sol;
        //P_el = eqlev_arr[isstab][0];
        P_el = eqlev_stab_unstab_arr.filter((entry) => entry.isstab, [])[0].sol;
      } else {
        if (eqlev_stab_unstab_arr[0].isstab) {
          P_el = eqlev_stab_unstab_arr.filter((entry) => entry.isstab, [])[0]
            .sol;
          //P_el = eqlev_arr[isstab][0];
          P_lfc = NaN;
        } else {
          P_lfc = NaN;
          P_el = NaN;
        }
      }

      //Calculation of SI(ShowAlter Index)

      let tparcel_850 = this.evaluateLinear(
        850,
        [...pparcel_arr].reverse(),
        [...tparcel_arr].reverse()
      );
      let temp_850 = t_dp_prof.filter((value) => value.press == 850);
      let si = NaN;

      if (tparcel_850.length && temp_850.length) {
        si = temp_850[0].temp - tparcel_850[0];
      }

      if (isNaN(P_lfc)) {
        return [
          P_lcl,
          T_lcl,
          P_lfc,
          P_el,
          0,
          0,
          presdry_arr,
          tempdry_arr,
          tempiso_arr,
          preswet_arr,
          tempwet_arr,
          si,
        ];
      }

      /* let soft_dewpt_arr = dewpt_arr.map((value) =>
        isNaN(value) ? -200 : value
      );

      let dwptenv_arr = this.evaluateLinear(
        pparcel_arr,
        pres_arr,
        soft_dewpt_arr
      ); */

      let hghtenv_arr = this.evaluateLinear(pparcel_arr, pres_arr, hght_arr);

      let comb_arr = [];
      for (let indx = 0; indx < tparcel_arr.length; indx++) {
        comb_arr.push({
          tparcel: tparcel_arr[indx],
          pparcel: pparcel_arr[indx],
          tempenv: tempenv_arr[indx],
          hgt: hghtenv_arr[indx],
        });
      }
      let cape_input = comb_arr
        .filter(
          (entry) =>
            entry.tparcel >= entry.tempenv &&
            entry.pparcel <= P_lfc &&
            entry.pparcel > P_el
        )
        .map((entry) => ({
          value:
            (9.81 * (entry.tparcel - entry.tempenv)) / (entry.tempenv + 273.15),
          hgt: entry.hgt,
        }));

      let cin_input = comb_arr
        .filter(
          (entry) => entry.tparcel < entry.tempenv && entry.pparcel > P_lfc
        )
        .map((entry) => ({
          value:
            (9.81 * (entry.tparcel - entry.tempenv)) / (entry.tempenv + 273.15),
          hgt: entry.hgt,
        }));
      let CAPE = this.trapz(cape_input);
      let CIN = this.trapz(cin_input);
      return [
        P_lcl,
        T_lcl,
        P_lfc,
        P_el,
        CAPE,
        CIN,
        presdry_arr,
        tempdry_arr,
        tempiso_arr,
        preswet_arr,
        tempwet_arr,
        si,
      ];
    },

    getCCL_ConvT(t_dp_prof) {
      let press_arr = t_dp_prof.map((prof) => prof.press);
      let temp_arr = t_dp_prof.map((prof) => prof.temp);
      let dewpt_arr = t_dp_prof.map((prof) => prof.dewpt);
      /* console.log("press_arr:" + press_arr);
      console.log("temp_arr:" + temp_arr);
      console.log("dewpt_arr:" + dewpt_arr); */

      //Pressure Values are from 0 to 100
      let pl = press_arr[press_arr.length - 1] / 10;
      let pll = press_arr[press_arr.length - 1] / 10;
      let tds = dewpt_arr[dewpt_arr.length - 1] + this.degCtoK;

      let ess = 0.611 * Math.exp(5423 * (1 / this.degCtoK - 1 / tds));
      let rss = (0.622 * ess) / (pll - ess);
      let qss = rss * 1000.0;

      let nlev = press_arr.length;

      let pmin = press_arr[0] / 10;
      let temp_env;
      //let j = 0;
      let tconv = NaN;
      let pccl = NaN;
      //console.log("pl:" + pl);

      while (pl >= pmin) {
        let k = 0;
        let condn = 1;

        while (k < nlev - 1 && condn === 1) {
          let n = k + 1;
          if (pl === press_arr[k] / 10) {
            temp_env = temp_arr[k];
            condn = 0;
          }

          //In Ascending order
          if (pl > press_arr[k] / 10 && pl < press_arr[n] / 10) {
            let pb = press_arr[k] / 10;
            let pa = press_arr[n] / 10;

            let tmn =
              (Math.log10(pb) * temp_arr[k] + Math.log10(pa) * temp_arr[n]) /
              Math.log10(pa * pb);
            let tkmn = tmn + this.degCtoK;

            let LayerD = (287 * tkmn * Math.log(pb / pa)) / 9.8;

            let DZ = (287 * tkmn * Math.log(pb / pl)) / 9.8;
            let DT = temp_arr[n] - temp_arr[k];

            temp_env = temp_arr[k] + (DZ * DT) / LayerD;
            condn = 0;
          }
          k = k + 1;
        }

        let tmix =
          Math.pow(
            1 / this.degCtoK -
              0.0001844 *
                Math.log(
                  ((qss / 1000.0) * pl) / (0.611 * (qss / 1000.0 + 0.622))
                ),
            -1
          ) - this.degCtoK;

        let dift = Math.abs(temp_env - tmix);
        //console.log("dift:" + dift);
        if (dift <= 0.2) {
          pccl = pl * 10;
          let tccl = temp_env + this.degCtoK;
          let thetccl = Math.pow(100 / pl, 0.286) * tccl;
          let tc1 = Math.pow(100 / pll, 0.286);
          tconv = thetccl / tc1 - this.degCtoK;
        }
        pl = pl - 0.5;
      }

      return [tconv, pccl];
    },

    trapz(input) {
      let sum = 0;
      for (let indx = 1; indx < input.length; indx++) {
        sum +=
          ((input[indx - 1].value + input[indx].value) / 2.0) *
          (input[indx].hgt - input[indx - 1].hgt);
      }
      return sum;
    },

    getMoistAdiabats(tmin, tmax, tstep_size, preswet) {
      /*let pbase = 1050,
        ptop = 10;*/
      //let nsteps = 501;
      //console.log("pbase:" + pbase + " ptop:" + ptop + " nsteps:" + nsteps);
      //let step_size = (Math.log10(pbase) - Math.log10(ptop)) / (nsteps - 1);

      //let tstep_size = (tmax - tmin) / (tsteps - 1);
      let temps = d3.range(tmin, tmax, tstep_size);
      //console.log("temps:" + temps);

      /* let preswet = d3.range(ptop, startp, nsteps);
    console.log("preswet:" + preswet); */
      //let ptop = 10;
      let wet_adiabats = [];
      for (let t of temps) {
        //let preswet = d3.range(Math.log10(ptop), Math.log10(pbase), step_size);

        let tempwet = [];
        tempwet.push(t);
        let temp = t;
        let num_entries = preswet.length;
        for (let ii = 0; ii < num_entries - 1; ii++) {
          let delp = preswet[ii] - preswet[ii + 1];
          temp +=
            100 *
            delp *
            this.GammaW(temp + this.degCtoK, (preswet[ii] - delp / 2) * 100);
          tempwet.push(temp);
        }
        wet_adiabats.push(tempwet);
      }
      return wet_adiabats;
    },
  },
};
