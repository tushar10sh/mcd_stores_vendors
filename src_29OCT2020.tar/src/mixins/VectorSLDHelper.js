export default {
  methods: {
    getDefaultLabelPlacement() {
      return (
        "<LabelPlacement>" +
        "<PointPlacement>" +
        "<AnchorPoint>" +
        "<AnchorPointX>0.0</AnchorPointX>" +
        "<AnchorPointY>0.5</AnchorPointY>" +
        "</AnchorPoint>" +
        "</PointPlacement>" +
        "</LabelPlacement>"
      );
    },

    decodeSLD(input_sld) {
      let sld_pairs = input_sld.split(";");
      let num_slds = sld_pairs.length;
      let lc, lo, lw;
      let my_label_item = "";
      let font_size = 0;
      for (let i = 0; i < num_slds; i++) {
        let sld_value_arr = sld_pairs[i].split("=");
        if (sld_value_arr[0] == "color") {
          lc = sld_value_arr[1];
        } else if (sld_value_arr[0] == "width") {
          lw = sld_value_arr[1];
        } else if (sld_value_arr[0] == "opacity") {
          lo = sld_value_arr[1];
        } else if (sld_value_arr[0] == "label_item") {
          my_label_item = sld_value_arr[1];
        } else if (sld_value_arr[0] == "label_font_size") {
          font_size = parseInt(sld_value_arr[1]);
        }
      }
      let sld = {
        line_color: lc,
        line_opacity: parseFloat(lo),
        line_width: parseFloat(lw),
        label_item: my_label_item,
        label_font_size: font_size,
      };
      return sld;
    },

    createSLD(layer_name, decoded_sld, is_base_layer = false) {
      var enable_label = decoded_sld.label_item !== "";
      //console.log("enable_label:" + decoded_sld.label_item);
      let sld = "<sld:StyledLayerDescriptor ";
      sld += 'xmlns="http://www.opengis.net/ogc" ';
      sld += 'xmlns:sld="http://www.opengis.net/sld" ';
      sld += 'xmlns:ogc="http://www.opengis.net/ogc" ';
      sld += 'xmlns:gml="http://www.opengis.net/gml" ';
      sld += 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ';
      sld += 'version="1.0.0" ';
      sld +=
        'xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.0.0/StyledLayerDescriptor.xsd"> ';
      let multi_layer = layer_name.includes(",");
      if (is_base_layer || !multi_layer) {
        sld += "<sld:NamedLayer> ";
        sld += "<sld:Name>" + layer_name + "</sld:Name> ";
        sld += "<sld:UserStyle> ";
        sld += "<sld:Name>lineSymbolizer</sld:Name> ";
        sld += "<sld:Title>lineSymbolizer</sld:Title> ";
        sld += "<sld:FeatureTypeStyle> ";
        sld += "<sld:Rule> ";
        sld += "<sld:LineSymbolizer> ";
        sld += "<sld:Stroke> ";
        sld +=
          '<sld:CssParameter name="stroke">' +
          decoded_sld.line_color +
          "</sld:CssParameter> ";
        sld +=
          '<sld:CssParameter name="stroke-opacity">' +
          decoded_sld.line_opacity +
          "</sld:CssParameter> ";
        sld +=
          '<sld:CssParameter name="stroke-width">' +
          decoded_sld.line_width +
          "</sld:CssParameter> ";
        sld += "</sld:Stroke> ";
        sld += "</sld:LineSymbolizer> ";
        if (enable_label) {
          sld += "<TextSymbolizer> ";
          sld += "<Label> ";
          sld +=
            "<ogc:PropertyName>" +
            decoded_sld.label_item +
            "</ogc:PropertyName> ";
          sld += "</Label> ";
          sld += "<Font> ";
          sld +=
            '<sld:CssParameter name="font-family">Arial</sld:CssParameter> ';
          sld +=
            '<sld:CssParameter name="font-size">' +
            decoded_sld.label_font_size +
            "</sld:CssParameter> ";
          sld +=
            '<sld:CssParameter name="font-style">normal</sld:CssParameter> ';
          sld +=
            '<sld:CssParameter name="font-weight">bold</sld:CssParameter> ';
          sld += "</Font> ";
          sld += this.getDefaultLabelPlacement();
          sld += "<Fill> ";
          sld +=
            '<sld:CssParameter name="fill">' +
            decoded_sld.line_color +
            "</sld:CssParameter> ";
          sld += "</Fill> ";
          sld += "</TextSymbolizer> ";
        }
        sld += "</sld:Rule> ";
        sld += "</sld:FeatureTypeStyle> ";
        sld += "</sld:UserStyle> ";
        sld += "</sld:NamedLayer> ";
      } else {
        let layer_names = layer_name.split(",");
        let num_layers = layer_names.length;
        for (var i = 0; i < num_layers; i++) {
          sld += "<sld:NamedLayer> ";
          sld += "<sld:Name>" + layer_names[i] + "</sld:Name> ";
          sld += "<sld:UserStyle> ";
          sld += "<sld:Name>lineSymbolizer</sld:Name> ";
          sld += "<sld:Title>lineSymbolizer</sld:Title> ";
          sld += "<sld:FeatureTypeStyle> ";
          sld += "<sld:Rule> ";
          sld += "<sld:LineSymbolizer> ";
          sld += "<sld:Stroke> ";
          sld +=
            '<sld:CssParameter name="stroke">' +
            decoded_sld.line_color +
            "</sld:CssParameter> ";
          sld +=
            '<sld:CssParameter name="stroke-opacity">' +
            decoded_sld.line_opacity +
            "</sld:CssParameter> ";
          sld +=
            '<sld:CssParameter name="stroke-width">' +
            decoded_sld.line_width +
            "</sld:CssParameter> ";
          sld += "</sld:Stroke> ";
          sld += "</sld:LineSymbolizer> ";
          if (enable_label) {
            sld += "<TextSymbolizer> ";
            sld += "<Label> ";
            sld +=
              "<ogc:PropertyName>" +
              decoded_sld.label_item +
              "</ogc:PropertyName> ";
            sld += "</Label> ";
            sld += "<Font> ";
            sld +=
              '<sld:CssParameter name="font-family">Arial</sld:CssParameter> ';
            sld +=
              '<sld:CssParameter name="font-size">' +
              decoded_sld.label_font_size +
              "</sld:CssParameter> ";
            sld +=
              '<sld:CssParameter name="font-style">normal</sld:CssParameter> ';
            sld +=
              '<sld:CssParameter name="font-weight">bold</sld:CssParameter> ';
            sld += "</Font> ";
            sld += this.getDefaultLabelPlacement();
            sld += "<Fill> ";
            sld +=
              '<sld:CssParameter name="fill">' +
              decoded_sld.line_color +
              "</sld:CssParameter> ";
            sld += "</Fill> ";
            sld += "</TextSymbolizer> ";
          }
          sld += "</sld:Rule> ";
          sld += "</sld:FeatureTypeStyle> ";
          sld += "</sld:UserStyle> ";
          sld += "</sld:NamedLayer> ";
        }
      }
      sld += "</sld:StyledLayerDescriptor>";
      return sld;
    },
  },
};
