export default {
  methods: {
    addJSONObjToLocalStorage(key, obj) {
      localStorage.setItem(key, JSON.stringify(obj));
    },
    getJSONObjFromLocalStorage(key) {
      return JSON.parse(localStorage.getItem(key));
    },
    clearLocalStorage() {
      localStorage.clear();
    },
  },
};
