export default {
  IST_TZ: { id: "Asia/Calcutta", caption: "IST" },
  UTC_TZ: { id: "UTC", caption: "UTC" },
};
