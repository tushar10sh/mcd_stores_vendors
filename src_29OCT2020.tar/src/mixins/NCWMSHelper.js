import moment from "moment";
import moment_timezone from "moment-timezone";
import { default as SLDHelpers } from "./SLDHelpers.js";
import { default as Constants } from "./Constants.js";

export default {
  mixins: [SLDHelpers],

  data() {
    return {
      wms_date_format: "YYYY-MM-DDTHH:mm:ss",
    };
  },

  methods: {
    createFormattedDateTimeString(layer_time) {
      return moment_timezone(layer_time)
        .tz("UTC")
        .format(this.wms_date_format);
    },

    /* createFcstRefTime(time_str) {
      return new Date(moment(time_str + "Z", "DD-MM-YYYY hhZ"));
    }, */

    getFcstRefTimeAct(datesWithData, fcst_hr) {
      let yr_str = Object.keys(datesWithData)[0];
      let mn_str = Object.keys(datesWithData[yr_str])[0];
      let dy = datesWithData[yr_str][mn_str][0];
      let mn = parseInt(mn_str) + 1; //Because month is 0 to 11 but moment accepts 1 to 12
      let dy_str = this.format1DigitTo2Digit(dy);
      mn_str = this.format1DigitTo2Digit(mn);
      let time_str = dy_str + "-" + mn_str + "-" + yr_str + " " + fcst_hr;
      return new Date(moment(time_str + "Z", "DD-MM-YYYY hhZ"));
      /* return this.createFcstRefTime(
        dy_str + "-" + mn_str + "-" + yr_str + " " + fcst_hr
      ); */
    },

    creatFormattedDateString: (date, frmt) => moment(date).format(frmt),
    createFormattedTimeString(time, frmt, mtz = Constants.UTC_TZ.id) {
      //console.log("tz:" + mtz);
      let frmt_tm = moment_timezone(time)
        .tz(mtz)
        .format(frmt);
      return frmt_tm;
    },

    createFormattedTimeString2(date, time, time_format, tz) {
      let day_diff = 0;
      //console.log("this.UTC_TZ:" + Constants.UTC_TZ);
      //if (tz !== Constants.UTC_TZ.id) {
      /* console.log("sel_date:" + date);
        console.log("sel_time:" + typeof time); */
      let sel_day = parseInt(this.creatFormattedDateString(date, "DDD"), 10);
      let tm_day = parseInt(this.creatFormattedDateString(time, "DDD"), 10);

      day_diff = tm_day - sel_day;
      //}
      let day_prefix =
        day_diff > 0 ? `+${day_diff} ` : day_diff < 0 ? `${day_diff} ` : "";
      return `${day_prefix} ${this.createFormattedTimeString(
        time,
        time_format,
        tz
      )}`;
    },

    getURLParameter: (url, param) => new URLSearchParams(url).get(param),

    createLayerNameFromArray(layer_names) {
      let num_layers = layer_names.length;

      let formatted_layer_name = "";
      for (let i = 0; i < num_layers; i++) {
        formatted_layer_name += layer_names[i];
        if (i != num_layers - 1) {
          formatted_layer_name += ",";
        }
      }
      return formatted_layer_name;
    },

    createArrayFromLayerName(layer_name) {
      return layer_name.split(",");
    },

    createWmsLayer(
      layer_info,
      layer_time,
      plt,
      elevation_values,
      scaleRange,
      opacity,
      sld
    ) {
      let frmt_dt_time = this.createFormattedDateTimeString(layer_time);
      let my_satlayer = undefined;

      my_satlayer = {
        url: layer_info.url_prefix,
        version: layer_info.wms_version,
        //layerName: formatted_layer_name,
        projection: layer_info.sat_projection,
        img_format: layer_info.img_format,
        attribution: layer_info.attribution,
        visible: layer_info.visible,
        opacity: opacity,
        time: frmt_dt_time,
        sld_name: layer_info.sld,
        //range_options: layer_info.range_options,
        autoscl: layer_info.autoscl,
        minResolution: layer_info.minResolution,
        maxResolution: layer_info.maxResolution,
      };

      if (sld !== undefined) {
        let formatted_layer_name = this.createLayerNameFromArray(
          layer_info.layer_name
        );

        //console.log("formatted_layer_name:" + formatted_layer_name);
        my_satlayer.layerName = formatted_layer_name;
        my_satlayer.range_options = layer_info.range_options;
        my_satlayer.extParams = {
          sld_body: sld,
        };
        /* my_satlayer = {
          url: layer_info.url_prefix,
          version: layer_info.wms_version,
          layerName: formatted_layer_name,
          projection: layer_info.sat_projection,
          img_format: layer_info.img_format,
          attribution: layer_info.attribution,
          visible: true,
          opacity: opacity,
          time: frmt_dt_time,
          range_options: layer_info.range_options,
          autoscl: layer_info.autoscl,
          minResolution: layer_info.minResolution,
          maxResolution: layer_info.maxResolution,
          extParams: {
            sld_body: sld,
          },
        }; */
      } else {
        console.log("layerinfo.clipRange:" + layer_info.clipRange);
        let indiv_scaleRange = scaleRange[0];
        my_satlayer.layerName = layer_info.layer_name;
        my_satlayer.extParams = {};
        /* if (layer_info.sld !== undefined) {
          my_satlayer.extParams.sld = layer_info.sld;
        } else { */
        my_satlayer.extParams = {
          style: layer_info.style + "/" + plt,
          BELOWMINCOLOR: layer_info.clipRange ? "#00000000" : "extend",
          ABOVEMAXCOLOR: layer_info.clipRange ? "#00000000" : "extend",
          COLORSCALERANGE: indiv_scaleRange[0] + "," + indiv_scaleRange[1],
          elevation: elevation_values[0],
          sld: layer_info.sld,
        };
        //}
        //my_satlayer.extParams.elevation = elevation_values[0];
        /* my_satlayer = {
          url: layer_info.url_prefix,
          version: layer_info.wms_version,
           layerName: layer_info.layer_name,
          projection: layer_info.sat_projection,
          img_format: layer_info.img_format,
          attribution: layer_info.attribution,
          visible: true,
          opacity: opacity,
          time: frmt_dt_time,
          autoscl: layer_info.autoscl,
          minResolution: layer_info.minResolution,
          maxResolution: layer_info.maxResolution,
          extParams: {
            style: "default/" + plt,
            BELOWMINCOLOR: "extend",
            ABOVEMAXCOLOR: "extend",
            elevation: elevation_values[0],
            COLORSCALERANGE: indiv_scaleRange[0] + "," + indiv_scaleRange[1],
          },
        }; */
      }
      return my_satlayer;
    },

    getColorRangeExtParams(raster_layer, scaleRanges) {
      let new_extParams = {};
      for (let key of Object.keys(raster_layer.extParams)) {
        new_extParams[key] = raster_layer.extParams[key];
      }
      if (raster_layer.extParams.sld_body !== undefined) {
        /* let ds_layers = raster_layer.layerName.split("/");
        let ds = ds_layers[0];
        let layers = ds_layers[1].split(","); */

        //  layers = layers.map((layer) => ds + "/" + layer);
        let layers = this.createArrayFromLayerName(raster_layer.layerName);
        let sld_body = raster_layer.extParams.sld_body;
        let out_sld = this.updateSLD(sld_body, layers, scaleRanges);
        new_extParams.sld_body = out_sld;
      } else {
        new_extParams.COLORSCALERANGE =
          scaleRanges[0][0] + "," + scaleRanges[0][1];
      }
      return new_extParams;
    },

    getDateArray(dates_with_data, should_reverse = true) {
      //let dates_with_data = metadata.datesWithData;
      let date_arr = [];
      for (let yr in dates_with_data) {
        var months = dates_with_data[yr];
        for (let mn in months) {
          var days = months[mn];
          for (let dy in days) {
            let date = new Date(yr, mn, days[dy]);
            date_arr.push(date);
          }
        }
      }
      if (should_reverse) {
        if (date_arr[0] < date_arr[date_arr.length - 1]) {
          date_arr = date_arr.reverse();
        }
      }
      return date_arr;
    },

    createTimeStepsUrl(url_prefix, layer_name, frmt_date) {
      let time_steps_url = `${url_prefix}&request=GetMetadata&item=timesteps&layerName=${layer_name}&day=${frmt_date}`;
      return time_steps_url;
    },

    /* createTimeStepsUrl2(wms_url, layer_name, frmt_date) {
      //let wms_url = `${layer_info.url_prefix}&dataset=${layer_info.ds_name}`;
      let time_steps_url = `${wms_url}&request=GetMetadata&item=timesteps&layerName=${layer_name}&day=${frmt_date}`;
      return time_steps_url;
    }, */

    /*createLayerDetailsUrl(layer_info) {
      //let wms_url = `${layer_info.url_prefix}&dataset=${layer_info.ds_name}`;
      let metadata_url = `${layer_info.url_prefix}&request=GetMetadata&item=layerDetails&layerName=${layer_info.layer_name}`;
      metadata_url = metadata_url.trim();
      return metadata_url;
    },*/

    createLayerDetailsUrl(url_prefix, layer_name) {
      let url_arr = [];
      //console.log("layer_name:" + layer_name);
      if (layer_name.includes(",")) {
        /* let ds_layers = layer_name.split("/");
        let ds = ds_layers[0];
        let layers = ds_layers[1].split(","); */
        let layers = this.createArrayFromLayerName(layer_name);
        for (let indiv_layer of layers) {
          url_arr.push(
            //`${url_prefix}&request=GetMetadata&item=layerDetails&layerName=${ds}/${indiv_layer}`
            `${url_prefix}&request=GetMetadata&item=layerDetails&layerName=${indiv_layer}`
          );
        }
      } else if (layer_name instanceof Array) {
        for (let indiv_layer of layer_name) {
          url_arr.push(
            `${url_prefix}&request=GetMetadata&item=layerDetails&layerName=${indiv_layer}`
          );
        }
      } else {
        url_arr.push(
          `${url_prefix}&request=GetMetadata&item=layerDetails&layerName=${layer_name}`
        );
      }
      return url_arr;
    },

    /* convertDateStringToTime(date_str) {
      return new Date(moment(date_str + "Z", "YYYY-MM-DDZ"));
    }, */

    createTimeStepsUrls(url_prefix, layer_name, date_arr) {
      let ts_url_arr = [];

      for (let dt of date_arr) {
        let frmtd_date = moment(dt).format("YYYY-MM-DD");
        let ts_url = this.createTimeStepsUrl(
          url_prefix,
          layer_name,
          frmtd_date
        );
        ts_url_arr.push(ts_url);
      }
      return ts_url_arr;
    },

    getTimeFromNcWMSLayerTimeString(ncwms_time_str) {
      //2020-09-08T09:12:33
      let day_time_str = ncwms_time_str.split("T");
      return new Date(
        moment(
          day_time_str[0] + " " + day_time_str[1] + "Z",
          "YYYY-MM-DDhh:mm:ssZ"
        )
      );
    },

    getLayerTimes(date_arr, ts_data) {
      let date_time_list = [];

      for (let dt_indx in date_arr) {
        let day_str = moment(date_arr[dt_indx]).format("YYYY-MM-DD");
        let timesteps = ts_data[dt_indx]; //.timesteps;
        //console.log("timesteps:" + timesteps);
        if (timesteps[0] < timesteps[timesteps.length - 1]) {
          timesteps = timesteps.reverse();
        }
        for (let tm of timesteps) {
          let time_str = tm.substring(0, tm.length - 1);
          let date_time = new Date(
            moment(day_str + " " + time_str + "Z", "YYYY-MM-DDhh:mm:ss.SSSZ")
          );
          date_time_list.push(date_time);
        }
      }
      return date_time_list;
    },

    createLayerRangeUrl(
      layer_info,
      metadata_arr,
      layer_time,
      elevation_values
    ) {
      let frmt_dt_time =
        layer_time instanceof Date
          ? this.createFormattedDateTimeString(layer_time)
          : layer_time;

      /* console.log("url:" + layer_info.url_prefix);
      console.log("wms_Version:" + layer_info.wms_version); */
      let url_arr = [];

      let layers_list = [];
      if (layer_info.layer_name.includes(",")) {
        layers_list = this.createArrayFromLayerName(layer_info.layer_name);
        /* let ds_layers = layer_info.layer_name.split("/");
        let ds = ds_layers[0];
        let layers = ds_layers[1].split(",");
        layers_list = layers.map((layer) => `${ds}/${layer}`); */
      } else if (layer_info.layer_name instanceof Array) {
        layers_list = layer_info.layer_name;
      } else {
        layers_list.push(layer_info.layer_name);
      }
      let cnt = 0;
      for (let indiv_layer of layers_list) {
        let bbox = metadata_arr[cnt].bbox;
        //let epsg4326_box = [bbox[1], bbox[0], bbox[3], bbox[2]];
        let epsg4326_box = bbox;
        //console.log("epsg4326_box:" + epsg4326_box);
        let minmax_url = `${layer_info.url_prefix}&version=${layer_info.wms_version}&CRS=${layer_info.sat_projection}&BBOX=${epsg4326_box}&elevation=${elevation_values[cnt]}&request=GetMetadata&item=minmax&width=256&height=256&layers=${indiv_layer}&time=${frmt_dt_time}`;
        url_arr.push(minmax_url);
        cnt = cnt + 1;
      }

      return url_arr;
    },

    getFeatureInfoUrl(
      raster_layer,
      map_bbox,
      map_size,
      scan_pix,
      request_name,
      time_clause,
      output_format,
      plevel_clause = ""
    ) {
      //      let featureInfoUrls = [];
      let url_prefix =
        raster_layer.url +
        "&service=WMS&request=" +
        request_name +
        "&version=" +
        raster_layer.version +
        "&CRS=" +
        raster_layer.projection +
        "&BBOX=" +
        map_bbox +
        "&I=" +
        scan_pix[0] +
        "&J=" +
        scan_pix[1] +
        "&TIME=" +
        time_clause +
        "&INFO_FORMAT=" +
        output_format;
      if (request_name !== "GetVerticalProfile") {
        let elev = raster_layer.extParams.elevation;
        if (elev === undefined) {
          elev = 0;
        }
        url_prefix += "&ELEVATION=" + elev;
      } else {
        if (plevel_clause !== "") {
          url_prefix += "&ELEVATION=" + plevel_clause;
        }
      }

      let url_suffix = "&WIDTH=" + map_size[0] + "&HEIGHT=" + map_size[1];
      let query_layers;
      let single_layername;
      let feature_count = 0;
      //console.log("layerName:" + raster_layer.layerName);
      if (raster_layer.layerName.includes(",")) {
        let layer_names = raster_layer.layerName.split(",");
        feature_count = 0; //layer_names.length;
        single_layername = layer_names[0];
        //query_layers = raster_layer.layerName;
        query_layers = "";
        for (let indx = 0; indx < layer_names.length; indx++) {
          let lname = layer_names[indx];
          if (lname.endsWith("-group")) {
            let ds_lname = lname.split("/");
            let ds = ds_lname[0];
            let only_grpname = ds_lname[1];
            let grp_lnames = only_grpname.substr(
              0,
              only_grpname.indexOf("-group")
            );
            let ind_layers = grp_lnames.split(":");
            for (let indx2 = 0; indx2 < ind_layers.length; indx2++) {
              query_layers += ds + "/" + ind_layers[indx2];
              if (indx2 != ind_layers.length - 1) {
                query_layers += ",";
              }
              feature_count++;
            }
          } else {
            query_layers += lname;
            feature_count++;
          }
          if (indx != layer_names.length - 1) {
            query_layers += ",";
          }
        }
      } else {
        single_layername = raster_layer.layerName;
        if (raster_layer.layerName.endsWith("-group")) {
          let lname = raster_layer.layerName;
          let ds_lname = lname.split("/");
          let ds = ds_lname[0];
          let only_grpname = ds_lname[1];
          let grp_lnames = only_grpname.substr(
            0,
            only_grpname.indexOf("-group")
          );
          let ind_layers = grp_lnames.split(":");
          query_layers = "";
          for (let indx2 = 0; indx2 < ind_layers.length; indx2++) {
            query_layers += ds + "/" + ind_layers[indx2];
            if (indx2 != ind_layers.length - 1) {
              query_layers += ",";
            }
            feature_count++;
          }
        } else {
          query_layers = raster_layer.layerName;

          feature_count = 1;
        }
      }
      //console.log("query_layers:" + query_layers);
      let featureInfoUrl =
        url_prefix +
        "&QUERY_LAYERS=" +
        query_layers +
        "&LAYERS=" +
        single_layername +
        "&FEATURE_COUNT=" +
        feature_count +
        url_suffix;
      return featureInfoUrl;
    },

    areNumericArraysEqual(a, b) {
      return (
        a !== undefined &&
        b != undefined &&
        a.length === b.length &&
        a.every((value, index) => value === b[index])
      );
    },

    isTSProbeInfoChanged(old_value, new_value) {
      //For Time Series
      let changed =
        old_value.layer.layerName !== new_value.layer.layerName ||
        old_value.layer.url !== new_value.layer.url ||
        old_value.layer.version !== new_value.layer.version ||
        old_value.layer.projection !== new_value.layer.projection ||
        old_value.layer.extParams.elevation !==
          new_value.layer.extParams.elevation ||
        !this.areNumericArraysEqual(old_value.map_bbox, new_value.map_bbox) ||
        !this.areNumericArraysEqual(old_value.map_size, new_value.map_size) ||
        !this.areNumericArraysEqual(old_value.scan_pix, new_value.scan_pix) ||
        !this.areNumericArraysEqual(old_value.location, new_value.location);
      console.log("TS ProbeInfoChanged:" + changed);
      return changed;
    },

    isVPProbeInfoChanged(old_value, new_value) {
      //For Vertical Profile/SkewT
      let changed =
        old_value.layer.layerName !== new_value.layer.layerName ||
        old_value.layer.url !== new_value.layer.url ||
        old_value.layer.version !== new_value.layer.version ||
        old_value.layer.projection !== new_value.layer.projection ||
        old_value.layer.time !== new_value.layer.time ||
        !this.areNumericArraysEqual(old_value.map_bbox, new_value.map_bbox) ||
        !this.areNumericArraysEqual(old_value.map_size, new_value.map_size) ||
        !this.areNumericArraysEqual(old_value.scan_pix, new_value.scan_pix) ||
        !this.areNumericArraysEqual(old_value.location, new_value.location);
      //console.log("VP ProbeInfoChanged:" + changed);
      return changed;
    },

    isPointProbeInfoChanged(old_value, new_value) {
      //For Point Probe
      console.log(old_value.layer.layerName + " " + new_value.layer.layerName);
      let out =
        old_value.layer.layerName !== new_value.layer.layerName ||
        old_value.layer.url !== new_value.layer.url ||
        old_value.layer.version !== new_value.layer.version ||
        old_value.layer.projection !== new_value.layer.projection ||
        old_value.layer.time !== new_value.layer.time ||
        !this.areNumericArraysEqual(old_value.location, new_value.location);
      console.log("isPointPorbeChanged:" + out);
      return out;
    },

    deepCopy(obj) {
      let newO;

      if (typeof obj !== "object") {
        return obj;
      }
      if (!obj) {
        return obj;
      }

      if (Array.isArray(obj)) {
        newO = [];
        for (let i = 0; i < obj.length; i++) {
          newO[i] = this.deepCopy(obj[i]);
        }
        return newO;
      }

      newO = {};
      for (let i in obj) {
        newO[i] = this.deepCopy(obj[i]);
      }
      return newO;
    },
    compareScalarArrays(a1, a2) {
      let cmp = true;
      if (a1.length != a2.length) {
        cmp = false;
      } else {
        for (let indx = 0; indx < a1.length; a1++) {
          if (a1[indx] !== a2[indx]) {
            cmp = false;
            break;
          }
        }
      }

      return cmp;
    },
    createCaptionedDateList(my_datelist, my_date_format) {
      let datelist_with_caption = [];
      for (let dt of my_datelist) {
        datelist_with_caption.push({
          value: dt,
          caption: this.creatFormattedDateString(dt, my_date_format),
        });
      }
      return datelist_with_caption;
    },

    createFormattedLayerName(ds_name, layer_name) {
      let formatted_layername = "";

      if (layer_name instanceof Array) {
        let layernames = layer_name;
        //console.log("Do we reach here");
        for (let indx = 0; indx < layernames.length; indx++) {
          if (layernames[indx].includes("/")) {
            formatted_layername += layernames[indx];
          } else {
            formatted_layername += ds_name + "/" + layernames[indx];
          }
          if (indx != layernames.length - 1) {
            formatted_layername += ",";
          }
        }
      } else {
        formatted_layername = ds_name + "/" + layer_name;
      }
      return formatted_layername;
    },
    format1DigitTo2Digit(hours) {
      let hrs_int = parseInt(hours);
      return hrs_int <= 9 ? "0" + hrs_int : hrs_int;
    },

    createCaptionedTimeList(
      mytimelist,
      my_sel_date,
      my_time_format,
      tz_id,
      model_tab = false,
      start_time = undefined
    ) {
      let timelist_with_caption = [];
      let sorted_timelist = undefined;

      if (model_tab) {
        sorted_timelist = mytimelist.sort((d1, d2) => {
          if (d1.value !== undefined) {
            return d1.value.getTime() - d2.value.getTime();
          } else {
            return d1.getTime() - d2.getTime();
          }
        });
      } else {
        sorted_timelist = mytimelist;
      }

      for (let tm of sorted_timelist) {
        let tm_value = tm.value;
        if (tm_value === undefined) {
          tm_value = tm;
        }

        let mycap = undefined;
        if (model_tab) {
          mycap =
            "F" +
            this.format1DigitTo2Digit(
              (tm_value.getTime() - start_time.getTime()) / (3600 * 1000)
            );
        } else {
          //console.log("tm_value:"+ Object.keys(tm_value));
          mycap = this.createFormattedTimeString2(
            my_sel_date,
            tm_value,
            my_time_format,
            tz_id
          );
        }

        timelist_with_caption.push({
          value: tm_value,
          caption: mycap,
        });
      }
      return timelist_with_caption;
    },
  },
};
