import Vuex from "vuex";
import Vue from "vue";

import { Constants } from "../mixins/";

Vue.use(Vuex);

export default new Vuex.Store({
  //mixins: [Constants],
  state: {
    layerlist_open: false,
    raster_layer_list: [],
    metadata_cache: new Map(),
    ts_cache: new Map(),
    minmax_cache: new Map(),
    sld_map: new Map(),
    probe_info: { caption: "none", id: "none", location: [], layer: {} },
    mobileView: false,
    distance_probe: "",
    area_probe: "",
    sel_timezone: Constants.IST_TZ,
    animationlayer: {},
    map_props: {},
    addl_layerslist_map: {},
    gridlines_visible: false,
    gridlines_color: "rgba(255,255,255,1)",
    gridlines_width: 1,
  },

  getters: {
    getAddlLayersListByCat: (state) => (cat) => {
      let out_list = state.addl_layerslist_map[cat];
      return out_list;
    },
    getAddlLayer: (state) => (info) => {
      let veclayer;
      //TODO:replace by filter
      let layers_list = state.addl_layerslist_map[info.cat];
      for (let vlayer of layers_list) {
        let key = vlayer.url + "/" + vlayer.layerName;
        if (key === info.url) {
          veclayer = vlayer;
          break;
        }
      }
      return veclayer;
    },

    getFromSLDCache: (state) => (key) => state.sld_map.get(key),
    getProbeInfo: (state) => state.probe_info,

    getRasterLayerList: (state) => state.raster_layer_list,
    getRasterLayer: (state) => (layer_type) =>
      state.raster_layer_list.find((el) => el.layer_type == layer_type),
    getRasterLayerProperty: (state) => (layer_info) =>
      state.raster_layer_list.find(
        (el) => el.layer_type == layer_info.layer_type
      )[layer_info.prop],
    getFromMetadataCache: (state) => (urls) => {
      let metadata_arr = [];

      if (urls instanceof Array) {
        for (let url of urls) {
          let met = state.metadata_cache.get(url);
          //if (met !== undefined) {
          metadata_arr.push(met);
          //}
        }
      } else {
        let met = state.metadata_cache.get(urls);
        //if (met !== undefined) {
        metadata_arr.push(met);
        //}
      }
      return metadata_arr;
    },
    getFromTSCache: (state) => (url) => {
      let url_exp = new URL(url);
      let lname = url_exp.searchParams.get("layerName");
      url_exp.searchParams.set("layerName", lname.split("/")[0]);
      return state.ts_cache.get(url_exp.toString());
      //return state.ts_cache.get(url);
    },
    getFromMinMaxCache: (state) => (urls) => {
      let mm_arr = [];
      if (urls instanceof Array) {
        for (let url of urls) {
          let mm = state.minmax_cache.get(url);
          if (mm !== undefined) {
            mm_arr.push(mm);
          }
        }
      } else {
        let mm = state.minmax_cache.get(urls);
        if (mm !== undefined) {
          mm_arr.push(mm);
        }
      }
      return mm_arr;
    },
  },

  mutations: {
    setGridLinesColor: (state, new_val) => {
      state.gridlines_color = new_val;
    },
    setGridLinesWidth: (state, new_val) => {
      state.gridlines_width = new_val;
    },
    setGridLineVisibility: (state, new_value) => {
      state.gridlines_visible = new_value;
    },
    updateTimeZone: (state, new_value) => {
      state.sel_timezone = new_value;
    },
    updateDistanceProbe: (state, new_value) => {
      state.distance_probe = new_value;
    },
    updateAreaProbe: (state, new_value) => {
      state.area_probe = new_value;
    },
    updateProbeInfo: (state, new_probe_info) => {
      Object.assign(state.probe_info, new_probe_info);
    },
    setMobileView: (state, value) => {
      /* if (!value) {
        state.mobileView = true;
      } else {
        state.mobileView = true;
      } */
      state.mobileView = value;
    },

    setLayerListOpen: (state, isOpen) => {
      state.layerlist_open = isOpen;
    },
    addRasterLayer: (state, raster_layer) => {
      state.raster_layer_list.push(raster_layer);
    },

    setRasterLayer: (state, raster_layer) => {
      //console.log(" In setRaster layer_type:" + raster_layer.layer_type);
      let layer_indx = state.raster_layer_list.findIndex(
        (el) => el.layer_type == raster_layer.layer_type
      );
      /* console.log(
        "MUTATION DONE setRaster:" + layer_indx + " " + raster_layer.layer_type
      ); */
      Vue.set(state.raster_layer_list, layer_indx, raster_layer); //Array caveats
    },

    addToMetadataCache: (state, url_val) => {
      if (url_val.url instanceof Array) {
        let urls = url_val.url;
        let vals = url_val.val;
        let num_eles = urls.length;
        for (let i = 0; i < num_eles; i++) {
          state.metadata_cache.set(urls[i], vals[i]);
        }
      } else {
        //console.log("addToMetadata single");
        state.metadata_cache.set(url_val.url, url_val.val);
      }
    },

    addToTSCache: (state, url_val) => {
      //console.log("Adding to ts cache:" + url_val.url);
      let url_exp = new URL(url_val.url);
      let lname = url_exp.searchParams.get("layerName");
      url_exp.searchParams.set("layerName", lname.split("/")[0]);
      state.ts_cache.set(url_exp.toString(), url_val.val);
      //state.ts_cache.set(url_val.url, url_val.val);
    },

    addToMinMaxCache: (state, url_val) => {
      if (url_val.url instanceof Array) {
        let urls = url_val.url;
        let vals = url_val.val;
        let num_eles = urls.length;
        for (let i = 0; i < num_eles; i++) {
          state.minmax_cache.set(urls[i], vals[i]);
        }
      } else {
        state.minmax_cache.set(url_val.url, url_val.val);
      }
    },
    addToSLDCache: (state, sld_val) => {
      state.sld_map.set(sld_val.sld, sld_val.val);
    },
    updateRaster: (state, info) => {
      let layer_indx = state.raster_layer_list.findIndex(
        (el) => el.layer_type == info.layer_type
      );

      Object.assign(state.raster_layer_list[layer_indx], info.items);
    },
    setAnimationLayer: (state, mylayer) => {
      state.animationlayer = mylayer;
    },
    updateAnimationLayer: (state, info) => {
      Object.assign(state.animationlayer, info.items);
    },
    updateMapProps: (state, props) => {
      if (Object.keys(state.map_props).length <= 0) {
        state.map_props = props;
      } else {
        Object.assign(state.map_props, props);
      }
    },

    setAdditionLayerList: (state, info) => {
      Vue.set(state.addl_layerslist_map, info.cat, info.layers_list);
    },

    updateAdditionalLayer: (state, layer_info) => {
      let layers_list = state.addl_layerslist_map[layer_info.cat];
      let sel_indx = layers_list.findIndex(
        (layer) => layer.url + "/" + layer.layerName === layer_info.url
      );
      if (sel_indx >= 0) {
        let new_layer = { ...layers_list[sel_indx], ...layer_info.items };
        Vue.set(layers_list, sel_indx, new_layer);
      }
    },
  },

  /*  actions: {
    updateRaster: async (context, info) => {
      setTimeout(function() {
        context.commit("updateRasterSync", info);
      }, 0);
    },
  }, */
});
